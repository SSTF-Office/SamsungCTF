#!/bin/bash
python dump.py | nc 0 55402
