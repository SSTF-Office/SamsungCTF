from pickle import dumps

print dumps([1, 2, 3])+'#'
