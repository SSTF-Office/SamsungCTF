const express = require('express')
const bodyParser = require('body-parser')
const AWS = require('aws-sdk')
const ejs = require('ejs')
const app = express()
const port = 3000

// AWS configuration
AWS.config.update({
  accessKeyId: 'YOUR_AWS_ACCESS_KEY_ID',
  secretAccessKey: 'YOUR_AWS_SECRET_ACCESS_KEY',
  region: 'YOUR_AWS_S3_REGION'
})
const s3 = new AWS.S3()

// Middleware
app.use(bodyParser.urlencoded({ extended: false }))
app.use(bodyParser.json())

// Scaffolding APIs
app.get('/login', (req, res) => {
  res.send('Login Page')
})
app.get('/logout', (req, res) => {
  res.send('Logout Page')
})
app.get('/memberinfo', (req, res) => {
  res.send('Member Info Page')
})

// URL Shortener APIs
app.post('/harrypotter/get_url', (req, res) => {
  // Assume the URL is passed in the request body as 'url' parameter
  const url = req.body.url

  // Generate a unique ID for the shortened URL
  const id = Math.random().toString(36).substring(2, 15)

  // Store the shortened URL in AWS S3
  s3.putObject({
    Bucket: 'YOUR_AWS_S3_BUCKET_NAME',
    Key: `urls/${id}`,
    Body: url
  }, (err) => {
    if (err) {
      console.error(err)
      res.status(500).send('Error occurred while shortening URL')
    } else {
      // Return the shortened URL to the client
      const shortened_url = `http://localhost:${port}/harrypotter/${id}`
      res.send(shortened_url)
    }
  })
})
app.get('/harrypotter/:id', (req, res) => {
  // Retrieve the URL from AWS S3 using the ID and redirect to the original URL
  const id = req.params.id
  s3.getObject({
    Bucket: 'YOUR_AWS_S3_BUCKET_NAME',
    Key: `urls/${id}`
  }, (err, data) => {
    if (err) {
      console.error(err)
      res.status(404).send('Shortened URL not found')
    } else {
      const url = data.Body.toString()
      res.redirect(url)
    }
  })
})

// Arithmetic Calculation API
app.post('/sylvester/eval', (req, res) => {
  // Assume the expression is passed in the request body as 'exp' parameter
  const exp = req.body.exp

  // Evaluate the expression and return the result to the client
  try {
    const result = eval(exp)
    res.send(`${exp} = ${result}`)
  } catch (err) {
    console.error(err)
    res.status(400).send('Invalid expression')
  }
})

// Start the server
app.listen(port, () => {
  console.log(`Server listening on port ${port}`)
})