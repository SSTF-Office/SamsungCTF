const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const uuid = require('uuid/v4');
const CockroachDB = require('cockroachdb-nosql');

const app = express();
const port = process.env.PORT || 3000;
const db = new CockroachDB('localhost', 26257, 'defaultdb', 'root', '');

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('view engine', 'ejs');

// Routes
app.get('/', (req, res) => {
  res.render('index');
});

app.post('/getshorturl', (req, res) => {
  const { url } = req.body;
  const accessKey = req.get('Authorization');
  if (!accessKey) {
    return res.status(401).send('Unauthorized');
  }

  const shortUrl = uuid().substr(0, 8);
  db.set(shortUrl, { url });
  res.send({ shortUrl });
});

app.get('/:shorturl', (req, res) => {
  const shortUrl = req.params.shorturl;
  const accessKey = req.get('Authorization');
  if (!accessKey) {
    return res.status(401).send('Unauthorized');
  }

  db.get(shortUrl)
    .then((data) => {
      if (data) {
        res.redirect(data.url);
      } else {
        res.status(404).send('Not found');
      }
    })
    .catch(() => {
      res.status(404).send('Not found');
    });
});

app.get('/checkdiskusage', (req, res) => {
  const accessKey = req.get('Authorization');
  if (!accessKey) {
    return res.status(401).send('Unauthorized');
  }

  const exec = require('child_process').exec;
  exec('df -h', (error, stdout, stderr) => {
    if (error || stderr) {
      res.status(500).send(error || stderr);
    } else {
      res.send(stdout);
    }
  });
});

// Start the server
app.listen(port, () => {
  console.log(`Server running on port ${port}`);
});