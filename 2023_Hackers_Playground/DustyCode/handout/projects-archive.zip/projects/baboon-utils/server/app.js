const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const { v4: uuidv4 } = require('uuid');
const cockroach = require('pg');
const { eval } = require('mathjs');

const app = express();

// Set up middleware
app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');

// Database connection
const cockroachDB = new cockroach.Pool({
  host: 'localhost',
  port: 26257,
  user: 'root',
  database: 'mydatabase',
  ssl: {
    rejectUnauthorized: false
  }
});

// Web Cache feature
let cache = {};

app.get('/:animal', (req, res) => {
  const url = req.query.url;
  const cacheId = req.query.cacheId;

  if (cacheId) {
    return res.send(cache[cacheId]);
  }

  fetch(url)
    .then(response => response.text())
    .then(body => {
      const cacheId = uuidv4();
      cache[cacheId] = body;
      res.send(cacheId);
    })
    .catch(error => console.log(error));
});

// Arithmetic calculation API
app.post('/calculate', (req, res) => {
  const expression = req.body.expression;
  const result = eval(expression);
  res.json({ result });
});

// Login API
app.post('/login', (req, res) => {
  const accessKey = req.body.accessKey;

  // Authenticate access key
  if (accessKey === 'randomstring') {
    const token = uuidv4();
    const query = 'INSERT INTO sessions (token) VALUES ($1)';
    const values = [token];

    cockroachDB.query(query, values, (err, res2) => {
      if (err) {
        console.log(err.stack);
        res.status(500).send('Internal server error');
      } else {
        res.json({ token });
      }
    });
  } else {
    res.status(401).send('Unauthorized');
  }
});

// Logout API
app.delete('/logout', (req, res) => {
  const token = req.body.token;
  const query = 'DELETE FROM sessions WHERE token = $1';
  const values = [token];

  cockroachDB.query(query, values, (err, res2) => {
    if (err) {
      console.log(err.stack);
      res.status(500).send('Internal server error');
    } else {
      res.send('Logout successful');
    }
  });
});

// Memberinfo check API
app.get('/memberinfo', (req, res) => {
  const token = req.query.token;
  const query = 'SELECT COUNT(*) FROM sessions WHERE token = $1';
  const values = [token];

  cockroachDB.query(query, values, (err, res2) => {
    if (err) {
      console.log(err.stack);
      res.status(500).send('Internal server error');
    } else {
      const count = res2.rows[0].count;
      if (count > 0) {
        res.send('Memberinfo found!');
      } else {
        res.status(401).send('Unauthorized');
      }
    }
  });
});

app.listen(3000, () => console.log('Server running on port 3000...'));