const Hapi = require('hapi');
const Joi = require('joi');
const redis = require('redis');

const port = process.env.PORT || 3000;
const accessKey = process.env.ACCESS_KEY || 'random-access-key';
const redisHost = process.env.REDIS_HOST || 'localhost';
const redisPort = process.env.REDIS_PORT || 6379;

// create a redis client
const client = redis.createClient(redisPort, redisHost);

client.on('error', err => {
  console.error('Redis Error:', err);
});

// create a Hapi server instance
const server = new Hapi.Server({
  port,
  routes: {
    validate: {
      failAction: (request, h, err) => {
        throw err;
      }
    }
  }
});

// safe exec function to check disk usage
const checkDiskUsage = async () => {
  return new Promise((resolve, reject) => {
    const exec = require('child_process').exec;
    exec('df', (err, stdout, stderr) => {
      if (err) {
        reject(stderr);
      } else {
        resolve(stdout);
      }
    });
  });
}

// register plugins
(async () => {
  await server.register(require('hapi-auth-basic'));
  await server.register(require('hapi-rate-limit'));

  // configure auth strategy
  server.auth.strategy('access_key', 'basic', {
    validate: async (request, username, password, h) => {
      if (password === accessKey) {
        return { isValid: true };
      } else {
        return { isValid: false };
      }
    }
  });

  // configure rate limit
  server.ext('onPreAuth', (request, h) => {
    return h.rateLimit({
      userCache: client,
      user: request.info.remoteAddress,
      method: request.method
    });
  });

  // define routes
  server.route([
    // login route
    {
      method: 'POST',
      path: '/monkey/login',
      handler: async (request, h) => {
        return { message: 'Logged in successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // logout route
    {
      method: 'POST',
      path: '/lion/logout',
      handler: async (request, h) => {
        return { message: 'Logged out successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // member info route
    {
      method: 'GET',
      path: '/tiger/info',
      handler: async (request, h) => {
        return { message: 'Welcome back, member!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // add friend route
    {
      method: 'POST',
      path: '/giraffe/friends',
      handler: async (request, h) => {
        return { message: 'Friend added successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // remove friend route
    {
      method: 'DELETE',
      path: '/elephant/friends',
      handler: async (request, h) => {
        return { message: 'Friend removed successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // find friends route
    {
      method: 'GET',
      path: '/koala/friends',
      handler: async (request, h) => {
        return { message: 'Friends found successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // add post route
    {
      method: 'POST',
      path: '/crocodile/posts',
      handler: async (request, h) => {
        return { message: 'Post added successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // comment on post route
    {
      method: 'POST',
      path: '/panda/posts/comments',
      handler: async (request, h) => {
        return { message: 'Comment added successfully!' };
      },
      config: {
        auth: 'access_key'
      }
    },
    // check disk usage route
    {
      method: 'GET',
      path: '/whale/diskusage',
      handler: async (request, h) => {
        const result = await checkDiskUsage();
        return { result };
      },
      config: {
        auth: 'access_key'
      }
    }
  ]);

  // start the server
  await server.start();
  console.log(`Server running on ${server.info.uri}`);
})();