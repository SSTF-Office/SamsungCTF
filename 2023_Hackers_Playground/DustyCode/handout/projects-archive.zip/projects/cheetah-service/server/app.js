const http = require('http');
const WebSocket = require('ws');
const url = require('url');
const crypto = require('crypto');
const CockroachDB = require('cockroachdb-nodejs');

const db = new CockroachDB({
  host: 'localhost',
  port: 26257,
  database: 'my_database',
  user: 'my_username',
  password: 'my_password',
});

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);

  // Serve static files for web client
  if (/^\/static\//.test(parsedUrl.pathname)) {
    // serve static file
  }

  // Handle API endpoints
  if (parsedUrl.pathname === '/login') {
    if (req.method === 'POST') {
      let body = [];
      req.on('data', chunk => {
        body.push(chunk);
      }).on('end', () => {
        body = Buffer.concat(body).toString();
        const data = JSON.parse(body);

        if (data.access_key === 'my_random_access_key') {
          const sessionId = crypto.randomBytes(16).toString('hex');
          db.insert('sessions', { id: sessionId, userId: 'my_user_id' });
          res.writeHead(200, {
            'Set-Cookie': `session_id=${sessionId}; HttpOnly; Path=/`,
          });
          res.end(JSON.stringify({ success: true }));
        } else {
          res.writeHead(401);
          res.end();
        }
      });
    } else {
      res.writeHead(405);
      res.end();
    }
  } else if (parsedUrl.pathname === '/logout') {
    if (req.method === 'POST') {
      const sessionId = req.headers.cookie ? req.headers.cookie.split('=')[1] : null;
      if (sessionId) {
        db.delete('sessions', { id: sessionId });
      }
      res.writeHead(200, {
        'Set-Cookie': 'session_id=; exires=Thu, 01 Jan 1970 00:00:00 GMT; HttpOnly; Path=/',
      });
      res.end();
    } else {
      res.writeHead(405);
      res.end();
    }
  } else if (parsedUrl.pathname === '/memberinfo') {
    if (req.method === 'GET') {
      const sessionId = req.headers.cookie ? req.headers.cookie.split('=')[1] : null;
      if (sessionId) {
        const session = await db.getById('sessions', sessionId);
        if (session && session.userId === 'my_user_id') {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ id: 'my_user_id' }));
        } else {
          res.writeHead(401);
          res.end();
        }
      } else {
        res.writeHead(401);
        res.end();
      }
    } else {
      res.writeHead(405);
      res.end();
    }
  } else if (parsedUrl.pathname === '/create_room') {
    // Create new chat room
  } else if (parsedUrl.pathname === '/delete_room') {
    // Delete chat room
  } else if (parsedUrl.pathname === '/join_room') {
    // Join chat room
  } else if (parsedUrl.pathname === '/direct_message') {
    // Send direct message
  } else if (parsedUrl.pathname === '/broadcast') {
    // Broadcast to chat room
  } else if (parsedUrl.pathname === '/safe_exec') {
    if (req.method === 'POST') {
      let body = [];
      req.on('data', chunk => {
        body.push(chunk);
      }).on('end', async () => {
        body = Buffer.concat(body).toString();
        const command = JSON.parse(body).cmd;
        if (/^\s*(ls|df)\s*$/.test(command)) {
          // execute command safely
          res.end();
        } else {
          res.writeHead(403);
          res.end();
        }
      });
    } else {
      res.writeHead(405);
      res.end();
    }
  } else {
    res.writeHead(404);
    res.end();
  }
});

const wss = new WebSocket.Server({ server });

wss.on('connection', (ws, req) => {
  const sessionId = req.headers.cookie ? req.headers.cookie.split('=')[1] : null;

  if (sessionId) {
    const session = await db.getById('sessions', sessionId);
  }

  // Handle WebSocket messages for Realtime Chatting
  ws.on('message', message => {
    
  });

  // Handle WebSocket client disconnection
  ws.on('close', () => {
    
  });
});

server.listen(3000);
console.log('Server started on port 3000');