const http = require('http');
const fs = require('fs');
const { exec } = require('child_process');
const bodyParser = require('body-parser');

const port = process.env.PORT || 3000;
const dataFile = 'data.json';
const accessKey = 'RandomAccessKeyHere';

// Function to read data from the data file
function readData() {
  let data = [];
  try {
    data = JSON.parse(fs.readFileSync(dataFile, 'utf8'));
  } catch (err) {
    console.error(err);
  }
  return data;
}

// Function to write data to the data file
function writeData(data) {
  fs.writeFileSync(dataFile, JSON.stringify(data), 'utf8');
}

// Function to safely execute a command and return the result
function safeExec(command) {
  return new Promise((resolve, reject) => {
    exec(command, (err, stdout, stderr) => {
      if (err) {
        reject(err);
      } else {
        resolve(stdout);
      }
    });
  });
}

// Function to authenticate requests
function authenticate(req) {
  const authHeader = req.headers.authorization || '';
  const accessKeyMatch = authHeader.match(/^Bearer (.+)$/);
  if (accessKeyMatch && accessKeyMatch[1] === accessKey) {
    return true;
  }
  return false;
}

// Create the HTTP server
const server = http.createServer((req, res) => {
  // Allow cross-origin resource sharing (CORS)
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Headers', 'Authorization, Content-Type');

  // Check disk usage before handling the request
  safeExec('df -k .').then((output) => {
    console.log('Disk usage:', output.trim());
    if (!authenticate(req)) {
      res.writeHead(401);
      res.end();
      return;
    }
    // Handle the request
    if (req.method === 'GET' && req.url === '/board') {
      // Get all the posts
      const data = readData();
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(data.posts));
    } else if (req.method === 'GET' && req.url.match(/^\/board\/(\d+)$/)) {
      // Get a specific post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const data = readData();
      const post = data.posts.find((p) => p.id === postId);
      if (post) {
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(post));
      } else {
        res.writeHead(404);
        res.end();
      }
    } else if (req.method === 'POST' && req.url === '/board') {
      // Create a new post
      const data = readData();
      const newPost = {
        id: data.nextPostId++,
        author: req.body.author,
        title: req.body.title,
        content: req.body.content,
        comments: [],
      };
      data.posts.push(newPost);
      writeData(data);
      res.writeHead(201, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(newPost));
    } else if (req.method === 'PUT' && req.url.match(/^\/board\/(\d+)$/)) {
      // Update an existing post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const data = readData();
      const post = data.posts.find((p) => p.id === postId);
      if (post) {
        post.author = req.body.author || post.author;
        post.title = req.body.title || post.title;
        post.content = req.body.content || post.content;
        writeData(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(post));
      } else {
        res.writeHead(404);
        res.end();
      }
    } else if (req.method === 'DELETE' && req.url.match(/^\/board\/(\d+)$/)) {
      // Delete a post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const data = readData();
      const index = data.posts.findIndex((p) => p.id === postId);
      if (index >= 0) {
        const post = data.posts.splice(index, 1)[0];
        writeData(data);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(post));
      } else {
        res.writeHead(404);
        res.end();
      }
    } else if (req.method === 'POST' && req.url.match(/^\/board\/(\d+)\/comments$/)) {
      // Add a comment to a post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const data = readData();
      const post = data.posts.find((p) => p.id === postId);
      if (post) {
        const newComment = {
          id: post.comments.length,
          author: req.body.author,
          content: req.body.content,
          replies: [],
        };
        post.comments.push(newComment);
        writeData(data);
        res.writeHead(201, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(newComment));
      } else {
        res.writeHead(404);
        res.end();
      }
    } else if (req.method === 'PUT' && req.url.match(/^\/board\/(\d+)\/comments\/(\d+)$/)) {
      // Update an existing comment by ID in a post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const commentId = parseInt(req.url.split('/')[4], 10);
      const data = readData();
      const post = data.posts.find((p) => p.id === postId);
      if (post) {
        const comment = post.comments.find((c) => c.id === commentId);
        if (comment) {
          comment.author = req.body.author || comment.author;
          comment.content = req.body.content || comment.content;
          writeData(data);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(comment));
        } else {
          res.writeHead(404);
          res.end();
        }
      } else {
        res.writeHead(404);
        res.end();
      }
    } else if (req.method === 'DELETE' && req.url.match(/^\/board\/(\d+)\/comments\/(\d+)$/)) {
      // Delete a comment by ID in a post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const commentId = parseInt(req.url.split('/')[4], 10);
      const data = readData();
      const post = data.posts.find((p) => p.id === postId);
      if (post) {
        const index = post.comments.findIndex((c) => c.id === commentId);
        if (index >= 0) {
          const comment = post.comments.splice(index, 1)[0];
          writeData(data);
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(comment));
        } else {
          res.writeHead(404);
          res.end();
        }
      } else {
        res.writeHead(404);
        res.end();
      }
    } else if (req.method === 'POST' && req.url.match(/^\/board\/(\d+)\/comments\/(\d+)\/replies$/)) {
      // Add a reply to a comment by ID in a post by ID
      const postId = parseInt(req.url.split('/')[2], 10);
      const commentId = parseInt(req.url.split('/')[4], 10);
      const data = readData();
      const post = data.posts.find((p) => p.id === postId);
      if (post) {
        const comment = post.comments.find((c) => c.id === commentId);
        if (comment) {
          const newReply = {
            id: comment.replies.length,
            author: req.body.author,
            content: req.body.content,
          };
          comment.replies.push(newReply);
          writeData(data);
          res.writeHead(201, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify(newReply));
        } else {
          res.writeHead(404);
          res.end();
        }
      } else {
        res.writeHead(404);
        res.end();
      }
    } else {
      res.writeHead(404);
      res.end();
    }
  }).catch((err) => {
    console.error(err);
    res.writeHead(500);
    res.end();
  });
});

// Start the HTTP server
server.listen(port, () => {
  console.log(`Server listening on port ${port}`);
});