const Hapi = require('hapi');
const crypto = require('crypto');

const server = Hapi.server({
    port: 3000,
    host: 'localhost'
});

const accessKeys = new Set();
const urlData = new Map();

// Generate random access key
function generateAccessKey() {
    const accessKeyLength = 16;
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let accessKey = '';
    for (let i = 0; i < accessKeyLength; i++) {
        accessKey += chars[Math.floor(Math.random() * chars.length)];
    }
    return accessKey;
}

// Check if access key is valid
function isValidAccessKey(accessKey) {
    return accessKeys.has(accessKey);
}

// Safe exec function
async function safeExec(command) {
    const { exec } = require('child_process');
    // Check disk usage before executing command
    const { stdout } = await exec('df -h .');
    const [, , , , usedPercentage] = stdout.split(/\s+/);
    const diskUsageThreshold = 80;
    if (parseInt(usedPercentage) < diskUsageThreshold) {
        return await new Promise((resolve, reject) => {
            exec(command, (error, stdout, stderr) => {
                if (error) {
                    reject(error);
                } else {
                    resolve(stdout);
                }
            });
        });
    } else {
        throw new Error('Disk usage is too high.');
    }
}

// Generate URL shorten key
function generateShortenKey() {
    const shortenKeyLength = 8;
    const chars = 'abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789';
    let shortenKey = '';
    for (let i = 0; i < shortenKeyLength; i++) {
        shortenKey += chars[Math.floor(Math.random() * chars.length)];
    }
    return shortenKey;
}

// Route for login
server.route({
    method: 'POST',
    path: '/login',
    handler: (request, h) => {
        const accessKey = generateAccessKey();
        accessKeys.add(accessKey);
        return { access_key: accessKey };
    },
    options: {
        auth: false
    }
});

// Route for memberinfo check
server.route({
    method: 'GET',
    path: '/memberinfo',
    handler: (request, h) => {
        if (!isValidAccessKey(request.query.access_key)) {
            throw new Error('Invalid access key.');
        }
        return { message: 'You are logged in.' };
    }
});

// Route for logout
server.route({
    method: 'POST',
    path: '/logout',
    handler: (request, h) => {
        accessKeys.delete(request.payload.access_key);
        return { message: 'Logged out successfully.' };
    }
});

// Route for URL shortening
server.route({
    method: 'POST',
    path: '/tiger/url',
    handler: (request, h) => {
        if (!isValidAccessKey(request.payload.access_key)) {
            throw new Error('Invalid access key.');
        }
        const url = request.payload.url;
        const shortenKey = generateShortenKey();
        urlData.set(shortenKey, url);
        return { shorten_key: shortenKey };
    }
});

// Route for getting the shortened URL
server.route({
    method: 'GET',
    path: '/rhino/url',
    handler: (request, h) => {
        if (!isValidAccessKey(request.query.access_key)) {
            throw new Error('Invalid access key.');
        }
        const shortenKey = request.query.shorten_key;
        const url = urlData.get(shortenKey);
        if (!url) {
            throw new Error('Invalid shorten key.');
        }
        return { url: url };
    }
});

// Start the server
async function startServer() {
    try {
        await server.start();
    } catch (err) {
        console.log(err);
        process.exit(1);
    }
    console.log('Server running at:', server.info.uri);
}

startServer();