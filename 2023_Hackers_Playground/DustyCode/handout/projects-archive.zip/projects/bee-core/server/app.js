const express = require('express');
const { v4: uuidv4 } = require('uuid');
const WebSocket = require('ws');
const ejs = require('ejs');

const app = express();
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));
app.set('views', __dirname + '/views');
app.set('view engine', 'ejs');

// In-memory database
const rooms = {};
const users = {};

// Helper function to validate access_key
const checkAccessKey = (req, res, next) => {
  const accessKey = req.header('access_key');
  if (!accessKey || !users[accessKey]) {
    return res.status(401).send('Unauthorized');
  }
  next();
};

// Login API
app.post('/login', (req, res) => {
  const name = req.body.name;
  if (!name) {
    return res.status(400).send('Name is required');
  }
  const accessKey = uuidv4();
  users[accessKey] = { name };
  res.header('access_key', accessKey).send('Logged in');
});

// Logout API
app.post('/logout', checkAccessKey, (req, res) => {
  const accessKey = req.header('access_key');
  delete users[accessKey];
  res.send('Logged out');
});

// Member info API
app.get('/memberinfo', checkAccessKey, (req, res) => {
  const accessKey = req.header('access_key');
  const user = users[accessKey];
  res.json(user);
});

// Chat rooms APIs
app.get('/chatrooms', checkAccessKey, (req, res) => {
  res.json(Object.keys(rooms));
});

app.post('/chatrooms', checkAccessKey, (req, res) => {
  const name = req.body.name;
  if (!name) {
    return res.status(400).send('Name is required');
  }
  if (rooms[name]) {
    return res.status(400).send(`Chat room ${name} already exists`);
  }
  rooms[name] = [];
  res.send(`Chat room ${name} created`);
});

app.delete('/chatrooms/:name', checkAccessKey, (req, res) => {
  const name = req.params.name;
  if (!rooms[name]) {
    return res.status(404).send(`Chat room ${name} not found`);
  }
  delete rooms[name];
  res.send(`Chat room ${name} deleted`);
});

app.post('/joinroom/:name', checkAccessKey, (req, res) => {
  const name = req.params.name;
  const accessKey = req.header('access_key');
  if (!rooms[name]) {
    return res.status(404).send(`Chat room ${name} not found`);
  }
  rooms[name].push(users[accessKey]);
  res.send(`Joined chat room ${name}`);
});

// Websocket server for real-time chat
const wss = new WebSocket.Server({ port: 8080 });
wss.on('connection', (ws) => {
  ws.on('message', (message) => {
    const data = JSON.parse(message);
    switch (data.type) {
      case 'join':
        const { room, name } = data.payload;
        if (!rooms[room]) {
          return ws.send(JSON.stringify({ type: 'error', payload: `Chat room ${room} not found` }));
        }
        const accessKey = Object.keys(users).find(key => users[key].name === name);
        if (!accessKey) {
          return ws.send(JSON.stringify({ type: 'error', payload: `User ${name} not found` }));
        }
        ws.accessKey = accessKey;
        ws.room = room;
        rooms[room].push(users[accessKey]);
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN && client.room === room) {
            client.send(JSON.stringify({ type: 'join', payload: { name, rooms: rooms[room].map(user => user.name) } }));
          }
        });
        break;
      case 'message':
        const { room: roomName, sender, messageText } = data.payload;
        if (!rooms[roomName]) {
          return ws.send(JSON.stringify({ type: 'error', payload: `Chat room ${roomName} not found` }));
        }
        wss.clients.forEach((client) => {
          if (client.readyState === WebSocket.OPEN && client.room === roomName) {
            if (sender) {  // Direct message
              if (client.accessKey === Object.keys(users).find(key => users[key].name === sender)) {
                client.send(JSON.stringify({ type: 'message', payload: { sender, messageText } }));
              }
            } else {  // Broadcast message
              client.send(JSON.stringify({ type: 'message', payload: { sender: users[ws.accessKey].name, messageText } }));
            }
          }
        });
        break;
    }
  });
});

// Arithmetic calculation API
app.get('/calculate', checkAccessKey, (req, res) => {
  const expression = req.query.expression;
  if (!expression) {
    return res.status(400).send('Expression is required');
  }
  let result;
  try {
    result = eval(expression);
  } catch (e) {
    return res.status(400).send(`Invalid expression: ${e.message}`);
  }
  res.send(result.toString());
});

// Home page
app.get('/', (req, res) => {
  res.render('home', { rooms: Object.keys(rooms) });
});

const port = process.env.PORT || 3000;
app.listen(port, () => console.log(`Server started on port ${port}`));