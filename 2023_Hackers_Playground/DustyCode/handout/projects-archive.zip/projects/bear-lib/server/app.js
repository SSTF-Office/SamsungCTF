const http = require('http');
const redis = require('redis');
const url = require('url');
const WebSocket = require('ws');

const ACCESS_KEY = 'random_access_key'; // replace with your own random access key
const REDIS_PORT = 6379; // default Redis port
const REDIS_HOST = 'localhost'; // Redis server hostname
const server = http.createServer();

// create a new WebSocket server
const wss = new WebSocket.Server({ server });

// create a new Redis client
const redisClient = redis.createClient(REDIS_PORT, REDIS_HOST);

// handle incoming WebSocket connections
wss.on('connection', (ws) => {
  console.log('WebSocket client connected');
  // send a welcome message to the client
  ws.send('Welcome to the WebSocket server!');
});

// handle incoming HTTP requests
server.on('request', (req, res) => {
  const reqUrl = url.parse(req.url, true); // parse the request URL

  // check if the request includes an access key and whether it is valid
  if (reqUrl.query.access_key !== ACCESS_KEY) {
    res.statusCode = 401;
    res.end('Invalid Access Key');
    return;
  }

  // handle a login request
  if (reqUrl.pathname === '/login') {
    // check if the username and password are valid
    if (reqUrl.query.username === 'user' && reqUrl.query.password === 'pass') {
      // create a new session ID and store it in Redis
      const sessionId = Math.random().toString(36).substr(2, 9);
      redisClient.setex(sessionId, 3600, JSON.stringify({ username: reqUrl.query.username }));
      res.end(sessionId);
    } else {
      res.statusCode = 401;
      res.end('Invalid Credentials');
    }
  }

  // handle a logout request
  else if (reqUrl.pathname === '/logout') {
    // delete the session ID from Redis
    redisClient.del(reqUrl.query.session_id);
    res.end('Logged Out');
  }

  // handle a memberinfo request
  else if (reqUrl.pathname === '/memberinfo') {
    // check if the session ID is valid
    redisClient.get(reqUrl.query.session_id, (err, data) => {
      if (err) {
        res.statusCode = 500;
        res.end('Server Error');
        return;
      }
      if (!data) {
        res.statusCode = 401;
        res.end('Invalid Session ID');
        return;
      }
      const userInfo = JSON.parse(data);
      res.end(userInfo.username);
    });
  }

  // handle an arithmetic request
  else if (reqUrl.pathname === '/calc') {
    // check if the expression parameter is present and evaluate it using JavaScript's eval function
    if (reqUrl.query.expression) {
      try {
        const result = eval(reqUrl.query.expression);
        res.end(result.toString());
      } catch (error) {
        res.statusCode = 500;
        res.end('Calculation Error');
      }
    } else {
      res.statusCode = 400;
      res.end('Missing Parameter');
    }
  }

  // handle a URL request
  else if (reqUrl.pathname === '/url') {
    // check if the target URL parameter is present and send an HTTP request to that URL
    if (reqUrl.query.target) {
      http.get(reqUrl.query.target, (response) => {
        let responseData = '';
        response.on('data', (chunk) => {
          responseData += chunk;
        });
        response.on('end', () => {
          res.end(responseData);
        });
      }).on('error', (error) => {
        res.statusCode = 500;
        res.end('Server Error');
      });
    } else {
      res.statusCode = 400;
      res.end('Missing Parameter');
    }
  }

  // handle a default error
  else {
    res.statusCode = 404;
    res.end('Not Found');
  }
});

// start the server on port 3000
server.listen(3000, () => {
  console.log('Server listening on port 3000');
});