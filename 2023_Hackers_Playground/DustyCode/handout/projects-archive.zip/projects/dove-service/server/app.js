const express = require('express');
const bodyParser = require('body-parser');
const redis = require("redis");
const ejs = require('ejs');
const fs = require('fs');
const geoip = require('geoip-lite');

const app = express();

// parse application/json
app.use(bodyParser.json());

// setting view engine
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// connecting to redis database
const client = redis.createClient();

client.on('connect', function() {
    console.log('Connected to Redis...');
});

// login API
app.post('/login', function(req, res) {
    const access_key = req.body.access_key;
    
    // check if access key exists in redis
    client.get(access_key, function(err, reply) {
        if (err) {
            console.error(err);
            res.sendStatus(500);
        }
        else if (!reply) {
            res.sendStatus(401);
        }
        else {
            res.status(200).send({message: "Login successful!"});
        }
    });
});

// logout API
app.post('/logout', function(req, res) {
    const access_key = req.body.access_key;
    
    // delete access key from redis
    client.del(access_key, function(err, reply) {
        if (err) {
            console.error(err);
            res.sendStatus(500);
        }
        else if (reply == 0) {
            res.sendStatus(401);
        }
        else {
            res.status(200).send({message: "Logout successful!"});
        }
    });
});

// get member information API
app.get('/memberinfo', function(req, res) {
    const access_key = req.query.access_key;
    
    // get member information from redis
    client.get(access_key, function(err, reply) {
        if (err) {
            console.error(err);
            res.sendStatus(500);
        }
        else if (!reply) {
            res.sendStatus(401);
        }
        else {
            res.status(200).send({memberinfo: reply});
        }
    });
});

// search with address API
app.get('/zebra', function(req, res) {
    const address = req.query.address;
    
    // get geolocation from address using geoip-lite
    const geo = geoip.lookup(address);
    
    if (!geo) {
        res.status(404).send({message: "Geolocation not found!"});
    }
    else {
        res.status(200).send(geo);
    }
});

// add mark to geolocation API
app.post('/giraffe', function(req, res) {
    const access_key = req.body.access_key;
    const name = req.body.name;
    const coordinates = req.body.coordinates;
    
    // create new mark in redis
    const mark = {
        name: name,
        coordinates: coordinates
    };
    
    client.hset(access_key, name, JSON.stringify(mark), function(err, reply) {
        if (err) {
            console.error(err);
            res.sendStatus(500);
        }
        else {
            res.status(200).send({message: "Mark added successfully!"});
        }
    });
});

// share link to other people API
app.get('/rhinoceros', function(req, res) {
    const access_key = req.query.access_key;
    
    // generate link to the user's geolocation marks
    client.hgetall(access_key, function(err, reply) {
        if (err) {
            console.error(err);
            res.sendStatus(500);
        }
        else if (!reply) {
            res.sendStatus(401);
        }
        else {
            const link = "https://example.com/map/" + access_key;
            res.status(200).send({link: link});
        }
    });
});

// serve saved file API
app.get('/cat', function(req, res) {
    const file = req.query.file;
    const path = __dirname + "/files/" + file;
    
    // read file and send as response
    fs.readFile(path, function(err, data) {
        if (err) {
            console.error(err);
            res.sendStatus(404);
        }
        else {
            res.status(200).send(data);
        }
    });
});

// server listening
app.listen(3000, function() {
    console.log('Server listening on port 3000');
});