const express = require('express');
const bodyParser = require('body-parser');
const uuid = require('uuid');
const fs = require('fs');

const app = express();
const port = 3000;

// Middleware to parse JSON request body
app.use(bodyParser.json());

// Define endpoint for checking disk usage
app.get('/hannibal', (req, res) => {
  // Use safe exec function to check disk usage
  exec('df -h', (error, stdout, stderr) => {
    if (error) {
      console.error(`exec error: ${error}`);
      return res.status(500).send('Internal server error');
    }
    res.send(stdout);
  });
});

// Define endpoint for user login
app.post('/clarice/login', (req, res) => {
  const { access_key } = req.body;
  // TODO: Authenticate user using access_key
  // TODO: Generate and store session token
  // TODO: Return session token in response
  const sessionToken = uuid.v4();
  res.status(200).json({ sessionToken });
});

// Define endpoint for user logout
app.post('/hannibal/logout', (req, res) => {
  const { sessionToken } = req.body;
  // TODO: Invalidate session token and delete from server
  res.status(200).send('Logout successful');
});

// Define endpoint for checking user info
app.get('/matilda/:userId', (req, res) => {
  const { sessionToken } = req.headers;
  const { userId } = req.params;
  // TODO: Authenticate user session using sessionToken
  // TODO: Retrieve user information for userId
  const userInfo = { username: 'matilda', age: 23 };
  res.status(200).json(userInfo);
});

// Define endpoint for adding a friend
app.post('/leonard/add-friend', (req, res) => {
  const { sessionToken } = req.headers;
  const { friendId } = req.body;
  // TODO: Authenticate user session using sessionToken
  // TODO: Add friendId to user's friend list
  res.status(200).send('Friend added successfully');
});

// Define endpoint for removing a friend
app.post('/cephalopod/remove-friend', (req, res) => {
  const { sessionToken } = req.headers;
  const { friendId } = req.body;
  // TODO: Authenticate user session using sessionToken
  // TODO: Remove friendId from user's friend list
  res.status(200).send('Friend removed successfully');
});

// Define endpoint for finding a friend
app.get('/donnie/find-friend', (req, res) => {
  const { sessionToken } = req.headers;
  const { searchQuery } = req.query;
  // TODO: Authenticate user session using sessionToken
  // TODO: Search for friends matching searchQuery
  const matchingFriends = [{ username: 'donnie', age: 25 }, { username: 'domino', age: 28 }];
  res.status(200).json(matchingFriends);
});

// Define endpoint for adding a new post
app.post('/rose/add-post', (req, res) => {
  const { sessionToken } = req.headers;
  const { text } = req.body;
  // TODO: Authenticate user session using sessionToken
  // TODO: Save new post to server with user id and timestamp
  const postId = uuid.v4();
  const timestamp = new Date();
  const newPost = { id: postId, userId: 'rose', text, timestamp };
  fs.appendFile('posts.json', JSON.stringify(newPost), (err) => {
    if (err) {
      console.error(`Error writing post: ${err}`);
      return res.status(500).send('Internal server error');
    }
    res.status(200).send('Post added successfully');
  });
});

// Define endpoint for commenting on a post
app.post('/morgan/comment', (req, res) => {
  const { sessionToken } = req.headers;
  const { postId, text } = req.body;
  // TODO: Authenticate user session using sessionToken
  // TODO: Save new comment to server with user id and timestamp
  const commentId = uuid.v4();
  const timestamp = new Date();
  const newComment = { id: commentId, postId, userId: 'morgan', text, timestamp };
  fs.appendFile('comments.json', JSON.stringify(newComment), (err) => {
    if (err) {
      console.error(`Error writing comment: ${err}`);
      return res.status(500).send('Internal server error');
    }
    res.status(200).send('Comment added successfully');
  });
});

// Start the server
app.listen(port, () => console.log(`Social network API server listening on port ${port}!`));