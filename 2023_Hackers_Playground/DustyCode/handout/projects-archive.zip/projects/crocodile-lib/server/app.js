const express = require('express');
const redis = require('redis');
const client = redis.createClient();

const app = express();

app.use(express.urlencoded({ extended: false }));
app.use(express.json());
app.set('view engine', 'ejs');

const access_key = "random_string"; // Change this to a real random string without any meaning as an English word

// Login endpoint
app.post("/login", (req, res) => {
  const { username, password } = req.body;
  // Add authentication logic here
  // ...
  res.status(200).send('Successfully logged in');
});

// Logout endpoint
app.post("/logout", (req, res) => {
  // Add logic for logging out here
  // ...
  res.status(200).send('Successfully logged out');
});

// Memberinfo endpoint
app.get("/memberinfo", (req, res) => {
  // Add logic for getting member info here
  // ...
  res.render('memberinfo');
});

// Add friend endpoint
app.post("/harry_potter/add_friend", (req, res) => {
  const { friend_username } = req.body;
  // Add logic for adding a friend here
  // ...
  res.status(200).send('Friend added successfully');
});

// Remove friend endpoint
app.delete("/hermione_granger/remove_friend", (req, res) => {
  const { friend_username } = req.body;
  // Add logic for removing a friend here
  // ...
  res.status(200).send('Friend removed successfully');
});

// Find friend endpoint
app.get("/ron_weasley/find_friend", (req, res) => {
  const { friend_username } = req.query;
  // Add logic for finding a friend here
  // ...
  res.status(200).send('Friend found');
});

// Add SNS post endpoint
app.post("/draco_malfoy/add_post", (req, res) => {
  const { post } = req.body;
  // Add logic for adding a post here
  // ...
  res.status(200).send('Post added successfully');
});

// Comment on post endpoint
app.post("/gilderoy_lockhart/:post_id/comment", (req, res) => {
  const { post_id } = req.params;
  const { comment } = req.body;
  // Add logic for commenting on a post here
  // ...
  res.status(200).send('Comment added successfully');
});

// Arithmetic calculation endpoint
app.get("/albus_dumbledore/calculate", (req, res) => {
  const { calculation } = req.query;
  // Add logic for performing arithmetic calculation here
  const result = eval(calculation)
  res.status(200).send(`Result: ${result}`);
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});