const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const AWS = require('aws-sdk');
const fs = require('fs');

const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

const s3 = new AWS.S3({
  accessKeyId: '<your-access-key>',
  secretAccessKey: '<your-secret-key>',
});

const CACHE_BUCKET_NAME = 'web-cache-bucket';

const writeToFile = (filename, contents) => {
  fs.writeFile(filename, contents, (err) => {
    if (err) {
      console.log(`Error writing to file ${filename}:`, err);
    } else {
      console.log(`Successfully wrote to file ${filename}`);
    }
  });
};

const readFromFile = (filename, callback) => {
  fs.readFile(filename, 'utf-8', (err, data) => {
    if (err) {
      console.log(`Error reading from file ${filename}:`, err);
      callback(null);
    } else {
      console.log(`Successfully read from file ${filename}`);
      callback(data);
    }
  });
};

app.get('/taco', (req, res) => {
  res.render('index');
});

app.post('/taco', (req, res) => {
  const url = req.body.url;
  const cacheId = req.body.cacheId;

  if (cacheId) {
    // check if cache id exists in S3
    s3.getObject({
      Bucket: CACHE_BUCKET_NAME,
      Key: cacheId,
    }, (err, data) => {
      if (err) {
        console.log(`Error fetching cache with id ${cacheId}`);
        res.send('Cache with that id does not exist!');
      } else {
        console.log(`Successfully fetched cache with id ${cacheId}`);
        res.send(data.Body.toString());
      }
    });
  } else {
    // fetch data from url and write to S3
    const params = {
      Bucket: CACHE_BUCKET_NAME,
      Key: Date.now().toString(), // generate unique id
      Body: '',
    };

    const request = require('request');
    request(url, (err, response, body) => {
      if (err) {
        console.log('Error fetching web page:', err);
        res.send('Error fetching web page');
      } else {
        console.log('Successfully fetched web page');
        // save data to S3
        params.Body = body;
        s3.upload(params, (err, data) => {
          if (err) {
            console.log('Error storing cache:', err);
            res.send('Error storing cache');
          } else {
            console.log(`Successfully stored cache with id ${params.Key}`);
            // send cache id to client
            res.send(params.Key);
          }
        });
      }
    });
  }
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});