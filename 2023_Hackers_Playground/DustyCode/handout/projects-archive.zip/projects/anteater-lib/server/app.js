const http = require('http');
const url = require('url');
const redis = require('redis');
const fs = require('fs');
const querystring = require('querystring');

const redisClient = redis.createClient(); // Create Redis client

// In-memory storage for access keys and logged-in users
let accessKeys = {};
let loggedInUsers = {};

// Generate random string for access key
const generateAccessKey = () => {
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let rnd = '';
  for (let i = 0; i < 32; i++) {
    rnd += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return rnd;
};

// Authenticate user with access key
const authenticateUser = (accessKey) => {
  return accessKeys[accessKey] || null;
};

const server = http.createServer((req, res) => {
  const reqUrl = url.parse(req.url, true);
  const reqMethod = req.method.toLowerCase(); // Convert method to lowercase

  // Login endpoint
  if (reqUrl.pathname === '/luke' && reqMethod === 'post') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });

    req.on('end', () => {
      const data = querystring.parse(body);

      // Check if username and password are correct
      if (data.username === 'admin' && data.password === 'password') {
        const accessKey = generateAccessKey();
        accessKeys[accessKey] = 'admin'; // Store access key for user
        loggedInUsers['admin'] = accessKey; // Store logged-in user
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ success: true, access_key: accessKey }));
      } else {
        res.writeHead(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid username or password' }));
      }
    });
  } 
  // Logout endpoint
  else if (reqUrl.pathname === '/han' && reqMethod === 'get') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      const username = authenticateUser(accessKey);
      delete loggedInUsers[username]; // Remove logged-in user
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ success: true }));
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Member info check endpoint
  else if (reqUrl.pathname === '/leia' && reqMethod === 'get') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      const username = authenticateUser(accessKey);
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ username: username }));
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Blog creation endpoint
  else if (reqUrl.pathname === '/padme' && reqMethod === 'post') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString();
      });

      req.on('end', () => {
        const data = querystring.parse(body);
        const blogData = {
          title: data.title || '',
          content: data.content || '',
          author: authenticateUser(accessKey)
        };
        const id = Math.floor(Math.random() * 1000000); // Generate random ID
        redisClient.hset('blogs', id, JSON.stringify(blogData), (err, reply) => {
          if (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Error creating blog' }));
          } else {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true, id: id }));
          }
        });
      });
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Blog editing endpoint
  else if (reqUrl.pathname === '/elsa' && reqMethod === 'put') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      const blogId = reqUrl.query.id;
      if (!blogId) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing blog ID' }));
        return;
      }

      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString();
      });

      req.on('end', () => {
        const data = querystring.parse(body);
        redisClient.hget('blogs', blogId, (err, reply) => {
          if (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Error updating blog' }));
          } else if (!reply) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Blog not found' }));
          } else {
            const blogData = JSON.parse(reply);
            if (authenticateUser(accessKey) !== blogData.author) {
              res.writeHead(401, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Unauthorized' }));
              return;
            }

            blogData.title = data.title || blogData.title;
            blogData.content = data.content || blogData.content;

            redisClient.hset('blogs', blogId, JSON.stringify(blogData), (err, reply) => {
              if (err) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Error updating blog' }));
              } else {
                res.writeHead(200, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ success: true }));
              }
            });
          }
        });
      });
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Blog deletion endpoint
  else if (reqUrl.pathname === '/simba' && reqMethod === 'delete') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      const blogId = reqUrl.query.id;
      if (!blogId) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing blog ID' }));
        return;
      }

      redisClient.hget('blogs', blogId, (err, reply) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Error deleting blog' }));
        } else if (!reply) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Blog not found' }));
        } else {
          const blogData = JSON.parse(reply);
          if (authenticateUser(accessKey) !== blogData.author) {
            res.writeHead(401, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Unauthorized' }));
            return;
          }

          redisClient.hdel('blogs', blogId, (err, reply) => {
            if (err) {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Error deleting blog' }));
            } else {
              res.writeHead(200, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ success: true }));
            }
          });
        }
      });
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Add blog neighbor endpoint
  else if (reqUrl.pathname === '/ariel' && reqMethod === 'post') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      const blogId = reqUrl.query.id;
      if (!blogId) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing blog ID' }));
        return;
      }

      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString();
      });

      req.on('end', () => {
        const data = querystring.parse(body);
        redisClient.hget('blogs', blogId, (err, reply) => {
          if (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Error adding neighbor' }));
          } else if (!reply) {
            res.writeHead(404, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Blog not found' }));
          } else {
            const blogData = JSON.parse(reply);
            if (authenticateUser(accessKey) !== blogData.author) {
              res.writeHead(401, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Unauthorized' }));
              return;
            }

            const neighborId = Math.floor(Math.random() * 1000000);
            const neighborData = {
              title: data.title || '',
              blog_id: blogId,
              author: authenticateUser(accessKey)
            };
            
            // Add neighbor data to Redis
            redisClient.hset('neighbors', neighborId, JSON.stringify(neighborData), (err, reply) => {
              if (err) {
                res.writeHead(500, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Error adding neighbor' }));
              } else {
                const neighbors = blogData.neighbors || [];
                neighbors.push(neighborId);
                blogData.neighbors = neighbors;

                // Update blog data with new neighbor
                redisClient.hset('blogs', blogId, JSON.stringify(blogData), (err, reply) => {
                  if (err) {
                    redisClient.hdel('neighbors', neighborId, (err, reply) => {
                      res.writeHead(500, { 'Content-Type': 'application/json' });
                      res.end(JSON.stringify({ error: 'Error adding neighbor' }));
                    });
                  } else {
                    res.writeHead(200, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ success: true }));
                  }
                });
              }
            });
          }
        });
      });
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Remove blog neighbor endpoint
  else if (reqUrl.pathname === '/baloo' && reqMethod === 'delete') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      const neighborId = reqUrl.query.id;
      if (!neighborId) {
        res.writeHead(400, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Missing neighbor ID' }));
        return;
      }

      redisClient.hget('neighbors', neighborId, (err, reply) => {
        if (err) {
          res.writeHead(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Error removing neighbor' }));
        } else if (!reply) {
          res.writeHead(404, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: 'Neighbor not found' }));
        } else {
          const neighborData = JSON.parse(reply);
          redisClient.hget('blogs', neighborData.blog_id, (err, reply) => {
            if (err) {
              res.writeHead(500, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Error removing neighbor' }));
            } else if (!reply) {
              res.writeHead(404, { 'Content-Type': 'application/json' });
              res.end(JSON.stringify({ error: 'Blog not found' }));
            } else {
              const blogData = JSON.parse(reply);
              if (authenticateUser(accessKey) !== blogData.author) {
                res.writeHead(401, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Unauthorized' }));
                return;
              }

              const neighbors = blogData.neighbors || [];
              const index = neighbors.indexOf(parseInt(neighborId));
              if (index === -1) {
                res.writeHead(404, { 'Content-Type': 'application/json' });
                res.end(JSON.stringify({ error: 'Neighbor not found' }));
              } else {
                neighbors.splice(index, 1);
                blogData.neighbors = neighbors;

                // Remove neighbor data from Redis
                redisClient.hdel('neighbors', neighborId, (err, reply) => {
                  if (err) {
                    res.writeHead(500, { 'Content-Type': 'application/json' });
                    res.end(JSON.stringify({ error: 'Error removing neighbor' }));
                  } else {
                    // Update blog data without removed neighbor
                    redisClient.hset('blogs', neighborData.blog_id, JSON.stringify(blogData), (err, reply) => {
                      if (err) {
                        res.writeHead(500, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ error: 'Error removing neighbor' }));
                      } else {
                        res.writeHead(200, { 'Content-Type': 'application/json' });
                        res.end(JSON.stringify({ success: true }));
                      }
                    });
                  }
                });
              }
            }
          });
        }
      });
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  // Write file endpoint
  else if (reqUrl.pathname === '/simon' && reqMethod === 'post') {
    const accessKey = req.headers.authorization || null;
    if (accessKey && authenticateUser(accessKey)) {
      let body = '';
      req.on('data', (chunk) => {
        body += chunk.toString();
      });

      req.on('end', () => {
        const data = querystring.parse(body);
        const filename = data.filename;
        const fileContent = data.content;

        fs.writeFile(filename, fileContent, (err) => {
          if (err) {
            res.writeHead(500, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ error: 'Error writing file' }));
          } else {
            res.writeHead(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ success: true }));
          }
        });
      });
    } else {
      res.writeHead(401, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Unauthorized' }));
    }
  } 
  else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found');
  }
});

server.listen(3000, () => {
  console.log('Server is listening on port 3000');
});