const http = require('http')
const { parse } = require('url')

const accessKeys = new Set(['random_string_1', 'random_string_2'])
const posts = []
const neighbors = []
const adminAccessKey = 'super_secret_key'

function authenticate(req) {
  const accessKey = parse(req.url, true).query.access_key
  return accessKeys.has(accessKey)
}

function isAdmin(req) {
  const accessKey = parse(req.url, true).query.access_key
  return accessKey === adminAccessKey
}

function findPostIndex(id) {
  return posts.findIndex(post => post.id === id)
}

function findNeighborIndex(name) {
  return neighbors.findIndex(neighbor => neighbor.name === name)
}

function sendUnauthorized(res) {
  res.statusCode = 401
  res.end('Unauthorized')
}

function sendNotFound(res) {
  res.statusCode = 404
  res.end('Not found')
}

function sendInternalServerError(res) {
  res.statusCode = 500
  res.end('Internal server error')
}

function sendJson(res, data) {
  res.setHeader('Content-Type', 'application/json')
  res.end(JSON.stringify(data))
}

function addPost(req, res) {
  if (!authenticate(req)) {
    sendUnauthorized(res)
    return
  }

  let body = ''
  req.on('data', chunk => {
    body += chunk
  })
  req.on('end', () => {
    try {
      const { title, content } = JSON.parse(body)
      const id = Date.now().toString()
      const post = { id, title, content }
      posts.push(post)
      sendJson(res, post)
    } catch (error) {
      sendInternalServerError(res)
    }
  })
}

function editPost(req, res) {
  if (!authenticate(req)) {
    sendUnauthorized(res)
    return
  }

  let body = ''
  req.on('data', chunk => {
    body += chunk
  })
  req.on('end', () => {
    try {
      const { id, title, content } = JSON.parse(body)
      const index = findPostIndex(id)

      if (index === -1) {
        sendNotFound(res)
        return
      }

      const post = posts[index]

      if (!isAdmin(req) && post.author !== parse(req.url, true).query.author) {
        sendUnauthorized(res)
        return
      }

      post.title = title
      post.content = content
      sendJson(res, post)
    } catch (error) {
      sendInternalServerError(res)
    }
  })
}

function removePost(req, res) {
  if (!authenticate(req)) {
    sendUnauthorized(res)
    return
  }

  const id = parse(req.url, true).query.id
  const index = findPostIndex(id)

  if (index === -1) {
    sendNotFound(res)
    return
  }

  const post = posts[index]

  if (!isAdmin(req) && post.author !== parse(req.url, true).query.author) {
    sendUnauthorized(res)
    return
  }

  posts.splice(index, 1)
  res.end('Post removed successfully')
}

function addNeighbor(req, res) {
  if (!authenticate(req)) {
    sendUnauthorized(res)
    return
  }

  const { name, url } = parse(req.url, true).query
  const index = findNeighborIndex(name)

  if (index !== -1) {
    sendJson(res, neighbors[index])
    return
  }

  const neighbor = { name, url }
  neighbors.push(neighbor)
  sendJson(res, neighbor)
}

function removeNeighbor(req, res) {
  if (!authenticate(req)) {
    sendUnauthorized(res)
    return
  }

  const name = parse(req.url, true).query.name
  const index = findNeighborIndex(name)

  if (index === -1) {
    sendNotFound(res)
    return
  }

  neighbors.splice(index, 1)
  sendJson(res, neighbors)
}

function safeExec(req, res) {
  if (!isAdmin(req)) {
    sendUnauthorized(res)
    return
  }

  // execute safe command to check disk usage and return the result
}

const server = http.createServer((req, res) => {
  const { pathname } = parse(req.url, true)

  if (pathname === '/post/add') {
    addPost(req, res)
  } else if (pathname === '/post/edit') {
    editPost(req, res)
  } else if (pathname === '/post/remove') {
    removePost(req, res)
  } else if (pathname === '/neighbor/add') {
    addNeighbor(req, res)
  } else if (pathname === '/neighbor/remove') {
    removeNeighbor(req, res)
  } else if (pathname === '/safeexec') {
    safeExec(req, res)
  } else {
    sendNotFound(res)
  }
})

server.listen(3000, () => {
  console.log('Server started on port 3000')
})