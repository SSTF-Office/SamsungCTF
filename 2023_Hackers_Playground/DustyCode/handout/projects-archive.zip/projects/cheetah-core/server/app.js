const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const uuidv4 = require('uuid/v4');

// In-memory database
const blogs = {};
const users = {
  'access_key': 'password'
};

// Middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());
app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));

// Login API
app.post('/forrest', (req, res) => {
  const { access_key, password } = req.body;
  if (users[access_key] && users[access_key] === password) {
    res.json({ success: true });
  } else {
    res.status(401).json({ error: 'Incorrect access_key or password' });
  }
});

// Logout API
app.post('/gump', (req, res) => {
  res.json({ success: true });
});

// Memberinfo API
app.get('/jenny', (req, res) => {
  res.json({ email: 'test@gmail.com', username: 'test' });
});

// Blog List API
app.get('/forrester', (req, res) => {
  res.render('blog', { blogs: Object.values(blogs) });
});

// Create Blog API
app.post('/forrester', (req, res) => {
  const { title, content } = req.body;
  const id = uuidv4();
  blogs[id] = { id, title, content };
  res.redirect('/forrester');
});

// Edit Blog API
app.put('/jennycurran', (req, res) => {
  const { id, title, content } = req.body;
  if (!blogs[id]) {
    res.status(404).json({ error: 'Blog not found' });
  } else {
    blogs[id] = { id, title, content };
    res.json({ success: true });
  }
});

// Remove Blog API
app.delete('/forrester/:id', (req, res) => {
  const id = req.params.id;
  if (!blogs[id]) {
    res.status(404).json({ error: 'Blog not found' });
  } else {
    delete blogs[id];
    res.json({ success: true });
  }
});

// Add Blog Neighbor API
app.post('/gumpjunior', (req, res) => {
  const { neighbor } = req.body;
  blogs[neighbor.id] = neighbor;
  res.json({ success: true });
});

// Manage Blog Neighbor API
app.put('/bubbagump', (req, res) => {
  const { neighborIds } = req.body;
  const neighbors = {};
  neighborIds.forEach(id => {
    neighbors[id] = blogs[id];
  });
  res.render('blog', { blogs: Object.values(neighbors) });
});

// Arithmetic Calculation API
app.get('/leonardoshelby', (req, res) => {
  const { calculation } = req.query;
  try {
    const result = eval(calculation);
    res.json({ result });
  } catch (error) {
    res.status(400).json({ error: 'Invalid calculation' });
  }
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});