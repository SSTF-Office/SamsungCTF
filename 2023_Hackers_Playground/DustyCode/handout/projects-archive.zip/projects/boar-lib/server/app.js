const Hapi = require('hapi');
const Joi = require('joi');
const fetch = require('node-fetch');
const AWS = require('aws-sdk');
const exec = require('child_process').exec;

// AWS object storage configuration
AWS.config.update({
    accessKeyId: 'AWS_ACCESS_KEY_ID',
    secretAccessKey: 'AWS_SECRET_ACCESS_KEY'
});

const s3 = new AWS.S3();

// Create a server with a host and port
const server = new Hapi.Server({
    host: 'localhost',
    port: 3000
});

// Route for fetching and caching a web page
server.route({
    method: 'POST',
    path: '/cachepage',
    handler: async (request, h) => {
        const { url } = request.payload;

        // Use a safe exec function to check disk usage before caching
        const usage = await safeExec('df -h /');
        console.log(`Disk usage: ${usage}`);

        // Check if there is already a cached version of the page
        let cacheId;
        try {
            cacheId = await getCacheId(url);
        } catch (err) {
            console.error(`Error getting cache ID: ${err.message}`);
        }
        if (cacheId) {
            console.log(`Using cache ID: ${cacheId}`);

            // Retrieve cached page contents
            const cachedContents = await getCachedContents(cacheId);
            return {
                cacheId,
                contents: cachedContents
            };
        }

        // Fetch page contents from the web
        const response = await fetch(url);
        const contents = await response.text();

        // Generate a unique ID for the cache
        cacheId = generateCacheId(url);

        // Upload contents to object storage
        try {
            await uploadToS3(cacheId, contents);
        } catch (err) {
            console.error(`Error uploading to S3: ${err.message}`);
        }

        return {
            cacheId,
            contents
        };
    },
    options: {
        validate: {
            payload: {
                url: Joi.string().uri().required()
            }
        }
    }
});

// Helper function to safely execute a shell command
function safeExec(command) {
    return new Promise((resolve, reject) => {
        exec(command, (error, stdout, stderr) => {
            if (error) {
                reject(error);
            } else {
                resolve(stdout);
            }
        });
    });
}

// Helper function to generate a unique cache ID
function generateCacheId(url) {
    return `cache-${new Date().getTime()}-${url.replace(/[^a-zA-Z0-9]/g, '')}`;
}

// Helper function to get the ID of a cached page for a given URL
async function getCacheId(url) {
    const listParams = {
        Bucket: 'my-caching-bucket',
        Prefix: `cache-${url.replace(/[^a-zA-Z0-9]/g, '')}`
    };
    const result = await s3.listObjectsV2(listParams).promise();
    if (result.Contents.length > 0) {
        return result.Contents[0].Key;
    } else {
        return null;
    }
}

// Helper function to retrieve the contents of a cached page for a given ID
async function getCachedContents(cacheId) {
    const getObjectParams = {
        Bucket: 'my-caching-bucket',
        Key: cacheId
    };
    const result = await s3.getObject(getObjectParams).promise();
    return result.Body.toString();
}

// Helper function to upload page contents to object storage
async function uploadToS3(cacheId, contents) {
    const uploadParams = {
        Bucket: 'my-caching-bucket',
        Key: cacheId,
        Body: contents
    };
    await s3.upload(uploadParams).promise();
}

// Start the server
const start = async () => {

    await server.start();
    console.log(`Server running at: ${server.info.uri}`);
};

start();