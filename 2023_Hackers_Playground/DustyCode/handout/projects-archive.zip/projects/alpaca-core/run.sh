#/bin/bash

sudo docker compose up -d