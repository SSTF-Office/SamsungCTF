const express = require('express');
const ejs = require('ejs');
const redis = require('redis');
const uuid = require('uuid/v4');
const bodyParser = require('body-parser');
const fs = require('fs');

const app = express();
const client = redis.createClient();

app.use(express.static('public'));
app.set('view engine', 'ejs');
app.set('views', './views');
app.use(bodyParser.urlencoded({ extended: false }));

// Helper function to generate random access keys
function generateAccessKey() {
  return uuid();
}

// Middleware to check if user is authenticated
function isAuthenticated(req, res, next) {
  const accessKey = req.headers.access_key;
  if (accessKey) {
    client.get(accessKey, (error, result) => {
      if (result) {
        next();
      } else {
        res.status(401).send('Unauthorized');
      }
    });
  } else {
    res.status(401).send('Unauthorized');
  }
}

// Route to generate new access key
app.get('/pennywise', (req, res) => {
  const accessKey = generateAccessKey();
  client.set(accessKey, 'true');
  res.send(accessKey);
});

// Route to login with access key
app.post('/scar', (req, res) => {
  const accessKey = req.body.access_key;
  client.get(accessKey, (error, result) => {
    if (result) {
      res.send('Logged in');
    } else {
      res.status(401).send('Unauthorized');
    }
  });
});

// Route to logout with access key
app.post('/ghostface', (req, res) => {
  const accessKey = req.headers.access_key;
  client.del(accessKey);
  res.send('Logged out');
});

// Route to get member info
app.get('/batman', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  client.get(accessKey, (error, result) => {
    if (result) {
      res.send('Member Info: ' + result);
    } else {
      res.status(401).send('Unauthorized');
    }
  });
});

// Route to write post to file
app.post('/harrypotter', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const content = req.body.content;
  const fileName = 'posts.txt';

  fs.appendFile(fileName, `[${accessKey}] ${content}\n`, (err) => {
    if (err) {
      res.status(500).send('Error writing to file');
    } else {
      res.send('Post written to file');
    }
  });
});

// Route to get all posts
app.get('/forrestgump', (req, res) => {
  const fileName = 'posts.txt';

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      const posts = [];

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          posts.push({
            accessKey: parts[0].substr(1),
            content: parts[1].trim(),
          });
        }
      }

      res.render('posts', { posts });
    }
  });
});

// Route to delete post
app.delete('/terminator/:id', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.id;
  const fileName = 'posts.txt';

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      let deleted = false;

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          if (postId === i.toString() && parts[0].substr(1) === accessKey) {
            lines.splice(i, 1);
            deleted = true;
            break;
          }
        }
      }

      if (deleted) {
        fs.writeFile(fileName, lines.join('\n'), (err) => {
          if (err) {
            res.status(500).send('Error writing to file');
          } else {
            res.send('Post deleted');
          }
        });
      } else {
        res.status(404).send('Post not found');
      }
    }
  });
});

// Route to edit post
app.put('/mavrick/:id', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.id;
  const content = req.body.content;
  const fileName = 'posts.txt';

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      let edited = false;

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          if (postId === i.toString() && parts[0].substr(1) === accessKey) {
            lines[i] = `[${accessKey}] ${content}`;
            edited = true;
            break;
          }
        }
      }

      if (edited) {
        fs.writeFile(fileName, lines.join('\n'), (err) => {
          if (err) {
            res.status(500).send('Error writing to file');
          } else {
            res.send('Post edited');
          }
        });
      } else {
        res.status(404).send('Post not found');
      }
    }
  });
});

// Route to add comment to post
app.post('/olaf/:postId/comments', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.postId;
  const content = req.body.content;
  const fileName = `comments-${postId}.txt`;

  fs.appendFile(fileName, `[${accessKey}] ${content}\n`, (err) => {
    if (err) {
      res.status(500).send('Error writing to file');
    } else {
      res.send('Comment added');
    }
  });
});

// Route to delete comment from post
app.delete('/nemo/:postId/comments/:commentId', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.postId;
  const commentId = req.params.commentId;
  const fileName = `comments-${postId}.txt`;

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      let deleted = false;

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          if (commentId === i.toString() && parts[0].substr(1) === accessKey) {
            lines.splice(i, 1);
            deleted = true;
            break;
          }
        }
      }

      if (deleted) {
        fs.writeFile(fileName, lines.join('\n'), (err) => {
          if (err) {
            res.status(500).send('Error writing to file');
          } else {
            res.send('Comment deleted');
          }
        });
      } else {
        res.status(404).send('Comment not found');
      }
    }
  });
});

// Route to edit comment from post
app.put('/zorro/:postId/comments/:commentId', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.postId;
  const commentId = req.params.commentId;
  const content = req.body.content;
  const fileName = `comments-${postId}.txt`;

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      let edited = false;

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          if (commentId === i.toString() && parts[0].substr(1) === accessKey) {
            lines[i] = `[${accessKey}] ${content}`;
            edited = true;
            break;
          }
        }
      }

      if (edited) {
        fs.writeFile(fileName, lines.join('\n'), (err) => {
          if (err) {
            res.status(500).send('Error writing to file');
          } else {
            res.send('Comment edited');
          }
        });
      } else {
        res.status(404).send('Comment not found');
      }
    }
  });
});

// Route to add reply to comment in post
app.post('/tigger/:postId/comments/:commentId/replies', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.postId;
  const commentId = req.params.commentId;
  const content = req.body.content;
  const fileName = `replies-${postId}-${commentId}.txt`;

  fs.appendFile(fileName, `[${accessKey}] ${content}\n`, (err) => {
    if (err) {
      res.status(500).send('Error writing to file');
    } else {
      res.send('Reply added');
    }
  });
});

// Route to delete reply from comment in post
app.delete('/ironman/:postId/comments/:commentId/replies/:replyId', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.postId;
  const commentId = req.params.commentId;
  const replyId = req.params.replyId;
  const fileName = `replies-${postId}-${commentId}.txt`;

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      let deleted = false;

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          if (replyId === i.toString() && parts[0].substr(1) === accessKey) {
            lines.splice(i, 1);
            deleted = true;
            break;
          }
        }
      }

      if (deleted) {
        fs.writeFile(fileName, lines.join('\n'), (err) => {
          if (err) {
            res.status(500).send('Error writing to file');
          } else {
            res.send('Reply deleted');
          }
        });
      } else {
        res.status(404).send('Reply not found');
      }
    }
  });
});

// Route to edit reply from comment in post
app.put('/minion/:postId/comments/:commentId/replies/:replyId', isAuthenticated, (req, res) => {
  const accessKey = req.headers.access_key;
  const postId = req.params.postId;
  const commentId = req.params.commentId;
  const replyId = req.params.replyId;
  const content = req.body.content;
  const fileName = `replies-${postId}-${commentId}.txt`;

  fs.readFile(fileName, 'utf8', (err, data) => {
    if (err) {
      res.status(500).send('Error reading file');
    } else {
      const lines = data.split('\n');
      let edited = false;

      for (let i = 0, len = lines.length; i < len; i++) {
        if (lines[i]) {
          const parts = lines[i].split('] ');
          if (replyId === i.toString() && parts[0].substr(1) === accessKey) {
            lines[i] = `[${accessKey}] ${content}`;
            edited = true;
            break;
          }
        }
      }

      if (edited) {
        fs.writeFile(fileName, lines.join('\n'), (err) => {
          if (err) {
            res.status(500).send('Error writing to file');
          } else {
            res.send('Reply edited');
          }
        });
      } else {
        res.status(404).send('Reply not found');
      }
    }
  });
});

// Start server
app.listen(3000, () => {
  console.log('Server running on port 3000');
});