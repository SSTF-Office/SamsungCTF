const express = require('express');
const session = require('express-session');
const redis = require('redis');
const redisStore = require('connect-redis')(session);
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');
const ejs = require('ejs');
const { evalExpr } = require('eval-expr');

const app = express();
const client = redis.createClient();

app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

app.set('view engine', 'ejs');
app.use(express.static(__dirname + '/public'));

app.use(session({
  genid: function(req) {
    return uuidv4();
  },
  secret: 'mysecretkey',
  resave: false,
  saveUninitialized: false,
  store: new redisStore({ host: 'localhost', port: 6379, client: client, ttl: 86400 })
}));

// authentication middleware
const authenticate = (req, res, next) => {
  const access_key = req.query.access_key || req.body.access_key || req.session.access_key;
  
  if (access_key) {
    // perform authentication here
    next();
  }
  else {
    res.status(401).json({ error: 'Unauthorized access' });
  }
};

// login API endpoint
app.post('/login', (req, res) => {
  const access_key = req.body.access_key;
  
  // perform login authentication here
  if (access_key) {
    req.session.access_key = access_key;
    res.status(200).json({ message: 'Successfully logged in' });
  }
  else {
    res.status(401).json({ error: 'Invalid access key' });
  }
});

// logout API endpoint
app.post('/logout', (req, res) => {
  req.session.destroy();
  res.status(200).json({ message: 'Successfully logged out' });
});

// member information API endpoint
app.get('/members/:id', authenticate, (req, res) => {
  const member_id = req.params.id;
  
  // fetch member information from database here
  res.status(200).json({ id: member_id, name: 'John Smith', age: 25 });
});

// add friend API endpoint
app.post('/addfriend', authenticate, (req, res) => {
  const friend_id = req.body.friend_id;
  
  // perform adding friend here
  res.status(200).json({ message: `Successfully added friend ${friend_id}` });
});

// remove friend API endpoint
app.post('/removefriend', authenticate, (req, res) => {
  const friend_id = req.body.friend_id;
  
  // perform removing friend here
  res.status(200).json({ message: `Successfully removed friend ${friend_id}` });
});

// find friend API endpoint
app.get('/findfriend/:name', authenticate, (req, res) => {
  const friend_name = req.params.name;
  
  // search for friend with name here
  res.status(200).json({ name: friend_name, age: 30, occupation: 'Teacher' });
});

// add sns post API endpoint
app.post('/addpost', authenticate, (req, res) => {
  const post_content = req.body.content;
  
  // add post to database here
  res.status(200).json({ message: 'Successfully added post', post_id: '12345' });
});

// comment on post API endpoint
app.post('/addcomment', authenticate, (req, res) => {
  const post_id = req.body.post_id;
  const comment_content = req.body.content;
  
  // add comment to post in database here
  res.status(200).json({ message: `Successfully added comment to post ${post_id}` });
});

// arithmetic calculation API endpoint
app.get('/calculate', authenticate, (req, res) => {
  const expr = req.query.expr;
  const result = evalExpr(expr);
  
  res.status(200).json({ expression: expr, result: result });
});

app.listen(3000, () => console.log('Server started on port 3000'));