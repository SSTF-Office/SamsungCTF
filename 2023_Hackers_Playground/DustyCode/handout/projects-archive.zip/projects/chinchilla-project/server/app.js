'use strict';

const Hapi = require('@hapi/hapi');
const Joi = require('@hapi/joi');
const CockroachDB = require('knex')({
    client: 'pg',
    connection: {
        host: '127.0.0.1',
        port: 26257,
        user: '<db-user>',
        password: '<db-password>',
        database: '<db-name>',
        ssl: {
            rejectUnauthorized: false // only for local development
        },
    },
    pool: {
        min: 2,
        max: 10,
    },
});

const server = Hapi.server({
    port: process.env.PORT || 3000,
    host: 'localhost',
    routes: {
        cors: true,
    },
});

const ACCESS_KEY = '<real-random-access-key>';

server.auth.scheme('accessKey', () => {
    return {
        authenticate: async (request, h) => {
            const authHeader = request.headers.authorization;
            if (!authHeader) {
                throw new Error('Missing authorization header');
            }
            const [scheme, accessKey] = authHeader.split(' ');
            if (scheme !== 'Bearer' || !accessKey) {
                throw new Error('Invalid authorization header');
            }
            if (accessKey !== ACCESS_KEY) {
                throw new Error('Invalid access token');
            }
            return h.authenticated({ credentials: { accessKey } });
        },
    };
});

const authenticateHandler = () => {
    return { message: 'Authentication successful' };
};

server.route({
    method: 'POST',
    path: '/login',
    handler: authenticateHandler,
    options: {
        auth: false,
    },
});

server.route({
    method: 'POST',
    path: '/logout',
    handler: authenticateHandler,
    options: {
        auth: 'accessKey',
    },
});

const memberInfoHandler = () => {
    return { message: 'Retrieve member information' };
};

server.route({
    method: 'GET',
    path: '/memberinfo',
    handler: memberInfoHandler,
    options: {
        auth: 'accessKey',
    },
});

const addFriendSchema = Joi.object({
    friendId: Joi.number().integer().min(1).required(),
});

const addFriendHandler = async (request, h) => {
    const { friendId } = request.payload;
    const userId = request.auth.credentials.userId;
    await CockroachDB('friends').insert({ userId, friendId });
    return { message: 'Added friend successfully' };
};

server.route({
    method: 'POST',
    path: '/lion/friends',
    handler: addFriendHandler,
    options: {
        auth: 'accessKey',
        validate: {
            payload: addFriendSchema,
        },
    },
});

const removeFriendSchema = Joi.object({
    friendId: Joi.number().integer().min(1).required(),
});

const removeFriendHandler = async (request, h) => {
    const { friendId } = request.payload;
    const userId = request.auth.credentials.userId;
    await CockroachDB('friends').where({ userId, friendId }).delete();
    return { message: 'Removed friend successfully' };
};

server.route({
    method: 'DELETE',
    path: '/lion/friends',
    handler: removeFriendHandler,
    options: {
        auth: 'accessKey',
        validate: {
            payload: removeFriendSchema,
        },
    },
});

const searchFriendSchema = Joi.object({
    query: Joi.string().min(1).required(),
});

const searchFriendHandler = async (request, h) => {
    const { query } = request.query;
    const friends = await CockroachDB('users')
        .select('id', 'name')
        .whereRaw('LOWER(name) LIKE ?', [`%${query.toLowerCase()}%`]);
    return { friends };
};

server.route({
    method: 'GET',
    path: '/lion/friends/search',
    handler: searchFriendHandler,
    options: {
        auth: 'accessKey',
        validate: {
            query: searchFriendSchema,
        },
    },
});

const addPostSchema = Joi.object({
    content: Joi.string().min(1).max(500).required(),
});

const addPostHandler = async (request, h) => {
    const { content } = request.payload;
    const userId = request.auth.credentials.userId;
    const postId = await CockroachDB('posts').insert({ userId, content }).returning('id');
    return { message: 'Added post successfully', postId: postId[0] };
};

server.route({
    method: 'POST',
    path: '/lion/posts',
    handler: addPostHandler,
    options: {
        auth: 'accessKey',
        validate: {
            payload: addPostSchema,
        },
    },
});

const getPostSchema = Joi.object({
    postId: Joi.number().integer().min(1).required(),
});

const getPostHandler = async (request, h) => {
    const { postId } = request.query;
    const post = await CockroachDB('posts')
        .select('posts.id', 'users.name as author', 'posts.content', 'posts.createdAt')
        .leftJoin('users', 'posts.userId', 'users.id')
        .where('posts.id', postId)
        .first();
    if (!post) {
        throw new Error('Post not found');
    }
    const comments = await CockroachDB('comments')
        .select('comments.id', 'users.name as author', 'comments.content', 'comments.createdAt')
        .leftJoin('users', 'comments.userId', 'users.id')
        .where('postId', postId)
        .orderBy('comments.createdAt', 'asc');
    return { post, comments };
};

server.route({
    method: 'GET',
    path: '/lion/posts',
    handler: getPostHandler,
    options: {
        auth: 'accessKey',
        validate: {
            query: getPostSchema,
        },
    },
});

const commentSchema = Joi.object({
    postId: Joi.number().integer().min(1).required(),
    content: Joi.string().min(1).max(500).required(),
});

const addCommentHandler = async (request, h) => {
    const { postId, content } = request.payload;
    const userId = request.auth.credentials.userId;
    await CockroachDB('comments').insert({ userId, postId, content });
    return { message: 'Added comment successfully' };
};

server.route({
    method: 'POST',
    path: '/lion/comments',
    handler: addCommentHandler,
    options: {
        auth: 'accessKey',
        validate: {
            payload: commentSchema,
        },
    },
});

const writeFileSchema = Joi.object({
    fileName: Joi.string().min(1).required(),
    content: Joi.binary().required(),
});

const writeFileHandler = async (request, h) => {
    const { fileName, content } = request.payload;
    const filePath = `/var/data/${fileName}`;
    await fs.promises.writeFile(filePath, content);
    return { message: `File ${fileName} written successfully` };
};

server.route({
    method: 'POST',
    path: '/tiger/files',
    handler: writeFileHandler,
    options: {
        auth: 'accessKey',
        payload: {
            output: 'stream',
            parse: true,
            allow: 'application/octet-stream',
        },
        validate: {
            payload: writeFileSchema,
        },
    },
});

const start = async () => {
    await server.start();
    console.log(`Server running at: ${server.info.uri}`);
};

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

start();