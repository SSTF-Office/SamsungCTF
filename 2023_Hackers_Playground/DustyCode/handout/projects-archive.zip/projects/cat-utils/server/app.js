const express = require('express');
const { firefox } = require('playwright');

const app = express();

// Define a sample access key
const ACCESS_KEY = 'a1b2c3d4e5';

app.get('/:fruitName', async (req, res) => {
  const { fruitName } = req.params;
  const { access_key, url } = req.query;

  // Check access key
  if (access_key !== ACCESS_KEY) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if url parameter is provided
  if (!url) {
    return res.status(400).json({ error: 'url parameter is required' });
  }

  // Launch the browser and visit the given URL
  const browser = await firefox();
  const context = await browser.newContext();
  const page = await context.newPage();
  await page.goto(url);

  // Get the page content
  const content = await page.content();

  // Close the browser
  await browser.close();

  res.send(content);
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});