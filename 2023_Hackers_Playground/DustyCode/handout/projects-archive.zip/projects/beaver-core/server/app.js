const Hapi = require('@hapi/hapi');
const Joi = require('joi');
const bcrypt = require('bcrypt');
const fs = require('fs');

const saltRounds = 10;

// Initialize database
const dbPath = './database.json';

const initDb = () => {
  if (!fs.existsSync(dbPath)) {
    fs.writeFileSync(dbPath, JSON.stringify({ users: [], friends: [], posts: [], comments: [] }));
  }
};

// Helper functions
const getUserIndex = (users, username) => {
  return users.findIndex(user => user.username === username);
}

const generateAccessKey = () => {
  const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  const accessKeyLength = 32;
  let accessKey = '';
  for (let i = 0; i < accessKeyLength; i++) {
    accessKey += characters.charAt(Math.floor(Math.random() * characters.length));
  }
  return accessKey;
}

const hashPassword = async (password) => {
  return await bcrypt.hash(password, saltRounds);
}

const comparePassword = async (password, hash) => {
  return await bcrypt.compare(password, hash);
}

const validateAccessKey = (request, h) => {
  const users = JSON.parse(fs.readFileSync(dbPath)).users;
  const accessKey = request.headers.access_key;
  const user = users.find(user => user.access_key === accessKey);

  if (!user) {
    return h.response({ message: 'Invalid access key' }).code(401);
  }

  return h.continue;
}

const safeExec = (command, callback) => {
  const diskSpaceLimit = 5368709120; // 5 GB in bytes
  let chunks = [];

  const childProcess = require('child_process').spawn(command);

  childProcess.stdout.on('data', (data) => {
    chunks.push(data);
  });

  childProcess.on('close', (code) => {
    const output = Buffer.concat(chunks).toString();

    if (code === 0) {
      const diskSpace = parseFloat(output.split('\n')[3].split(':')[1]);

      if (diskSpace <= diskSpaceLimit) {
        callback(null);
      } else {
        callback({ message: 'Disk space limit reached' });
      }
    } else {
      callback({ message: 'Error executing command' });
    }
  });
}

// Initialize server
const server = Hapi.server({
  port: 3000,
  host: 'localhost'
});

// Initialize database
initDb();

// Routes
server.route({
  method: 'GET',
  path: '/characters',
  handler: (request, h) => {
    return 'Welcome to the Social Network Service';
  }
});

// Authentication routes
server.route({
  method: 'POST',
  path: '/register',
  handler: (request, h) => {
    const { username, password } = request.payload;
    const users = JSON.parse(fs.readFileSync(dbPath)).users;

    if (getUserIndex(users, username) !== -1) {
      return h.response({ message: 'User already exists' }).code(400);
    }

    hashPassword(password).then((hash) => {
      const newUser = {
        username,
        password: hash,
        access_key: generateAccessKey()
      };

      users.push(newUser);
      fs.writeFileSync(dbPath, JSON.stringify({ users }));

      return h.response({ message: 'User registered successfully', access_key: newUser.access_key }).code(201);
    });
  },
  options: {
    validate: {
      payload: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required()
      })
    }
  }
});

server.route({
  method: 'POST',
  path: '/login',
  handler: (request, h) => {
    const { username, password } = request.payload;
    const users = JSON.parse(fs.readFileSync(dbPath)).users;
    const userIndex = getUserIndex(users, username);

    if (userIndex === -1) {
      return h.response({ message: 'Invalid username or password' }).code(401);
    }

    comparePassword(password, users[userIndex].password).then((result) => {
      if (result) {
        const accessKey = generateAccessKey();
        users[userIndex].access_key = accessKey;
        fs.writeFileSync(dbPath, JSON.stringify({ users }));

        return h.response({ message: 'Authentication successful', access_key: accessKey }).code(200);
      } else {
        return h.response({ message: 'Invalid username or password' }).code(401);
      }
    });
  },
  options: {
    validate: {
      payload: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required()
      })
    }
  }
});

server.route({
  method: 'POST',
  path: '/logout',
  handler: (request, h) => {
    const users = JSON.parse(fs.readFileSync(dbPath)).users;
    const accessKey = request.headers.access_key;
    const userIndex = users.findIndex(user => user.access_key === accessKey);

    if (userIndex !== -1) {
      users[userIndex].access_key = '';
      fs.writeFileSync(dbPath, JSON.stringify({ users }));

      return h.response({ message: 'Logout successful' }).code(200);
    } else {
      return h.response({ message: 'Invalid access key' }).code(401);
    }
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ]
  }
});

// Friend routes
server.route({
  method: 'GET',
  path: '/han-solo/friends',
  handler: (request, h) => {
    const friends = JSON.parse(fs.readFileSync(dbPath)).friends;
    const accessKey = request.headers.access_key;
    const currentUser = JSON.parse(fs.readFileSync(dbPath)).users.find(user => user.access_key === accessKey);

    if (currentUser) {
      const userFriends = friends.filter(friend => friend.user_id === currentUser.username);
      return h.response(userFriends).code(200);
    } else {
      return h.response({ message: 'Invalid access key' }).code(401);
    }
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ]
  }
});

server.route({
  method: 'POST',
  path: '/harry-potter/friends',
  handler: (request, h) => {
    const friends = JSON.parse(fs.readFileSync(dbPath)).friends;
    const { friend_name } = request.payload;
    const accessKey = request.headers.access_key;
    const currentUser = JSON.parse(fs.readFileSync(dbPath)).users.find(user => user.access_key === accessKey);

    if (currentUser) {
      if (getUserIndex(friends, friend_name) !== -1) {
        return h.response({ message: 'Friend already added' }).code(400);
      }

      friends.push({ user_id: currentUser.username, friend_name });
      fs.writeFileSync(dbPath, JSON.stringify({ friends }));

      return h.response({ message: 'Friend added successfully' }).code(201);
    } else {
      return h.response({ message: 'Invalid access key' }).code(401);
    }
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ],
    validate: {
      payload: Joi.object({
        friend_name: Joi.string().required()
      })
    }
  }
});

server.route({
  method: 'DELETE',
  path: '/james-bond/friends',
  handler: (request, h) => {
    const friends = JSON.parse(fs.readFileSync(dbPath)).friends;
    const { friend_name } = request.payload;
    const accessKey = request.headers.access_key;
    const currentUser = JSON.parse(fs.readFileSync(dbPath)).users.find(user => user.access_key === accessKey);
    const friendIndex = friends.findIndex(friend => friend.user_id === currentUser.username && friend.friend_name === friend_name);

    if (friendIndex !== -1) {
      friends.splice(friendIndex, 1);
      fs.writeFileSync(dbPath, JSON.stringify({ friends }));

      return h.response({ message: 'Friend removed successfully' }).code(200);
    } else {
      return h.response({ message: 'Friend not found' }).code(404);
    }
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ],
    validate: {
      payload: Joi.object({
        friend_name: Joi.string().required()
      })
    }
  }
});

// SNS post routes
server.route({
  method: 'GET',
  path: '/simba/posts',
  handler: (request, h) => {
    const posts = JSON.parse(fs.readFileSync(dbPath)).posts;
    const accessKey = request.headers.access_key;

    if (!accessKey) {
      return h.response(posts).code(200);
    }

    const currentUser = JSON.parse(fs.readFileSync(dbPath)).users.find(user => user.access_key === accessKey);

    if (currentUser.role === 'admin') {
      return h.response(posts).code(200);
    }

    const userFriends = JSON.parse(fs.readFileSync(dbPath)).friends.filter(friend => friend.user_id === currentUser.username);

    const friendPosts = posts.filter(post => {
      return post.username === currentUser.username || userFriends.findIndex(friend => friend.friend_name === post.username) !== -1;
    });

    return h.response(friendPosts).code(200);
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ]
  }
});

server.route({
  method: 'POST',
  path: '/hannibal/posts',
  handler: (request, h) => {
    const { content } = request.payload;
    const accessKey = request.headers.access_key;
    const currentUser = JSON.parse(fs.readFileSync(dbPath)).users.find(user => user.access_key === accessKey);
    const timestamp = new Date().toISOString();

    const newPost = {
      username: currentUser.username,
      content,
      timestamp
    };

    const posts = JSON.parse(fs.readFileSync(dbPath)).posts;
    posts.push(newPost);
    fs.writeFileSync(dbPath, JSON.stringify({ posts }));

    return h.response({ message: 'Post created successfully' }).code(201);
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ],
    validate: {
      payload: Joi.object({
        content: Joi.string().required()
      })
    }
  }
});

server.route({
  method: 'POST',
  path: '/pikachu/comments',
  handler: (request, h) => {
    const comments = JSON.parse(fs.readFileSync(dbPath)).comments;
    const { post_timestamp, content } = request.payload;
    const accessKey = request.headers.access_key;
    const currentUser = JSON.parse(fs.readFileSync(dbPath)).users.find(user => user.access_key === accessKey);
    const timestamp = new Date().toISOString();

    const newComment = {
      post_timestamp,
      username: currentUser.username,
      content,
      timestamp
    };

    comments.push(newComment);
    fs.writeFileSync(dbPath, JSON.stringify({ comments }));

    return h.response({ message: 'Comment added successfully' }).code(201);
  },
  options: {
    pre: [
      { method: validateAccessKey }
    ],
    validate: {
      payload: Joi.object({
        post_timestamp: Joi.string().required(),
        content: Joi.string().required()
      })
    }
  }
});

// Disk usage route
server.route({
  method: 'GET',
  path: '/finding-nemo/diskusage',
  handler: (request, h) => {
    const command = 'df';
    let chunks = [];

    const childProcess = require('child_process').spawn(command);

    childProcess.stdout.on('data', (data) => {
      chunks.push(data);
    });

    childProcess.on('close', (code) => {
      const output = Buffer.concat(chunks).toString();

      if (code === 0) {
        const diskUsage = output.split('\n')[1].split(' ').filter(value => value !== '');
        const diskSpace = parseFloat(diskUsage[1]) * 1024; // KB to bytes
        const diskUsed = parseFloat(diskUsage[2]) * 1024; // KB to bytes

        return h.response({ disk_space: diskSpace, disk_used: diskUsed }).code(200);
      } else {
        return h.response({ message: 'Error executing command' }).code(500);
      }
    });
  }
});

// Start server
const start = async () => {
  try {
    await server.start();
    console.log(`Server running at: ${server.info.uri}`);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
};

start();