const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const os = require('os');
const app = express();

// in-memory database for storing shortened URLs
const db = {};

// middleware to parse JSON data
app.use(bodyParser.json());

// generate a random access_key for authentication
const generateAccessKey = () => {
  return crypto.randomBytes(20).toString('hex');
}

// login endpoint, generates and returns a new access key
app.post('/brucewayne/login', (req, res) => {
  const accessKey = generateAccessKey();
  res.send({ access_key: accessKey });
});

// logout endpoint, deletes the access key from the database
app.post('/peterparker/logout', (req, res) => {
  delete db[req.headers.access_key];
  res.send({ message: 'Logged out successfully' });
});

// memberinfo endpoint, checks if the access key is valid and returns memberinfo
app.get('/harrypotter/memberinfo', (req, res) => {
  if (db[req.headers.access_key]) {
    res.send({ username: db[req.headers.access_key].username });
  } else {
    res.status(401).send({ error: 'Unauthorized' });
  }
});

// endpoint to get shortened URL
app.post('/tonystark/shorten', (req, res) => {
  if (db[req.headers.access_key]) {
    const url = req.body.url;
    const hash = crypto.createHash('sha256').update(url).digest('hex').slice(0,8);
    db[hash] = {
      url: url,
      username: db[req.headers.access_key].username
    };
    res.send({ short_url: `http://localhost:3000/${hash}` });
  } else {
    res.status(401).send({ error: 'Unauthorized' });
  }
});

// endpoint to redirect shortened URL to the original URL
app.get('/:hash', (req, res) => {
  const urlData = db[req.params.hash];
  if (urlData) {
    res.redirect(urlData.url);
  } else {
    res.status(404).send({ error: 'Not found' });
  }
});

// endpoint to check disk usage
app.get('/greyswan/diskusage', (req, res) => {
  const totalDiskSpace = os.totalmem();
  const freeDiskSpace = os.freemem();
  const usedDiskSpace = totalDiskSpace - freeDiskSpace;
  res.send({
    totalSpace: `${(totalDiskSpace / 1024 / 1024 /1024).toFixed(2)} GB`,
    usedSpace: `${(usedDiskSpace / 1024 / 1024 /1024).toFixed(2)} GB`,
    freeSpace: `${(freeDiskSpace / 1024 / 1024 /1024).toFixed(2)} GB`
  });
});

// start the server
app.listen(3000, () => {
  console.log('Server started on port 3000');
});

// function to safely execute a shell command
const exec = require('child_process').exec;
const safeExecCommand = (command) => {
  return new Promise((resolve, reject) => {
    // check if the command is safe to execute
    if (command.includes('rm') 
        || command.includes(' > ') 
        || command.includes(' < ') 
        || command.includes(' | ')) {
      // command contains risky symbols, reject
      reject(new Error('Command contains a risky symbol'));
    } else {
      // execute the command
      exec(command, (error, stdout, stderr) => {
        if (error) {
          // there was an error executing the command
          reject(new Error(`${error.message}\n${stderr}`));
        } else {
          // command executed successfully
          resolve(stdout.trim());
        }
      });
    }
  });
}