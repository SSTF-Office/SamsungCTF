// Import required library
const express = require('express');
const ejs = require('ejs');
const redis = require('redis');
const { exec } = require('child_process');

// Create express app
const app = express();

// Set view engine to ejs
app.set('view engine', 'ejs');

// Create redis client
const client = redis.createClient();

// Set default port to 3000
const port = process.env.PORT || 3000;

// Middleware to parse request body
app.use(express.urlencoded({ extended: false }));
app.use(express.json());

// Middleware to check access key
const checkAccessKey = (req, res, next) => {
  const accessKey = req.headers['access-key'];

  if (!accessKey) {
    return res.status(401).json({ error: 'Access key missing' });
  }

  // Check if access key exists in redis
  client.get(accessKey, (err, reply) => {
    if (err) {
      console.error('Redis error:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    if (!reply) {
      return res.status(401).json({ error: 'Invalid access key' });
    }

    // Access key is valid, proceed to next middleware
    next();
  });
};

// Endpoint to add friend
app.post('/taco', checkAccessKey, (req, res) => {
  // TODO: Add friend

  res.json({ message: 'Friend added' });
});

// Endpoint to remove friend
app.post('/pizza', checkAccessKey, (req, res) => {
  // TODO: Remove friend

  res.json({ message: 'Friend removed' });
});

// Endpoint to find friend
app.get('/sushi', checkAccessKey, (req, res) => {
  // TODO: Find friend

  res.json([{ name: 'John Doe', age: 25 }]);
});

// Endpoint to add post
app.post('/burger', checkAccessKey, (req, res) => {
  // TODO: Add post

  res.json({ message: 'Post added' });
});

// Endpoint to add comment
app.post('/ramen', checkAccessKey, (req, res) => {
  // TODO: Add comment

  res.json({ message: 'Comment added' });
});

// Endpoint to get disk usage
app.get('/spaghetti', checkAccessKey, (req, res) => {
  exec('df -h', (err, stdout, stderr) => {
    if (err) {
      console.error('Exec error:', err);
      return res.status(500).json({ error: 'Internal server error' });
    }

    if (stderr) {
      console.error('Exec stderr:', stderr);
      return res.status(500).json({ error: 'Internal server error' });
    }

    const usage = stdout.toString();
    res.send(`<pre>${usage}</pre>`);
  });
});

// Start server
app.listen(port, () => console.log(`Server started on port ${port}`));