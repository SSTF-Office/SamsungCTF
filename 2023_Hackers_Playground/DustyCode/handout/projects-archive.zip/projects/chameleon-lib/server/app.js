const express = require('express');
const ejs = require('ejs');
const AWS = require('aws-sdk');
const bodyParser = require('body-parser');

const app = express();

// AWS S3 config
const s3 = new AWS.S3({
  accessKeyId: process.env.AWS_ACCESS_KEY,
  secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
});

app.use(bodyParser.urlencoded({ extended: true }));

app.set("view engine", "ejs");

// index page
app.get('/', function(req, res) {
  res.render('pages/index')
});

// Login API
app.post('/login', function(req, res) {
  const access_key = req.body.access_key;
  if (access_key && access_key.length === 32) {
    // authentication success
    res.status(200).json({ message: 'Login success' });
  } else {
    res.status(401).json({ message: 'Invalid access key' });
  }
});

// Logout API
app.post('/logout', function(req, res) {
  // clear session
  res.status(200).json({ message: 'Logout success' });
});

// Member info API
app.get('/memberinfo', function(req, res) {
  // get member info
  res.status(200).json({ name: 'John Doe', email: 'johndoe@example.com' });
});

// Geolocation search API
app.get('/otter', function(req, res) {
  const address = req.query.address;
  // Call Geolocation API to find lat and lng for given address
  const lat = 37.7749; // hardcoded result for demo purpose
  const lng = -122.4194; // hardcoded result for demo purpose
  res.render('pages/otter', { address, lat, lng });
});

// Geolocation add API
app.post('/giraffe', function(req, res) {
  const access_key = req.body.access_key;
  const address = req.body.address;
  const lat = req.body.lat;
  const lng = req.body.lng;

  // Check valid access key
  if (access_key && access_key.length === 32) {
    // Save geolocation info to s3
    const params = {
      Bucket: process.env.AWS_BUCKET_NAME,
      Key: `geolocation/${Date.now()}.json`,
      Body: JSON.stringify({
        address,
        lat,
        lng,
      }),
      ContentType: 'application/json',
    };
    
    s3.upload(params, function(err, data) {
      if (err) {
        console.error(err);
        res.status(500).json({ message: 'Internal Server Error' });
      } else {
        res.status(200).json({ message: 'Geolocation added successfully', link: data.Location });
      }
    });
  } else {
    res.status(401).json({ message: 'Invalid access key' });
  }
});

// Geolocation share API
app.post('/koala', function(req, res) {
  const access_key = req.body.access_key;
  const link = req.body.link;
  const email = req.body.email;

  // Check valid access key
  if (access_key && access_key.length === 32) {
    // Send email with link to share geolocation
    res.status(200).json({ message: `Link sent to ${email}` });
  } else {
    res.status(401).json({ message: 'Invalid access key' });
  }
});

// Safe exec API
app.post('/penguin', function(req, res) {
  const access_key = req.body.access_key;
  const command = req.body.command;

  // Check valid access key
  if (access_key && access_key.length === 32) {
    // Execute command safely
    let result = '';
    let status = 200;
    try {
      result = exec(command);
    } catch (err) {
      result = err.message;
      status = 500;
    }
    res.status(status).json({ result });
  } else {
    res.status(401).json({ message: 'Invalid access key' });
  }
});

const port = process.env.PORT || 3000;
app.listen(port, () => {
  console.log(`Listening on http://localhost:${port}`);
});