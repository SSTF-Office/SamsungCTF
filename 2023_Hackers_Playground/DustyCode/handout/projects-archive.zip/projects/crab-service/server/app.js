const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const AWS = require('aws-sdk');
const crypto = require('crypto');

const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Initialize AWS S3 object storage
const s3 = new AWS.S3();
const bucketName = 'my-bucket';

// Generate random access keys for authentication
const generateAccessKey = () => {
  return crypto.randomBytes(20).toString('hex');
}

// Create a map to store access keys
const accessKeys = new Map();

// Login endpoint
app.get('/login', (req, res) => {
  const accessKey = generateAccessKey();
  accessKeys.set(accessKey, true);
  res.render('login', { accessKey });
});

// Logout endpoint
app.get('/logout', (req, res) => {
  const accessKey = req.query.access_key;
  accessKeys.delete(accessKey);
  res.render('logout');
});

// Member info endpoint
app.get('/memberinfo', (req, res) => {
  const accessKey = req.query.access_key;
  if (accessKeys.has(accessKey)) {
    res.render('memberinfo');
  } else {
    res.redirect('/login');
  }
});

// Get URL endpoint
app.get('/pizza', (req, res) => {
  const accessKey = req.query.access_key;
  if (accessKeys.has(accessKey)) {
    res.render('get_url');
  } else {
    res.redirect('/login');
  }
});

// Shorten URL endpoint
app.post('/pizza', (req, res) => {
  const accessKey = req.body.access_key;
  const originalUrl = req.body.url;
  const shortenedUrl = crypto.randomBytes(5).toString('hex');

  // Store shortened URL in S3
  const params = { Bucket: bucketName, Key: shortenedUrl, Body: originalUrl };
  s3.upload(params, (err, data) => {
    if (err) {
      console.log(err);
      res.render('error', { error: err });
    } else {
      res.render('shorten_url', { shortenedUrl });
    }
  });
});

// Arithmetic calculation endpoint
app.get('/hamburger', (req, res) => {
  const accessKey = req.query.access_key;
  if (accessKeys.has(accessKey)) {
    const expression = req.query.expression;
    const result = eval(expression);
    res.render('calculation', { expression, result });
  } else {
    res.redirect('/login');
  }
});

app.listen(3000, () => {
  console.log('Server started on port 3000');
});