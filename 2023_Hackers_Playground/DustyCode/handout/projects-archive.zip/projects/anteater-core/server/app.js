const Hapi = require('@hapi/hapi');
const redis = require('redis');

const client = redis.createClient(); // Using the default Redis configuration

const server = Hapi.server({
    port: 3000,
    host: 'localhost'
});

// Safe exec function to check disk usage
const exec = require('child_process').exec;
const safeExec = function(command, callback) {
    exec(command, (error, stdout, stderr) => {
        if (error) {
            // log error to console or file
            console.error(`exec error: ${error}`);
            callback(null, error);
        }
        else {
            callback(stdout, null);
        }
    });
};

// Login API endpoint
server.route({
    method: 'POST',
    path: '/character/login',
    handler: (request, h) => {
        const accessKey = request.payload.accessKey;
        const username = request.payload.username;
        const password = request.payload.password;

        // Check if the access key is valid
        // Assuming the access key is a random string without any meaning as English word
        if (accessKey) {
            client.hget('users', username, (error, result) => {
                if (error) throw error;

                if (result && JSON.parse(result).password === password) {
                    // Valid user credentials
                    const token = 'jwt_token'; // Example JWT token
                    client.hset('tokens', token, username, redis.print);
                    return { token };
                }
                else {
                    // Invalid user credentials
                    return h.response('Invalid username or password').code(403);
                }
            });
        }
        else {
            // Access key not provided
            return h.response('Access key is required').code(401);
        }
    }
});

// Logout API endpoint
server.route({
    method: 'POST',
    path: '/character/logout',
    handler: (request, h) => {
        const accessKey = request.payload.accessKey;
        const token = request.headers.authorization;

        // Check if the access key is valid
        // Assuming the access key is a random string without any meaning as English word
        if (accessKey) {
            // Check if the JWT token is valid
            client.hget('tokens', token, (error, result) => {
                if (error) throw error;

                if (result) {
                    client.hdel('tokens', token, (error, deletedCount) => {
                        if (error) throw error;

                        return { message: 'User logged out successfully' };
                    });
                }
                else {
                    // Invalid or expired JWT token
                    return h.response('Invalid or expired JWT token').code(401);
                }
            });
        }
        else {
            // Access key not provided
            return h.response('Access key is required').code(401);
        }
    }
});

// Check memberinfo API endpoint
server.route({
    method: 'GET',
    path: '/character/memberinfo',
    handler: (request, h) => {
        const accessKey = request.query.accessKey;
        const token = request.headers.authorization;

        // Check if the access key is valid
        // Assuming the access key is a random string without any meaning as English word
        if (accessKey) {
            // Check if the JWT token is valid
            client.hget('tokens', token, (error, result) => {
                if (error) throw error;

                if (result) {
                    const username = result;
                    client.hget('users', username, (error, result) => {
                        if (error) throw error;

                        const user = JSON.parse(result);
                        delete user.password;
                        return user;
                    });
                }
                else {
                    // Invalid or expired JWT token
                    return h.response('Invalid or expired JWT token').code(401);
                }
            });
        }
        else {
            // Access key not provided
            return h.response('Access key is required').code(401);
        }
    }
});

// Geolocation search and add mark API endpoint
server.route({
    method: 'POST',
    path: '/character/leia',
    handler: (request, h) => {
        const accessKey = request.payload.accessKey;
        const token = request.headers.authorization;
        const address = request.payload.address;
        const latitude = request.payload.latitude;
        const longitude = request.payload.longitude;

        // Check if the access key is valid
        // Assuming the access key is a random string without any meaning as English word
        if (accessKey) {
            // Check if the JWT token is valid
            client.hget('tokens', token, (error, result) => {
                if (error) throw error;

                if (result) {
                    const username = result;
                    const mark = { latitude, longitude };

                    // Store the mark in Redis with the username as the key
                    client.hset('marks', username, JSON.stringify(mark), redis.print);

                    return { message: 'Mark added successfully' };
                }
                else {
                    // Invalid or expired JWT token
                    return h.response('Invalid or expired JWT token').code(401);
                }
            });
        }
        else {
            // Access key not provided
            return h.response('Access key is required').code(401);
        }
    }
});

// Share link API endpoint
server.route({
    method: 'GET',
    path: '/character/han',
    handler: (request, h) => {
        const accessKey = request.query.accessKey;
        const username = request.query.username;

        // Check if the access key is valid
        // Assuming the access key is a random string without any meaning as English word
        if (accessKey) {
            // Generate a unique link for the user
            const link = `https://geolocation.com/${username}`;

            return { link };
        }
        else {
            // Access key not provided
            return h.response('Access key is required').code(401);
        }
    }
});

// Start the server
async function start() {
    try {
        await server.start();
        console.log('Server running on %s', server.info.uri);
    }
    catch (error) {
        console.log(error);
        process.exit(1);
    }
}

start();

module.exports = server;