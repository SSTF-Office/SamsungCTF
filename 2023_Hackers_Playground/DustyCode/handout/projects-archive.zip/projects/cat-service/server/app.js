const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const AWS = require('aws-sdk');
const app = express();

const PORT = 3000;
const ACCESS_KEY_LENGTH = 32;

AWS.config.update({
    accessKeyId: process.env.AWS_ACCESS_KEY_ID,
    secretAccessKey: process.env.AWS_SECRET_ACCESS_KEY,
    region: process.env.AWS_REGION,
});

const docClient = new AWS.DynamoDB.DocumentClient();
const s3 = new AWS.S3();

app.use(bodyParser.json());

app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');

// Authentication API endpoint
app.post('/login', (req, res) => {
    const accessKey = generateRandomString(ACCESS_KEY_LENGTH);
    const params = {
        TableName: 'users',
        Item: {
            id: accessKey,
            name: req.body.name,
            email: req.body.email,
        },
    };
    docClient.put(params, (err, data) => {
        if (err) {
            console.log(err);
            res.status(500).json({ message: 'Internal Server Error' });
        } else {
            res.status(200).json({ access_key: accessKey });
        }
    });
});

// Web Cache API endpoints
const cacheBucketName = 'web-cache';

app.post('/pizza', (req, res) => {
    const url = req.body.url;
    const key = generateRandomString(ACCESS_KEY_LENGTH);
    const params = {
        Bucket: cacheBucketName,
        Key: key,
        Body: '',
        ContentType: 'text/html',
        Metadata: { url: url },
    };
    getS3Object(url, (err, data) => {
        if (err) {
            console.log(`Error fetching ${url}: ${err}`);
            res.status(500).json({ message: 'Internal Server Error' });
        } else {
            params.Body = data.Body.toString();
            s3.upload(params, (err, data) => {
                if (err) {
                    console.log(`Error storing ${url} in cache: ${err}`);
                    res.status(500).json({ message: 'Internal Server Error' });
                } else {
                    res.status(200).json({ cache_id: key });
                }
            });
        }
    });
});

app.get('/burger', (req, res) => {
    const cacheId = req.query.cache_id;
    const params = {
        Bucket: cacheBucketName,
        Key: cacheId,
    };
    s3.getObject(params, (err, data) => {
        if (err) {
            console.log(`Error fetching ${cacheId}: ${err}`);
            res.status(500).json({ message: 'Internal Server Error' });
        } else {
            res.status(200).send(data.Body.toString('utf-8'));
        }
    });
});

// Arithmetic Calculation API endpoint
app.post('/donut', (req, res) => {
    const expr = req.body.expression;
    const result = eval(expr);
    res.status(200).json({ result: result });
});

// Helper function for generating random strings
function generateRandomString(length) {
    let result = '';
    const characters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    const charactersLength = characters.length;
    for (let i = 0; i < length; i++) {
        result += characters.charAt(Math.floor(Math.random() * charactersLength));
    }
    return result;
}

// Helper function for fetching web content from URL
function getS3Object(url, callback) {
    const urlParts = url.split('/');
    const Bucket = urlParts[2].replace('.', '-');
    const Key = urlParts.slice(3).join('/');
    s3.getObject({ Bucket: Bucket, Key: Key }, callback);
}

app.listen(PORT, () => {
    console.log(`Server started on port ${PORT}`);
});