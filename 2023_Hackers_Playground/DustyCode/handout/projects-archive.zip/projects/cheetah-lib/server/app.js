const Hapi = require('@hapi/hapi');
const Redis = require('redis');
const CockroachDB = require('pg').Pool;

const server = Hapi.server({
    port: 8000,
    host: 'localhost'
});

// connect to Redis
const redisClient = Redis.createClient();

// connect to CockroachDB
const cockroachDBClient = new CockroachDB({
    user: 'root',
    host: 'localhost',
    database: 'testdb',
    port: 26257
});

// define helper function to check access_key
const checkAccessKey = (accessKey) => {
    // perform some logic to check if access key is valid
    return accessKey === 'random_string';
};

// define API endpoints
server.route([
    {
        method: 'POST',
        path: '/login',
        handler: (request, h) => {
            const { accessKey } = request.payload;
            if (checkAccessKey(accessKey)) {
                // generate a session id and store it in Redis
                const sessionId = Math.random().toString(36).substring(2);
                redisClient.set(`session:${sessionId}`, accessKey);
                return { sessionId };
            } else {
                return { error: 'Invalid access key' };
            }
        }
    },
    {
        method: 'POST',
        path: '/logout',
        handler: (request, h) => {
            const { sessionId } = request.payload;
            redisClient.del(`session:${sessionId}`);
            return { message: 'Successfully logged out' };
        }
    },
    {
        method: 'GET',
        path: '/{shortUrl}',
        handler: async (request, h) => {
            const { shortUrl } = request.params;
            const { sessionId } = request.query;

            // check if session id is valid
            const accessKey = await redisClient.get(`session:${sessionId}`);
            if (!accessKey) {
                return { error: 'Invalid session id' };
            }

            // look up target URL in CockroachDB
            const { rows } = await cockroachDBClient.query('SELECT targetUrl FROM urls WHERE shortUrl = $1', [shortUrl]);
            if (rows.length > 0) {
                return { targetUrl: rows[0].targetUrl };
            } else {
                return { error: 'Short URL not found' };
            }
        }
    }
]);

// start the server
const start = async () => {
    await server.start();
    console.log(`Server running on ${server.info.uri}`);
};

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

start();