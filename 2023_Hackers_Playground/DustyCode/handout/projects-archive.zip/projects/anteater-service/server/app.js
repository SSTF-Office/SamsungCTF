const Hapi = require('@hapi/hapi');
const Joi = require('joi');
const fs = require('fs');

const server = Hapi.server({
  port: process.env.PORT || 3000,
  host: 'localhost'
});

// Mock user database
const users = [
  {
    id: 1,
    name: 'Alice',
    access_key: '4f12a8234f12123'
  },
  {
    id: 2,
    name: 'Bob',
    access_key: '2fabb9713f56c71'
  }
];

// Mock geolocation database (stored in JSON format)
let geolocations = [];

// Read geolocations from file on server start
fs.readFile('./geolocations.json', (err, data) => {
  if (err) throw err;
  geolocations = JSON.parse(data);
});

// Schema for geolocation object
const geolocationSchema = Joi.object({
  id: Joi.number().required(),
  address: Joi.string().required(),
  latitude: Joi.number().required(),
  longitude: Joi.number().required(),
  created_by: Joi.number().required()
});

// Login endpoint
server.route({
  method: 'POST',
  path: '/lion/login',
  handler: async (request, h) => {
    const { access_key } = request.payload;
    // Check if access_key matches any user's access_key
    const user = users.find(u => u.access_key === access_key);
    if (!user) {
      return h.response('Invalid access key').code(401);
    }
    // Return user object and new access_token
    const access_token = Math.random().toString(36).slice(2);
    return { user, access_token };
  },
  options: {
    validate: {
      payload: Joi.object({
        access_key: Joi.string().required()
      })
    }
  }
});

// Logout endpoint
server.route({
  method: 'POST',
  path: '/penguin/logout',
  handler: async (request, h) => {
    // TODO: Remove access_token from user record
    return 'Successfully logged out';
  }
});

// Get current user endpoint
server.route({
  method: 'GET',
  path: '/elephant/memberinfo',
  handler: async (request, h) => {
    // TODO: Lookup user with access_token
    const user = users[0];
    return user;
  }
});

// List geolocations endpoint
server.route({
  method: 'GET',
  path: '/giraffe/locations',
  handler: async (request, h) => {
    return geolocations;
  }
});

// Add geolocation endpoint
server.route({
  method: 'POST',
  path: '/tiger/location',
  handler: async (request, h) => {
    const { payload } = request;
    const { error } = geolocationSchema.validate(payload);
    if (error) {
      return h.response(error.details[0].message).code(400);
    }
    // Generate new ID
    const id = geolocations.length + 1;
    // Add ID to geolocation object
    const geolocation = {
      ...payload,
      id
    };
    geolocations.push(geolocation);
    // Write geolocations to file
    fs.writeFile('./geolocations.json', JSON.stringify(geolocations), err => {
      if (err) throw err;
    });
    return geolocation;
  },
  options: {
    validate: {
      payload: geolocationSchema
    }
  }
});

// Share geolocation endpoint
server.route({
  method: 'GET',
  path: '/zebra/share/{id}',
  handler: async (request, h) => {
    const { id } = request.params;
    const geolocation = geolocations.find(g => g.id === parseInt(id));
    if (!geolocation) {
      return h.response('Geolocation not found').code(404);
    }
    // Construct share URL with ID
    const shareUrl = `http://localhost:${process.env.PORT || 3000}/zebra/share/${id}`;
    return { shareUrl };
  }
});

// Serve static file endpoint
server.route({
  method: 'GET',
  path: '/{param*}',
  handler: {
    directory: {
      path: 'public'
    }
  }
});

// Start server
const start = async () => {
  await server.start();
  console.log(`Server running at ${server.info.uri}`);
};

start();