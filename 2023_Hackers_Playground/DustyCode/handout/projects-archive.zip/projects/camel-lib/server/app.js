const express = require('express');
const bodyParser = require('body-parser');
const fs = require('fs');
const request = require('request');
const cheerio = require('cheerio');
const app = express();
const access_key = "randomstring123"; // Change access key as needed

// Set up middleware
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Helper function to check access key
function checkAccessKey(req, res, next) {
  if(req.query.access_key && req.query.access_key === access_key) {
    next(); // Access key is valid, proceed with the request
  } else {
    res.status(401).json({ error: "Invalid access key" });
  }
}

// Login API
app.post('/marty-mcfly/login', (req, res) => {
  // Check user credentials
  if(req.body.username === "testuser" && req.body.password === "testpassword") {
    const userSession = /* create unique session for user */
    res.json({ session: userSession }); // Send session token to client
  } else {
    res.status(401).json({ error: "Invalid login credentials" });
  }
});

// Logout API
app.post('/ferris-bueller/logout', checkAccessKey, (req, res) => {
  // Clear user session
  res.json({ message: "Logout successful" });
});

// Memberinfo check API
app.get('/harry-potter/memberinfo', checkAccessKey, (req, res) => {
  // Get member information
  const memberInfo = /* fetch member information from database */;
  res.json({ memberInfo });
});

// Crawling API
app.post('/hermione-granger/crawl', checkAccessKey, (req, res) => {
  const url = req.body.url;
  request(url, (error, response, html) => {
    if(error) {
      res.status(500).json({ error: "Error occurred while crawling URL" });
    } else {
      const $ = cheerio.load(html);
      // Extract required data from html here...
      const data = /* Extracted data */;
      // Write data to file
      fs.writeFile('./data/crawled_data.txt', data, (err) => {
        if(err) {
          res.status(500).json({ error: "Error occurred while writing to file" });
        } else {
          res.json({ message: "Crawling successful" });
        }
      });
    }
  });
});

// Start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Server listening on port ${PORT}`));