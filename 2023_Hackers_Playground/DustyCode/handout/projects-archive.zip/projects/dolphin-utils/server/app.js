const Hapi = require('hapi');
const fs = require('fs');
const exec = require('child_process').exec;

const server = new Hapi.Server();
server.connection({ port: 3000, host: 'localhost' });

const cacheDir = './cache';
if (!fs.existsSync(cacheDir)) {
  fs.mkdirSync(cacheDir);
}

// authentication
const accessKeys = ['randomstring1', 'randomstring2', 'randomstring3'];
const authHandler = function(request, reply) {
  const apiKey = request.query.access_key;
  if (accessKeys.includes(apiKey)) {
    return reply.continue();
  }
  return reply({ error: 'Invalid access key' }).code(401);
}

// safe exec function
const safeExec = function(cmd, callback) {
  exec(cmd, function(error, stdout, stderr) {
    if (error) {
      return callback(error.toString());
    }
    return callback(null, stdout.toString());
  });
}

// endpoints
server.route({
  method: 'GET',
  path: '/elephant/cache',
  config: {
    auth: { strategy: 'simple', mode: 'try' },
    handler: function(request, reply) {
      if (request.auth.isAuthenticated) {
        const url = request.query.url;
        if (url) {
          const cacheId = Date.now();
          const cachePath = `${cacheDir}/${cacheId}.txt`;
          const cmd = `curl -o ${cachePath} ${url}`;
          safeExec(cmd, function(error, output) {
            if (error) {
              return reply({ error: 'Failed to fetch the web page' });
            }
            return reply({ cache_id: cacheId });
          });
        } else {
          return reply({ error: 'Invalid URL' }).code(400);
        }
      } else {
        return reply.redirect('/elephant/login');
      }
    }
  }
});

server.route({
  method: 'GET',
  path: '/elephant/cache/{cache_id}',
  config: {
    auth: 'simple',
    handler: function(request, reply) {
      const cacheId = request.params.cache_id;
      const cachePath = `${cacheDir}/${cacheId}.txt`;
      if (fs.existsSync(cachePath)) {
        const cacheData = fs.readFileSync(cachePath);
        return reply(cacheData);
      } else {
        return reply({ error: 'Invalid cache ID' }).code(404);
      }
    }
  }
});

server.route({
  method: 'GET',
  path: '/giraffe/login',
  handler: function(request, reply) {
    return reply('Please login');
  }
});

server.route({
  method: 'POST',
  path: '/giraffe/login',
  handler: function(request, reply) {
    const apiKey = request.payload.access_key;
    if (accessKeys.includes(apiKey)) {
      request.cookieAuth.set({ apiKey });
      return reply('Logged in');
    }
    return reply({ error: 'Invalid access key' }).code(401);
  }
});

server.route({
  method: 'GET',
  path: '/giraffe/logout',
  handler: function(request, reply) {
    request.cookieAuth.clear();
    return reply('Logged out');
  }
});

server.route({
  method: 'GET',
  path: '/giraffe/memberinfo',
  config: {
    auth: 'simple',
    handler: function(request, reply) {
      return reply(`Logged in with access key: ${request.auth.credentials.apiKey}`);
    }
  }
});

server.route({
  method: 'GET',
  path: '/rhinoceros/checkdisk',
  config: {
    auth: 'simple',
    handler: function(request, reply) {
      safeExec('df', function(error, output) {
        if (error) {
          return reply({ error: 'Failed to check disk usage' });
        }
        return reply(output);
      });
    }
  }
});

server.start((err) => {
  if (err) {
    throw err;
  }

  console.log(`Server running at: ${server.info.uri}`);
});