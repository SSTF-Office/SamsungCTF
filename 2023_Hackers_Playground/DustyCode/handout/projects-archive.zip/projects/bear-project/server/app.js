const http = require('http');
const url = require('url');
const redis = require('redis');
const crypto = require('crypto');

const redisClient = redis.createClient(); // Redis client for data storage

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const path = parsedUrl.pathname;

  // Authentication with access_key
  if (req.headers.access_key !== 'random_string_without_meaning') {
    res.statusCode = 401;
    res.end('Invalid Access Key');
    return;
  }

  // Login endpoint
  if (path === '/login' && req.method === 'POST') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { username, password } = JSON.parse(body);
      // Dummy authentication logic for demo
      if (username === 'admin' && password === 'admin') {
        const sessionId = crypto.randomBytes(16).toString('hex'); // Generate random sessionId
        redisClient.set(sessionId, Date.now()); // Store session data in Redis
        res.setHeader('Set-Cookie', `sessionId=${sessionId}`); // Set sessionId cookie
        res.end('Login Successful');
      } else {
        res.statusCode = 401;
        res.end('Invalid Credentials');
      }
    });
  }

  // Logout endpoint
  if (path === '/logout' && req.method === 'GET') {
    const sessionId = req.headers.cookie?.split('=')[1];
    if (sessionId) {
      redisClient.del(sessionId); // Remove session data from Redis
      res.setHeader('Set-Cookie', `sessionId=; Max-Age=0`); // Remove sessionId cookie
      res.end('Logout Successful');
    } else {
      res.statusCode = 401;
      res.end('Invalid Session');
    }
  }

  // Member Info endpoint
  if (path === '/member' && req.method === 'GET') {
    const sessionId = req.headers.cookie?.split('=')[1];
    if (sessionId) {
      redisClient.get(sessionId, (err, data) => {
        if (err || !data) {
          res.statusCode = 401;
          res.end('Invalid Session');
        } else {
          res.end(`Member info for sessionId ${sessionId}:\n${JSON.stringify({ sessionId, createdAt: new Date(parseInt(data)).toString() }, null, 2)}`);
        }
      });
    } else {
      res.statusCode = 401;
      res.end('Invalid Session');
    }
  }

  // URL Shortener - Get URL endpoint
  if (path === '/tiger' && req.method === 'GET') {
    const { url: longUrl } = parsedUrl.query;
    if (!longUrl) {
      res.statusCode = 400;
      res.end('Missing URL Parameter');
      return;
    }
    const shortUrl = crypto.createHash('md5').update(longUrl).digest('hex').substring(0, 8); // Generate shortUrl using MD5 hash of longUrl
    redisClient.set(shortUrl, longUrl); // Store shortUrl-longUrl data in Redis
    res.end(`Short URL for ${longUrl}:\nhttp://localhost:8080/${shortUrl}\n`);
  }

  // URL Shortener - Shorten URL endpoint
  if (/^[a-z]+$/.test(path.substr(1)) && req.method === 'GET') {
    const shortUrl = path.substr(1);
    redisClient.get(shortUrl, (err, longUrl) => {
      if (err || !longUrl) {
        res.statusCode = 404;
        res.end('Short URL Not Found');
      } else {
        res.setHeader('Location', longUrl);
        res.statusCode = 307;
        res.end();
      }
    });
  }

  // Arithmetic Calculation endpoint
  if (path === '/lion' && req.method === 'POST') {
    let body = '';
    req.on('data', (chunk) => {
      body += chunk.toString();
    });
    req.on('end', () => {
      try {
        const result = eval(body); // Evaluate the arithmetic expression
        res.end(`Result: ${result}\n`);
      } catch (err) {
        res.statusCode = 400;
        res.end('Invalid Expression');
      }
    });
  }

  // Invalid endpoint
  res.statusCode = 404;
  res.end('Invalid Endpoint');
});

const PORT = process.env.PORT || 8080;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});