const http = require('http');
const querystring = require('querystring');

// in memory storage for shortened urls
const urls = {};

// generate random access key for authentication
const accessKey = Math.random().toString(36).substring(2);

const server = http.createServer((req, res) => {

  // handle login request
  if (req.url === '/owl/login' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { access_key } = querystring.parse(body);
      if (access_key === accessKey) {
        res.end('Login successful');
      } else {
        res.statusCode = 401;
        res.end('Unauthorized');
      }
    });
  }
  
  // handle logout request
  else if (req.url === '/giraffe/logout' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { access_key } = querystring.parse(body);
      if (access_key === accessKey) {
        res.end('Logout successful');
      } else {
        res.statusCode = 401;
        res.end('Unauthorized');
      }
    });
  }
  
  // handle memberinfo check
  else if (req.url === '/penguin/memberinfo' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { access_key } = querystring.parse(body);
      if (access_key === accessKey) {
        res.end(JSON.stringify({ username: 'john_doe', email: 'john_doe@example.com' }));
      } else {
        res.statusCode = 401;
        res.end('Unauthorized');
      }
    });
  }
  
  // handle url shorten request
  else if (req.url === '/elephant/shorten' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { access_key, url } = querystring.parse(body);
      if (access_key === accessKey) {
        const id = Math.random().toString(36).substring(2);
        urls[id] = url;
        res.end(`Shortened URL: http://localhost:8000/${id}`);
      } else {
        res.statusCode = 401;
        res.end('Unauthorized');
      }
    });
  }
  
  // handle shortened url redirect
  else if (req.url.startsWith('/') && req.method === 'GET') {
    const id = req.url.slice(1);
    const url = urls[id];
    if (url) {
      res.writeHead(301, { Location: url });
      res.end();
    } else {
      res.statusCode = 404;
      res.end('Not Found');
    }
  }
  
  // handle arithmetic calculation request
  else if (req.url === '/horse/calculate' && req.method === 'POST') {
    let body = '';
    req.on('data', chunk => {
      body += chunk.toString();
    });
    req.on('end', () => {
      const { access_key, expression } = querystring.parse(body);
      if (access_key === accessKey) {
        const result = eval(expression);
        res.end(`Result: ${result}`);
      } else {
        res.statusCode = 401;
        res.end('Unauthorized');
      }
    });
  }
  
  // handle unknown request
  else {
    res.statusCode = 404;
    res.end('Not Found');
  }

});

server.listen(8000, () => {
  console.log('Server started on http://localhost:8000');
});