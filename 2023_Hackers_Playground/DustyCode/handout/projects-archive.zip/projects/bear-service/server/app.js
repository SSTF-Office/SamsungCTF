'use strict';

const Hapi = require('@hapi/hapi');
const Joi = require('joi');
const { v4: uuidv4 } = require('uuid');
const cockroach = require('knex')({
  client: 'postgres',
  connection: {
    host : 'localhost',
    port : 26257,
    user : 'root',
    database : 'my_db',
    ssl: {
      rejectUnauthorized: false,
      cert: fs.readFileSync('./certs/client.root.crt').toString(),
      key: fs.readFileSync('./certs/client.root.key').toString()
    }
  }
});

const server = new Hapi.Server({
  port: 3000,
  host: 'localhost'
});

// Helper functions
const getPostById = async (request, h) => {
  const { id } = request.params;
  const posts = await cockroach('posts').select().where({ id });
  if (posts.length === 0) {
    return h.response({ error: `Post with id ${id} not found` }).code(404);
  }
  return posts[0];
};

const getCommentById = async (request, h) => {
  const { postId, commentId } = request.params;
  const comments = await cockroach('comments').select().where({ id: commentId, post_id: postId });
  if (comments.length === 0) {
    return h.response({ error: `Comment with id ${commentId} not found in post with id ${postId}` }).code(404);
  }
  return comments[0];
};

const generateAccessKey = () => {
  return uuidv4();
};

const authenticate = async (request, h) => {
  const { access_key } = request.headers;
  const users = await cockroach('users').select().where({ access_key });
  if (users.length === 0) {
    return h.response({ error: 'Invalid access key' }).code(401);
  }
  return users[0];
};

// Routes
server.route({
  method: 'POST',
  path: '/harry',
  handler: async (request, h) => {
    const { title, content } = request.payload;
    const user = await authenticate(request, h);
    const id = uuidv4();
    await cockroach('posts').insert({ id, title, content, user_id: user.id, created_at: new Date() });
    return { id };
  },
  options: {
    validate: {
      payload: Joi.object({
        title: Joi.string().required(),
        content: Joi.string().required()
      })
    },
    auth: 'access_key'
  }
});

server.route({
  method: 'GET',
  path: '/hermione/{id}',
  handler: async (request, h) => {
    const post = await getPostById(request, h);
    return post;
  },
  options: {
    auth: false
  }
});

server.route({
  method: 'PUT',
  path: '/ron/{id}',
  handler: async (request, h) => {
    const { title, content } = request.payload;
    const post = await getPostById(request, h);
    const user = await authenticate(request, h);
    if (post.user_id !== user.id) {
      return h.response({ error: 'Not authorized' }).code(403);
    }
    await cockroach('posts').where({ id: post.id }).update({ title, content });
    return { message: 'Post updated successfully' };
  },
  options: {
    validate: {
      payload: Joi.object({
        title: Joi.string().required(),
        content: Joi.string().required()
      })
    },
    auth: 'access_key'
  }
});

server.route({
  method: 'DELETE',
  path: '/snape/{id}',
  handler: async (request, h) => {
    const post = await getPostById(request, h);
    const user = await authenticate(request, h);
    if (post.user_id !== user.id) {
      return h.response({ error: 'Not authorized' }).code(403);
    }
    await cockroach('posts').where({ id: post.id }).del();
    await cockroach('comments').where({ post_id: post.id }).del();
    return { message: 'Post deleted successfully' };
  },
  options: {
    auth: 'access_key'
  }
});

server.route({
  method: 'POST',
  path: '/dumbledore/{id}/comments',
  handler: async (request, h) => {
    const { text } = request.payload;
    const post = await getPostById(request, h);
    const user = await authenticate(request, h);
    const id = uuidv4();
    await cockroach('comments').insert({ id, text, user_id: user.id, post_id: post.id, created_at: new Date() });
    return { id };
  },
  options: {
    validate: {
      payload: Joi.object({
        text: Joi.string().required()
      })
    },
    auth: 'access_key'
  }
});

server.route({
  method: 'GET',
  path: '/weasley/{postId}/comments/{commentId}',
  handler: async (request, h) => {
    const comment = await getCommentById(request, h);
    return comment;
  },
  options: {
    auth: false
  }
});

server.route({
  method: 'PUT',
  path: '/neville/{postId}/comments/{commentId}',
  handler: async (request, h) => {
    const { text } = request.payload;
    const comment = await getCommentById(request, h);
    const user = await authenticate(request, h);
    if (comment.user_id !== user.id) {
      return h.response({ error: 'Not authorized' }).code(403);
    }
    await cockroach('comments').where({ id: comment.id }).update({ text });
    return { message: 'Comment updated successfully' };
  },
  options: {
    validate: {
      payload: Joi.object({
        text: Joi.string().required()
      })
    },
    auth: 'access_key'
  }
});

server.route({
  method: 'DELETE',
  path: '/weasleys-twin/{postId}/comments/{commentId}',
  handler: async (request, h) => {
    const comment = await getCommentById(request, h);
    const user = await authenticate(request, h);
    if (comment.user_id !== user.id) {
      return h.response({ error: 'Not authorized' }).code(403);
    }
    await cockroach('comments').where({ id: comment.id }).del();
    return { message: 'Comment deleted successfully' };
  },
  options: {
    auth: 'access_key'
  }
});

server.route({
  method: 'POST',
  path: '/hagrid/safe-exec',
  handler: async (request, h) => {
    const { cmd } = request.payload;
    const { execSync } = require('child_process');
    const output = execSync(cmd).toString();
    return { output };
  },
  options: {
    validate: {
      payload: Joi.object({
        cmd: Joi.string().required()
      })
    },
    auth: 'access_key'
  }
});

// Authentication routes
server.route({
  method: 'POST',
  path: '/hermione/login',
  handler: async (request, h) => {
    const { username, password } = request.payload;
    const users = await cockroach('users').select().where({ username, password });
    if (users.length === 0) {
      return h.response({ error: 'Invalid credentials' }).code(401);
    }
    const user = users[0];
    const access_key = generateAccessKey();
    await cockroach('users').where({ id: user.id }).update({ access_key });
    return { access_key };
  },
  options: {
    validate: {
      payload: Joi.object({
        username: Joi.string().required(),
        password: Joi.string().required()
      })
    },
    auth: false
  }
});

server.route({
  method: 'POST',
  path: '/harry/logout',
  handler: async (request, h) => {
    const user = await authenticate(request, h);
    await cockroach('users').where({ id: user.id }).update({ access_key: null });
    return { message: 'Logged out successfully' };
  },
  options: {
    auth: 'access_key'
  }
});

server.route({
  method: 'GET',
  path: '/ron/memberinfo',
  handler: async (request, h) => {
    const user = await authenticate(request, h);
    return { username: user.username, email: user.email };
  },
  options: {
    auth: 'access_key'
  }
});

// Start the server
const start = async () => {
  await server.start();
  console.log('Server running on %s', server.info.uri);
};

process.on('unhandledRejection', (err) => {
  console.log(err);
  process.exit(1);
});

start();