const express = require('express');
const bodyParser = require('body-parser');
const redis = require('redis');
const fs = require('fs');

const app = express();
app.use(bodyParser.urlencoded({ extended: true }));
app.set('view engine', 'ejs');

const client = redis.createClient();

app.get('/padthai', (req, res) => {
  const url = req.query.url;
  if (url && req.get('access_key')) {
    client.get(url, (err, data) => {
      if (err) {
        console.log(err);
        res.status(500).send('Error fetching data from the cache server');
      } else if (data) {
        console.log('Cache hit');
        res.send(data);
      } else {
        console.log('Cache miss, fetching from web server');
        // Fetch the web response from the given URL using any HTTP library
        // For example:
        // axios.get(url).then(response => {
        //   const responseText = response.data;
        //   const cacheId = Math.random().toString(36).substr(2, 9);
        //   client.set(cacheId, responseText);
        //   res.render('cache', { cacheId: cacheId });
        // }).catch(error => {
        //   console.log(error);
        //   res.status(500).send('Error fetching data from the web server');
        // });
        
        // For demonstration purpose, let's write a local file instead of fetching from web server
        const responseText = 'This is the response from the local file';
        const cacheId = Math.random().toString(36).substr(2, 9);
        client.set(cacheId, responseText);
        fs.writeFile(`./cache/${cacheId}.txt`, responseText, (err) => {
          if (err) {
            console.log(err);
            res.status(500).send('Error writing to the local file');
          } else {
            res.render('cache', { cacheId: cacheId });
          }
        });
      }
    });
  } else {
    res.status(400).send('Invalid request');
  }
});

app.get('/burgers', (req, res) => {
  const cacheId = req.query.id;
  if (cacheId && req.get('access_key')) {
    client.get(cacheId, (err, data) => {
      if (err) {
        console.log(err);
        res.status(500).send('Error fetching data from the cache server');
      } else if (data) {
        console.log('Cache hit');
        res.send(data);
      } else {
        res.status(404).send('Cache not found');
      }
    });
  } else {
    res.status(400).send('Invalid request');
  }
});

app.post('/hamburger', (req, res) => {
  const cacheId = req.body.id;
  const content = req.body.content;
  if (cacheId && content && req.get('access_key')) {
    client.set(cacheId, content);
    fs.writeFile(`./cache/${cacheId}.txt`, content, (err) => {
      if (err) {
        console.log(err);
        res.status(500).send('Error writing to the local file');
      } else {
        res.send('Cache updated');
      }
    });
  } else {
    res.status(400).send('Invalid request');
  }
});

app.listen(3000, () => {
  console.log('The server is listening on port 3000');
});