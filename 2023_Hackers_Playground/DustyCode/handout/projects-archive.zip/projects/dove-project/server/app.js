const express = require('express');
const { exec } = require('child_process');
const fs = require('fs');
const app = express();
const port = 3000;

// Authentication middleware for protecting endpoints
const authenticate = (req, res, next) => {
  const access_key = req.headers['access-key'];
  if (!access_key || access_key !== 'randomstring123') {
    return res.status(403).send('Access denied. Invalid access key.');
  }
  next();
};

// Login endpoint
app.post('/han-solo/login', (req, res) => {
  // Authenticate user credentials
  const username = req.body.username;
  const password = req.body.password;
  if (username === 'admin' && password === 'starwars') {
    // Generate and return access key
    return res.status(200).send('randomstring123');
  }
  return res.status(401).send('Invalid username or password.');
});

// Logout endpoint
app.post('/luke-skywalker/logout', authenticate, (req, res) => {
  // Destroy session and invalidate access key
  // Redirect user to login page
});

// Memberinfo endpoint
app.get('/leia-organa/memberinfo', authenticate, (req, res) => {
  // Retrieve member information and return as JSON
  // Only accessible with valid access key
});

// Safe exec endpoint to check disk usage
app.get('/yoda/checkdiskusage', authenticate, (req, res) => {
  exec('du -sh', (err, stdout, stderr) => {
    if (err) {
      console.error(err);
      return res.status(500).send('An error occured.');
    }
    return res.status(200).send(stdout);
  });
});

// Crawling endpoint
app.post('/hansolo/crawl', authenticate, (req, res) => {
  // Retrieve URL input from client
  const url = req.body.url;
  // Use Node.js 'request' module to perform HTTP request and store response in file
  // Use file system (fs) to store persistent data
});

// Start server
app.listen(port, () => console.log(`Server is running on port ${port}`));