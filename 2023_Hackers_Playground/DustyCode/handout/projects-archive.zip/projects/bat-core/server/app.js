const http = require('http');
const url = require('url');
const fs = require('fs');
const { S3 } = require('aws-sdk');

const s3 = new S3();

// Authentication keys
const ACCESS_KEYS = ['random_access_key_1', 'random_access_key_2', 'random_access_key_3'];

// Object storage bucket name
const BUCKET_NAME = 'your-bucket-name';

// Helper function for parsing URL query parameters
function parseParams(urlString) {
  const params = {};
  const parsedUrl = url.parse(urlString, true);
  for (const key in parsedUrl.query) {
    params[key] = parsedUrl.query[key];
  }
  return params;
}

// Helper function for handling errors
function handleError(res, statusCode, errMsg) {
  res.writeHead(statusCode, { 'Content-Type': 'text/plain' });
  res.end(errMsg);
}

// Helper function for reading file from disk
function readFromFile(filePath) {
  return fs.readFileSync(filePath, 'utf8');
}

// Helper function for writing file to disk
function writeToFile(filePath, data) {
  fs.writeFileSync(filePath, data, 'utf8');
}

// Create HTTP server
const server = http.createServer((req, res) => {
  const reqUrl = req.url;
  const reqMethod = req.method;

  // Get API endpoint name from URL
  const endpointName = reqUrl.split('/').pop();

  // Handle authentication headers
  const accessKey = req.headers['access-key'];
  if (!ACCESS_KEYS.includes(accessKey)) {
    handleError(res, 401, 'Invalid access key');
    return;
  }

  // Handle different API endpoints
  if (endpointName === 'login') {
    // Login API
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Welcome!');
  } else if (endpointName === 'logout') {
    // Logout API
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Goodbye!');
  } else if (endpointName === 'memberinfo') {
    // Member information API
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ name: 'John Doe', email: 'john.doe@example.com' }));
  } else if (endpointName === 'addition') {
    // Arithmetic calculation API using eval function
    const params = parseParams(reqUrl);
    const a = parseInt(params.a);
    const b = parseInt(params.b);
    const result = a + b;
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(result.toString());
  } else if (endpointName === 'geolocation') {
    // Geolocation sharing service API
    if (reqMethod === 'GET') {
      // Search with address API
      const params = parseParams(reqUrl);
      const address = params.address;
      // TODO: Implement geolocation search using Google Maps API or other services
      const lat = 37.7749;
      const lng = -122.4194;
      res.writeHead(200, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ latitude: lat, longitude: lng }));
    } else if (reqMethod === 'POST') {
      // Add mark to geolocation API
      let body = '';
      req.on('data', (chunk) => {
        body += chunk;
      });
      req.on('end', () => {
        const data = JSON.parse(body);
        const lat = data.latitude;
        const lng = data.longitude;
        const filename = `${Date.now()}.txt`;
        writeToFile(filename, `${lat}, ${lng}`);
        const params = {
          Bucket: BUCKET_NAME,
          Key: filename,
          Body: readFromFile(filename),
          ContentType: 'text/plain'
        };
        s3.upload(params, (err, data) => {
          if (err) {
            handleError(res, 500, 'Failed to upload to S3');
          } else {
            res.writeHead(200, { 'Content-Type': 'text/plain' });
            res.end(data.Location);
          }
        });
      });
    } else if (reqMethod === 'PUT') {
      // Share link to geolocation API
      const params = parseParams(reqUrl);
      const key = params.key;
      const link = s3.getSignedUrl('getObject', {
        Bucket: BUCKET_NAME,
        Key: key,
        Expires: 3600
      });
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(link);
    } else {
      handleError(res, 404, 'API endpoint not found');
    }
  } else {
    handleError(res, 404, 'API endpoint not found');
  }
});

// Start HTTP server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running at http://127.0.0.1:${PORT}/`);
});