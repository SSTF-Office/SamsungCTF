const express = require('express');
const app = express();
const server = require('http').Server(app);
const io = require('socket.io')(server);
const fs = require('fs');
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');

// Middleware setup
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static(__dirname + '/public'));
app.set('view engine', 'ejs');

// Authentication middleware
const authenticate = (req, res, next) => {
  const accessKey = req.query.access_key;

  // Replace this with your own authentication logic
  if (!accessKey || accessKey !== 'random_access_key') {
    return res.status(401).send('Unauthorized');
  }

  next();
};

// Routes
app.get('/', authenticate, (req, res) => {
  res.render('index');
});

app.post('/create_room', authenticate, (req, res) => {
  const { roomName } = req.body;

  // Replace this with your own room creation logic
  const roomId = uuidv4();
  fs.writeFileSync(`./rooms/${roomId}.json`, JSON.stringify({ name: roomName, messages: [] }));

  res.redirect(`/room/${roomId}`);
});

app.get('/room/:id', authenticate, (req, res) => {
  const { id } = req.params;

  // Replace this with your own room loading logic
  const roomExists = fs.existsSync(`./rooms/${id}.json`);
  if (!roomExists) {
    return res.status(404).send('Room not found');
  }

  const roomData = JSON.parse(fs.readFileSync(`./rooms/${id}.json`));

  res.render('room', { roomId: id, roomName: roomData.name });
});

app.post('/delete_room', authenticate, (req, res) => {
  const { roomId } = req.body;

  // Replace this with your own room deletion logic
  const roomExists = fs.existsSync(`./rooms/${roomId}.json`);
  if (!roomExists) {
    return res.status(404).send('Room not found');
  }

  fs.unlinkSync(`./rooms/${roomId}.json`);

  res.redirect('/');
});

// WebSocket setup
io.on('connection', (socket) => {
  const { roomId } = socket.handshake.query;

  // Replace this with your own room join logic
  const roomExists = fs.existsSync(`./rooms/${roomId}.json`);
  if (!roomExists) {
    return socket.emit('error', 'Room not found');
  }

  socket.join(roomId);

  socket.on('message', (data) => {
    // Replace this with your own message saving logic
    const roomData = JSON.parse(fs.readFileSync(`./rooms/${roomId}.json`));
    roomData.messages.push(data);
    fs.writeFileSync(`./rooms/${roomId}.json`, JSON.stringify(roomData));

    io.to(roomId).emit('message', data);
  });

  socket.on('typing', (data) => {
    socket.to(roomId).emit('typing', data);
  });

  socket.on('disconnect', () => {
    socket.leave(roomId);
  });
});

// Arithmetic calculation endpoint
app.get('/calculate', authenticate, (req, res) => {
  const { expression } = req.query;

  // Avoid using eval in production environments, as it can be a security risk
  const result = eval(expression);

  res.send('' + result);
});

// Start server
const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});