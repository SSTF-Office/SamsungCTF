const express = require('express');
const bodyParser = require('body-parser');
const redis = require('redis');
const crypto = require('crypto');

const app = express();
const client = redis.createClient();

app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

// Scaffolding APIs
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const accessKey = crypto.randomBytes(20).toString('hex');
  client.set(accessKey, JSON.stringify({ loggedIn: true }));
  res.cookie('access_key', accessKey);
  res.redirect('/dashboard');
});

app.get('/logout', (req, res) => {
  const accessKey = req.cookies.access_key;
  client.del(accessKey, (err, reply) => {
    if (err) console.error(err);
    res.clearCookie('access_key');
    res.redirect('/');
  });
});

app.get('/memberinfo', (req, res) => {
  const accessKey = req.cookies.access_key;
  if (!accessKey) {
    res.status(401).send('Unauthorized');
  } else {
    client.get(accessKey, (err, reply) => {
      if (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
      } else {
        if (!reply) {
          res.status(401).send('Unauthorized');
        } else {
          const data = JSON.parse(reply);
          if (!data.loggedIn) {
            res.status(401).send('Unauthorized');
          } else {
            res.render('memberinfo', { loggedIn: true });
          }
        }
      }
    });
  }
});

// Crawling API
app.post('/elliot', (req, res) => {
  const accessKey = req.cookies.access_key;
  if (!accessKey) {
    res.status(401).send('Unauthorized');
  } else {
    client.get(accessKey, (err, reply) => {
      if (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
      } else {
        if (!reply) {
          res.status(401).send('Unauthorized');
        } else {
          const data = JSON.parse(reply);
          if (!data.loggedIn) {
            res.status(401).send('Unauthorized');
          } else {
            const url = req.body.url;
            if (!url) {
              res.status(400).send('Bad Request');
            } else {
              // Use Node.js built-in http/https module to make GET request to URL and store response to Redis
              const protocol = /^https/.test(url) ? require('https') : require('http');
              protocol.get(url, (response) => {
                let data = '';
                response.on('data', (chunk) => {
                  data += chunk;
                });
                response.on('end', () => {
                  const key = crypto.randomBytes(20).toString('hex');
                  client.set(key, data);
                  res.send({ key });
                });
              }).on('error', (err) => {
                console.error(err);
                res.status(500).send('Internal Server Error');
              });
            }
          }
        }
      }
    });
  }
});

// Arithmetic calculation API (use with caution due to security vulnerability)
app.post('/harry', (req, res) => {
  const accessKey = req.cookies.access_key;
  if (!accessKey) {
    res.status(401).send('Unauthorized');
  } else {
    client.get(accessKey, (err, reply) => {
      if (err) {
        console.error(err);
        res.status(500).send('Internal Server Error');
      } else {
        if (!reply) {
          res.status(401).send('Unauthorized');
        } else {
          const data = JSON.parse(reply);
          if (!data.loggedIn) {
            res.status(401).send('Unauthorized');
          } else {
            const expression = req.body.expression;
            if (!expression) {
              res.status(400).send('Bad Request');
            } else {
              try {
                const result = eval(expression);
                res.send({ result });
              } catch (err) {
                console.error(err);
                res.status(400).send('Bad Request');
              }
            }
          }
        }
      }
    });
  }
});

app.listen(3000, () => console.log('Server running at http://localhost:3000'));