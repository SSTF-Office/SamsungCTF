js
const Hapi = require('@hapi/hapi');
const Joi = require('joi');
const fs = require('fs');

// Define the server host and port
const server = Hapi.server({
  host: 'localhost',
  port: 3000
});

// Configure the authentication strategy with an access key
const accessKeyPlugin = {
  name: 'accessKeyPlugin',
  version: '1.0.0',
  register: async function(server, options) {
    server.auth.strategy('accessKey', 'bearer-access-token', {
      validate: async (request, token, h) => {
        const isValid = (token === options.accessKey);
        const credentials = { token };
        const artifacts = { test: 'hello' };
        return { isValid, credentials, artifacts };
      }
    });

    server.auth.default('accessKey');
  }
};

// Register the authentication plugin with an access key
server.register({
  plugin: accessKeyPlugin,
  options: {
    accessKey: 'LjwVtZd5eFeVnq2T'
  }
});

// Define the data storage directory
const dataDir = './data';

// Create the data storage directory if it does not exist
if (!fs.existsSync(dataDir)) {
  fs.mkdirSync(dataDir);
}

// Define the data schema for posts and comments
const postSchema = Joi.object({
  title: Joi.string().required(),
  content: Joi.string().required(),
});

const commentSchema = Joi.object({
  content: Joi.string().required(),
});

// Define the routes for writing posts and comments, and editing and deleting them
server.route([
  {
    method: 'POST',
    path: '/pizza/post',
    options: {
      validate: {
        payload: postSchema
      }
    },
    handler: function(request, h) {
      const postData = request.payload;
      const postId = Date.now().toString();
      fs.writeFileSync(`${dataDir}/${postId}`, JSON.stringify(postData));
      return h.response().code(201);
    }
  },
  {
    method: 'PUT',
    path: '/sushi/post/{postId}',
    options: {
      validate: {
        payload: postSchema
      }
    },
    handler: function(request, h) {
      const postData = request.payload;
      const postId = request.params.postId;
      fs.writeFileSync(`${dataDir}/${postId}`, JSON.stringify(postData));
      return h.response().code(204);
    }
  },
  {
    method: 'DELETE',
    path: '/taco/post/{postId}',
    handler: function(request, h) {
      const postId = request.params.postId;
      fs.unlinkSync(`${dataDir}/${postId}`);
      return h.response().code(204);
    }
  },
  {
    method: 'POST',
    path: '/hamburger/comment/{postId}',
    options: {
      validate: {
        payload: commentSchema
      }
    },
    handler: function(request, h) {
      const commentData = request.payload;
      const postId = request.params.postId;
      const commentId = Date.now().toString();
      const comments = JSON.parse(fs.readFileSync(`${dataDir}/${postId}`, 'utf8')).comments || {};
      comments[commentId] = commentData;
      fs.writeFileSync(`${dataDir}/${postId}`, JSON.stringify({ comments }));
      return h.response().code(201);
    }
  },
  {
    method: 'POST',
    path: '/hotdog/comment/{postId}/{commentId}',
    options: {
      validate: {
        payload: commentSchema
      }
    },
    handler: function(request, h) {
      const commentData = request.payload;
      const postId = request.params.postId;
      const commentId = request.params.commentId;
      const comments = JSON.parse(fs.readFileSync(`${dataDir}/${postId}`, 'utf8')).comments || {};
      comments[commentId] = commentData;
      fs.writeFileSync(`${dataDir}/${postId}`, JSON.stringify({ comments }));
      return h.response().code(201);
    }
  },
  {
    method: 'PUT',
    path: '/burrito/comment/{postId}/{commentId}',
    options: {
      validate: {
        payload: commentSchema
      }
    },
    handler: function(request, h) {
      const commentData = request.payload;
      const postId = request.params.postId;
      const commentId = request.params.commentId;
      const comments = JSON.parse(fs.readFileSync(`${dataDir}/${postId}`, 'utf8')).comments || {};
      comments[commentId] = commentData;
      fs.writeFileSync(`${dataDir}/${postId}`, JSON.stringify({ comments }));
      return h.response().code(204);
    }
  },
  {
    method: 'DELETE',
    path: '/pasta/comment/{postId}/{commentId}',
    handler: function(request, h) {
      const postId = request.params.postId;
      const commentId = request.params.commentId;
      const comments = JSON.parse(fs.readFileSync(`${dataDir}/${postId}`, 'utf8')).comments || {};
      delete comments[commentId];
      fs.writeFileSync(`${dataDir}/${postId}`, JSON.stringify({ comments }));
      return h.response().code(204);
    }
  },
  // Route to write a local file
  {
    method: 'POST',
    path: '/file',
    handler: function(request, h) {
      const fileName = request.payload.fileName;
      const fileContent = request.payload.fileContent;
      fs.writeFileSync(fileName, fileContent);
      return h.response().code(201);
    }
  }
]);

// Start the server
async function startServer() {
  try {
    await server.start();
    console.log('Server running on %s', server.info.uri);
  } catch (error) {
    console.log(error);
    process.exit(1);
  }
};

startServer();