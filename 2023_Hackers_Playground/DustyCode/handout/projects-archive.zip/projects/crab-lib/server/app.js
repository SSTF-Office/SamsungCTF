const http = require('http');
const url = require('url');

const accessKeys = new Set();
const posts = {};
const neighbors = {};

const server = http.createServer((req, res) => {
  const { pathname } = url.parse(req.url, true);
  const [, character, id] = pathname.split('/');

  if (req.method === 'POST' && pathname === '/login') {
    let accessKey = '';
    do {
      accessKey = Math.random().toString(36).substring(2, 10);
    } while (accessKeys.has(accessKey));
    accessKeys.add(accessKey);
    res.writeHead(200, 'OK', { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ access_key: accessKey }));
  } else if (req.method === 'POST' && pathname === '/logout') {
    accessKeys.delete(req.headers.authorization);
    res.writeHead(200, 'OK', { 'Content-Type': 'text/plain' });
    res.end('Logged out');
  } else if (req.method === 'POST' && pathname === '/posts/create') {
    if (!accessKeys.has(req.headers.authorization)) {
      res.writeHead(401, 'Unauthorized', { 'Content-Type': 'text/plain' });
      res.end('Unauthorized');
      return;
    }
    const body = [];
    req.on('data', chunk => body.push(chunk));
    req.on('end', () => {
      const data = JSON.parse(Buffer.concat(body).toString());
      const id = Math.random().toString(36).substring(2, 10);
      posts[id] = { ...data, id };
      res.writeHead(201, 'Created', { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(posts[id]));
    });
  } else if (req.method === 'GET' && pathname === '/posts') {
    const data = [];
    for (const post of Object.values(posts)) {
      data.push({ ...post, content: undefined });
    }
    res.writeHead(200, 'OK', { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(data));
  } else if (req.method === 'GET' && pathname === '/posts/' + id) {
    if (!posts[id]) {
      res.writeHead(404, 'Not Found', { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
    res.writeHead(200, 'OK', { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(posts[id]));
  } else if (req.method === 'PUT' && pathname === '/posts/' + id) {
    if (!accessKeys.has(req.headers.authorization)) {
      res.writeHead(401, 'Unauthorized', { 'Content-Type': 'text/plain' });
      res.end('Unauthorized');
      return;
    }
    if (!posts[id]) {
      res.writeHead(404, 'Not Found', { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
    const body = [];
    req.on('data', chunk => body.push(chunk));
    req.on('end', () => {
      const data = JSON.parse(Buffer.concat(body).toString());
      posts[id] = { ...posts[id], ...data, id };
      res.writeHead(200, 'OK', { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(posts[id]));
    });
  } else if (req.method === 'DELETE' && pathname === '/posts/' + id) {
    if (!accessKeys.has(req.headers.authorization)) {
      res.writeHead(401, 'Unauthorized', { 'Content-Type': 'text/plain' });
      res.end('Unauthorized');
      return;
    }
    if (!posts[id]) {
      res.writeHead(404, 'Not Found', { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
    delete posts[id];
    res.writeHead(200, 'OK', { 'Content-Type': 'text/plain' });
    res.end('Deleted');
  } else if (req.method === 'POST' && pathname === '/neighbors/add') {
    if (!accessKeys.has(req.headers.authorization)) {
      res.writeHead(401, 'Unauthorized', { 'Content-Type': 'text/plain' });
      res.end('Unauthorized');
      return;
    }
    const body = [];
    req.on('data', chunk => body.push(chunk));
    req.on('end', () => {
      const data = JSON.parse(Buffer.concat(body).toString());
      if (!neighbors[data.character]) {
        neighbors[data.character] = { ...data, posts: [] };
      } else if (!neighbors[data.character].posts.includes(data.post)) {
        neighbors[data.character].posts.push(data.post);
      }
      res.writeHead(200, 'OK', { 'Content-Type': 'application/json' });
      res.end(JSON.stringify(neighbors[data.character]));
    });
  } else if (req.method === 'GET' && pathname === '/neighbors/' + character) {
    if (!neighbors[character]) {
      res.writeHead(404, 'Not Found', { 'Content-Type': 'text/plain' });
      res.end('Not Found');
      return;
    }
    res.writeHead(200, 'OK', { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(neighbors[character]));
  } else if (req.method === 'GET' && pathname === '/calc') {
    const { query } = url.parse(req.url, true);
    const result = eval(query.expression);
    res.writeHead(200, 'OK', { 'Content-Type': 'text/plain' });
    res.end(result.toString());
  } else {
    res.writeHead(404, 'Not Found', { 'Content-Type': 'text/plain' });
    res.end('Not Found');
  }
});

server.listen(8080);