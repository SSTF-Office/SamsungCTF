const express = require('express');
const app = express();
const ejs = require('ejs');
const bodyParser = require('body-parser');
const { Pool } = require('pg');

// Initialize the database connection using the Pool object from node-postgres library
const pool = new Pool({
  connectionString: 'postgresql://username:password@localhost:5432/database'
});

// Set the view engine to EJS
app.set('view engine', 'ejs');

// Use the body-parser library to parse request bodies
app.use(bodyParser.urlencoded({ extended: true }));

// Define a middleware to authenticate the access_key sent by the client
function authenticate(req, res, next) {
  const access_key = req.get('access_key');
  if (access_key === 'random_string') {
    next();
  } else {
    res.status(401).render('unauthorized');
  }
}

// Define the routes for the login and logout endpoints
app.get('/login', (req, res) => {
  res.render('login');
});

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  // Query the database to authenticate the user
  pool.query('SELECT * FROM users WHERE username = $1 AND password = $2',
             [username, password], (err, result) => {
    if (err) throw err;
    if (result.rowCount === 1) {
      const access_key = 'random_string';
      res.set('access_key', access_key).redirect('/profile');
    } else {
      res.status(401).render('unauthorized');
    }
  });
});

app.get('/logout', authenticate, (req, res) => {
  res.render('logout');
});

app.post('/logout', authenticate, (req, res) => {
  res.redirect('/login');
});

// Define the routes for the memberinfo endpoint
app.get('/profile', authenticate, (req, res) => {
  res.render('profile');
});

// Define the routes for adding, removing, and finding friends
app.get('/add_friend', authenticate, (req, res) => {
  res.render('add_friend');
});

app.post('/add_friend', authenticate, (req, res) => {
  const username = req.body.username;
  // Query the database to add the friend
  pool.query('INSERT INTO friends (username) VALUES ($1)', [username], (err, result) => {
    if (err) throw err;
    res.redirect('/profile');
  });
});

app.get('/remove_friend', authenticate, (req, res) => {
  res.render('remove_friend');
});

app.post('/remove_friend', authenticate, (req, res) => {
  const username = req.body.username;
  // Query the database to remove the friend
  pool.query('DELETE FROM friends WHERE username = $1', [username], (err, result) => {
    if (err) throw err;
    res.redirect('/profile');
  });
});

app.get('/find_friend', authenticate, (req, res) => {
  res.render('find_friend');
});

app.post('/find_friend', authenticate, (req, res) => {
  const username = req.body.username;
  // Query the database to find the friend
  pool.query('SELECT * FROM friends WHERE username = $1', [username], (err, result) => {
    if (err) throw err;
    if (result.rowCount === 1) {
      const friend = result.rows[0];
      res.render('friend', { friend: friend });
    } else {
      res.render('friend_not_found', { username: username });
    }
  });
});

// Define the routes for adding and commenting on SNS posts
app.get('/new_post', authenticate, (req, res) => {
  res.render('new_post');
});

app.post('/new_post', authenticate, (req, res) => {
  const text = req.body.text;
  // Query the database to add the post
  pool.query('INSERT INTO posts (text) VALUES ($1)', [text], (err, result) => {
    if (err) throw err;
    res.redirect('/feed');
  });
});

app.get('/feed', authenticate, (req, res) => {
  // Query the database to get all the posts with their comments
  pool.query('SELECT * FROM posts LEFT JOIN comments ON posts.id = comments.post_id',
             (err, result) => {
    if (err) throw err;
    const posts = [];
    let current_post = null;
    for (const row of result.rows) {
      if (row.text !== current_post?.text) {
        // Start a new post
        current_post = {
          text: row.text,
          comments: []
        };
        posts.push(current_post);
      }
      if (row.comment_text) {
        // Add a comment to the current post
        current_post.comments.push(row.comment_text);
      }
    }
    res.render('feed', { posts: posts });
  });
});

app.post('/comment', authenticate, (req, res) => {
  const post_id = req.body.post_id;
  const text = req.body.text;
  // Query the database to add the comment
  pool.query('INSERT INTO comments (post_id, text) VALUES ($1, $2)', [post_id, text], (err, result) => {
    if (err) throw err;
    res.redirect('/feed');
  });
});

// Define the route for checking disk usage
app.get('/df', authenticate, (req, res) => {
  const { exec } = require('child_process');
  exec('df -h', (err, stdout, stderr) => {
    if (err) throw err;
    res.send(stdout);
  });
});

// Start the server on port 3000
app.listen(3000, () => {
  console.log('Server started on port 3000');
});