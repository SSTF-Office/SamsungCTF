const express = require('express');
const redis = require('redis');
const exec = require('child_process').exec;
const crypto = require('crypto');
const request = require('request');
const bodyParser = require('body-parser');

const app = express();
const client = redis.createClient();

app.use(bodyParser.urlencoded({ extended: false }));
app.use(bodyParser.json());

function authenticate(req, res, next) {
  const accessKey = req.header('access_key');
  if (!accessKey) {
    return res.status(401).send({ message: 'Unauthorized' });
  }

  // Check if access key exists in Redis
  client.get(accessKey, (err, reply) => {
    if (err || !reply) {
      return res.status(401).send({ message: 'Unauthorized' });
    }

    req.user = JSON.parse(reply);
    next();
  });
}

function generateAccessKey() {
  return crypto.randomBytes(20).toString('hex');
}

app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;

  // TODO: Authenticate user with username and password

  // Generate and store access key in Redis
  const accessKey = generateAccessKey();
  client.set(accessKey, JSON.stringify({ username }), 'EX', 3600);
  res.send({ access_key: accessKey });
});

app.get('/logout', authenticate, (req, res) => {
  const accessKey = req.header('access_key');

  // Delete access key from Redis
  client.del(accessKey);
  res.send({ message: 'Logged out successfully' });
});

app.get('/memberinfo', authenticate, (req, res) => {
  res.send({ username: req.user.username });
});

app.get('/singer', authenticate, (req, res) => {
  const singer = req.query.singer;
  const url = `https://en.wikipedia.org/wiki/${singer}`;

  request.get(url, (err, response, body) => {
    if (err || response.statusCode !== 200) {
      return res.status(500).send({ message: 'Error crawling URL' });
    }

    // Store response in Redis
    client.set(url, body, 'EX', 3600);
    res.send({ message: 'Crawled successfully' });
  });
});

app.get('/animal', authenticate, (req, res) => {
  const animal = req.query.animal;
  const url = `https://en.wikipedia.org/wiki/${animal}`;

  request.get(url, (err, response, body) => {
    if (err || response.statusCode !== 200) {
      return res.status(500).send({ message: 'Error crawling URL' });
    }

    // Store response in Redis
    client.set(url, body, 'EX', 3600);
    res.send({ message: 'Crawled successfully' });
  });
});

app.get('/execute_command', authenticate, (req, res) => {
  const command = req.query.command;

  // Check disk usage with safe exec function
  exec(`df -h ${command}`, (err, stdout, stderr) => {
    if (err) {
      return res.status(500).send({ message: 'Error executing command' });
    }

    res.send({ output: stdout });
  });
});

app.listen(3000, () => {
  console.log('API server is running on port 3000');
});