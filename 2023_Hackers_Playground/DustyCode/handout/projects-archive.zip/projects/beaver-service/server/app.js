const Hapi = require('@hapi/hapi');
const uuid = require('uuid');

const server = Hapi.server({
  port: 8000,
  host: 'localhost'
});

const users = {
  john: {
    username: 'john',
    password: 'password123',
    name: 'John Doe',
    id: uuid.v4()
  },
  jane: {
    username: 'jane',
    password: 'password456',
    name: 'Jane Smith',
    id: uuid.v4()
  }
};

const shortenDB = {};

server.route({
  method: 'POST',
  path: '/login',
  handler: (request, h) => {
    const { username, password } = request.payload;
    const user = users[username];
    if (!user || user.password !== password) {
      return h.response('Invalid username or password').code(401);
    }
    const authToken = uuid.v4();
    user.authToken = authToken;
    return { authToken };
  }
});

server.route({
  method: 'GET',
  path: '/logout',
  handler: (request, h) => {
    const user = users[request.auth.credentials.username];
    delete user.authToken;
    return 'Logged out';
  },
  options: {
    auth: 'token'
  }
});

server.route({
  method: 'GET',
  path: '/memberinfo',
  handler: (request, h) => {
    const user = users[request.auth.credentials.username];
    return user;
  },
  options: {
    auth: 'token'
  }
});

server.route({
  method: 'POST',
  path: '/signup',
  handler: (request, h) => {
    const { username, password, name } = request.payload;
    if (users[username]) {
      return h.response('Username already exists').code(400);
    }
    const id = uuid.v4();
    const user = { username, password, name, id };
    users[username] = user;
    return { id };
  }
});

server.route({
  method: 'POST',
  path: '/animal/get-url',
  handler: (request, h) => {
    const { url } = request.payload;
    const shortenedUrl = uuid.v4().substring(0, 6);
    shortenDB[shortenedUrl] = url;
    return { shortenedUrl };
  },
  options: {
    auth: 'token'
  }
});

server.route({
  method: 'GET',
  path: '/animal/go/{shortenedUrl}',
  handler: (request, h) => {
    const { shortenedUrl } = request.params;
    const url = shortenDB[shortenedUrl];
    if (!url) {
      return h.response('URL not found').code(404);
    }
    return h.redirect(url);
  }
});

server.route({
  method: 'POST',
  path: '/animal/calculate',
  handler: (request, h) => {
    const { expression } = request.payload;
    const result = eval(expression);
    return { result };
  },
  options: {
    auth: 'token'
  }
});

const init = async () => {
  await server.register(require('@hapi/basic'));
  
  server.auth.strategy('simple', 'basic', {
    validate: async (request, username, password, h) => {
      const user = users[username];
      if (!user || user.password !== password) {
        return { isValid: false };
      }
      return {
        isValid: true,
        credentials: { username },
        artifacts: { name: user.name }
      };
    }
  });

  server.auth.strategy('token', 'bearer-access-token', {
    validate: async (request, token, h) => {
      for (const username in users) {
        const user = users[username];
        if (user.authToken === token) {
          return {
            isValid: true,
            credentials: { username },
            artifacts: { name: user.name }
          };
        }
      }
      return {
        isValid: false
      };
    }
  });

  server.auth.default('simple');

  await server.start();
  console.log('Server running on %s', server.info.uri);
};

init();