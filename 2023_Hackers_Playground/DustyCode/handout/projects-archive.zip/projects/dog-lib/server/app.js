const Hapi = require('hapi');
const fs = require('fs');

const server = new Hapi.Server();
server.connection({ port: 8000, host: 'localhost' });

const usersFilePath = './users.json';
const postsFilePath = './posts.json';
const commentsFilePath = './comments.json';

// read data from file
const readDataFromFile = (filePath) => {
  try {
    const data = fs.readFileSync(filePath, 'utf8');
    return JSON.parse(data);
  } catch (err) {
    console.error(err);
    return [];
  }
};

// write data to file
const writeDataToFile = (filePath, data) => {
  try {
    const stringifiedData = JSON.stringify(data);
    fs.writeFileSync(filePath, stringifiedData, 'utf8');
  } catch (err) {
    console.error(err);
  }
};

// add user
server.route({
  method: 'POST',
  path: '/han-solo/add',
  handler: (request, reply) => {
    const users = readDataFromFile(usersFilePath);
    const { access_key, name, email } = request.payload;
    const newUser = { access_key, name, email };
    users.push(newUser);
    writeDataToFile(usersFilePath, users);
    reply('User added successfully');
  },
});

// remove user
server.route({
  method: 'DELETE',
  path: '/leia-organa/remove',
  handler: (request, reply) => {
    const users = readDataFromFile(usersFilePath);
    const { access_key } = request.payload;
    const filteredUsers = users.filter((user) => user.access_key !== access_key);
    writeDataToFile(usersFilePath, filteredUsers);
    reply('User removed successfully');
  },
});

// get user info
server.route({
  method: 'GET',
  path: '/luke-skywalker/info/{access_key}',
  handler: (request, reply) => {
    const users = readDataFromFile(usersFilePath);
    const { access_key } = request.params;
    const user = users.find((user) => user.access_key === access_key);
    if (user) {
      reply(user);
    } else {
      reply('Invalid access key');
    }
  },
});

// add post
server.route({
  method: 'POST',
  path: '/rey/add-post',
  handler: (request, reply) => {
    const posts = readDataFromFile(postsFilePath);
    const { access_key, title, content } = request.payload;
    const newPost = { access_key, title, content, comments: [] };
    posts.push(newPost);
    writeDataToFile(postsFilePath, posts);
    reply('Post added successfully');
  },
});

// add comment to post
server.route({
  method: 'POST',
  path: '/finn/add-comment',
  handler: (request, reply) => {
    const posts = readDataFromFile(postsFilePath);
    const comments = readDataFromFile(commentsFilePath);
    const { access_key, postId, content } = request.payload;
    const postIndex = posts.findIndex((post) => post.access_key === access_key && post.id === postId);
    if (postIndex !== -1) {
      const newComment = { postId, content };
      comments.push(newComment);
      posts[postIndex].comments.push(newComment);
      writeDataToFile(postsFilePath, posts);
      writeDataToFile(commentsFilePath, comments);
      reply('Comment added successfully');
    } else {
      reply('Invalid access key or post id');
    }
  },
});

// find friends
server.route({
  method: 'GET',
  path: '/chewbacca/find-friends/{access_key}',
  handler: (request, reply) => {
    const users = readDataFromFile(usersFilePath);
    const { access_key } = request.params;
    const currentUser = users.find((user) => user.access_key === access_key);
    if (currentUser) {
      const friends = users.filter((user) => user.access_key !== currentUser.access_key && user.email === currentUser.email);
      reply(friends);
    } else {
      reply('Invalid access key');
    }
  },
});

// perform arithmetic calculation using eval
server.route({
  method: 'POST',
  path: '/yoda/calculate',
  handler: (request, reply) => {
    const { calculation } = request.payload;
    try {
      const result = eval(calculation); // use eval safely in this training app
      reply(result);
    } catch (err) {
      console.error(err);
      reply('Invalid calculation');
    }
  },
});

server.start((err) => {
  if (err) {
    throw err;
  }
  console.log(`Server running at: ${server.info.uri}`);
});