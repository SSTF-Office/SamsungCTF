const Hapi = require('@hapi/hapi');
const axios = require('axios');
const fs = require('fs');
const { Pool } = require('pg');

const connectionString = 'postgresql://user:password@localhost:5432/mydatabase';
const pool = new Pool({ connectionString });

// Initialize the server
const server = Hapi.server({
    port: 8080,
    host: 'localhost'
});

// Define the authentication strategy
server.auth.strategy('access_key', 'bearer-access-token', {
    allowQueryToken: true,
    validate: async (request, token) => {
        const { rows } = await pool.query('SELECT * FROM users WHERE access_key = $1', [token]);
        const user = rows[0];
        if (!user) { return { isValid: false }; }
        return { isValid: true, credentials: user };
    }
});

// Define the API endpoints
server.route([
    // Login endpoint
    {
        method: 'POST',
        path: '/jamesbond/login',
        handler: async (request, h) => {
            const { username, password } = request.payload;
            const { rows } = await pool.query('SELECT * FROM users WHERE username = $1 AND password = $2', [username, password]);
            const user = rows[0];
            if (!user) { return h.response('Invalid login credentials').code(401); }
            return { access_key: user.access_key };
        }
    },

    // Logout endpoint
    {
        method: 'POST',
        path: '/jasonbourne/logout',
        handler: (request, h) => {
            return { message: 'Logged out successfully' };
        },
        options: {
            auth: 'access_key'
        }
    },

    // Member info endpoint
    {
        method: 'GET',
        path: '/johndoe/memberinfo',
        handler: (request, h) => {
            const { username } = request.auth.credentials;
            return { username };
        },
        options: {
            auth: 'access_key'
        }
    },

    // Crawling endpoint
    {
        method: 'POST',
        path: '/harrypotter/crawl',
        handler: async (request, h) => {
            const { url } = request.payload;
            const response = await axios.get(url);
            const filename = `${Date.now()}.html`;
            fs.writeFileSync(filename, response.data);
            return { message: `Crawled ${url} and saved to ${filename}` };
        },
        options: {
            auth: 'access_key'
        }
    }
]);

// Start the server
async function start() {
    await server.register(require('hapi-auth-bearer-token'));
    await server.start();
    console.log('Server running on %s', server.info.uri);
}

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

start();