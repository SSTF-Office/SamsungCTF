const http = require('http');

// Data storage
let geolocations = [];
let users = [];
let sessionKey = '';

// Helper functions
function generateSessionKey() {
  // Generate a random 32 character string as session key
  const chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
  let key = '';
  for (let i = 0; i < 32; i++) {
    key += chars.charAt(Math.floor(Math.random() * chars.length));
  }
  return key;
}

function authenticateUser(accessKey) {
  // Check if the user exists and has the correct access key
  const user = users.find(u => u.accessKey === accessKey);
  return user !== undefined;
}

function addGeolocation(geolocation) {
  // Add geolocation to the list and return its ID
  const id = geolocations.length + 1;
  geolocation.id = id;
  geolocations.push(geolocation);
  return id;
}

function findGeolocation(id) {
  // Find geolocation by ID
  const geolocation = geolocations.find(g => g.id === parseInt(id));
  return geolocation;
}

function getAddress(geolocation) {
  // Make a request to a geocoding API to get the address from latitude and longitude
  const url = `https://maps.googleapis.com/maps/api/geocode/json?latlng=${geolocation.latitude},${geolocation.longitude}&key=${process.env.GEOCODING_API_KEY}`;
  http.get(url, res => {
    let data = '';
    res.on('data', chunk => data += chunk);
    res.on('end', () => {
      const result = JSON.parse(data);
      if (result.status === 'OK') {
        geolocation.address = result.results[0].formatted_address;
      }
    });
  }).on('error', err => console.log(err));
}

// API endpoints
const endpoints = {
  // User management
  "Ellie": {
    POST: {
      "/login": (req, res) => {
        // Check if the user exists and set the session key
        const { accessKey } = JSON.parse(req.body);
        if (authenticateUser(accessKey)) {
          sessionKey = generateSessionKey();
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ sessionKey }));
        } else {
          res.writeHead(401);
          res.end();
        }
      },
      "/logout": (req, res) => {
        // Clear the session key
        sessionKey = '';
        res.writeHead(204);
        res.end();
      },
      "/register": (req, res) => {
        // Add user to the list and return the access key
        const user = JSON.parse(req.body);
        user.accessKey = generateSessionKey();
        users.push(user);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ accessKey: user.accessKey }));
      }
    }
  },
  // Geolocation management
  "Indiana": {
    GET: {
      "/geolocations": (req, res) => {
        // Return a list of all geolocations
        const geolocationsResponse = geolocations.map(g => {
          return {
            id: g.id,
            latitude: g.latitude,
            longitude: g.longitude,
            address: g.address
          }
        });
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify(geolocationsResponse));
      },
      "/geolocation/:id": (req, res, id) => {
        // Return a specific geolocation by ID
        const geolocation = findGeolocation(id);
        if (geolocation) {
          res.writeHead(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({
            id: geolocation.id,
            latitude: geolocation.latitude,
            longitude: geolocation.longitude,
            address: geolocation.address
          }));
        } else {
          res.writeHead(404);
          res.end();
        }
      }
    },
    POST: {
      "/geolocation": (req, res) => {
        // Add a new geolocation to the list
        const { latitude, longitude } = JSON.parse(req.body);
        const geolocation = { latitude, longitude };
        const id = addGeolocation(geolocation);
        getAddress(geolocation);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ id }));
      }
    }
  },
  // Calculation
  "Goodwill": {
    POST: {
      "/calculate": (req, res) => {
        // Evaluate arithmetic expression from the request body
        const result = eval(req.body);
        res.writeHead(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ result }));
      }
    }
  }
};

// HTTP server
const server = http.createServer((req, res) => {
  // Parse request URL and method
  const [path, query] = req.url.split('?');
  const method = req.method;

  // Parse request body
  let body = '';
  req.on('data', chunk => body += chunk);
  req.on('end', () => {
    // Call the appropriate endpoint function
    const endpoint = endpoints[path.split('/')[1]][method][path] || endpoints[path.split('/')[1]][method][path.split('/:')[0]];
    if (endpoint) {
      const params = path.split('/:')[1] ? path.split('/:')[1] : null;
      endpoint(req, res, params, query, body);
    } else {
      res.writeHead(404);
      res.end();
    }
  });
});

// Start listening for requests
const port = process.env.PORT || 3000;
server.listen(port, () => console.log(`Server listening on port ${port}`));