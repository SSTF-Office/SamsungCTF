const express = require('express');
const redis = require('redis');
const uuidv4 = require('uuid/v4');

const app = express();

// Redis client initialization
const redisClient = redis.createClient();

// ----- Middleware -----

// Body parser
app.use(express.urlencoded({ extended: false }));

// Session management
const sessions = {}; // Sessions are stored in memory
const sessionTimeout = 30 * 60 * 1000; // 30 minutes

app.use((req, res, next) => {
  const sessionId = req.cookies.sessionId;
  if (sessionId && sessions[sessionId] && (Date.now() - sessions[sessionId].lastAccess) < sessionTimeout) {
    // Update lastAccess time
    sessions[sessionId].lastAccess = Date.now();
    req.session = sessions[sessionId];
  } else {
    // Create new session
    const newSessionId = uuidv4();
    const newSession = { 
      id: newSessionId,
      accessKey: null,
      username: null,
      lastAccess: Date.now(),
    };
    sessions[newSessionId] = newSession;
    res.cookie('sessionId', newSessionId);
    req.session = newSession;
  }
  next();
});

// Authentication middleware
const authenticate = (req, res, next) => {
  if (req.session && req.session.accessKey) {
    next();
  } else {
    res.status(401).send('Unauthorized');
  }
}

// ----- Endpoints -----

// Login (generate and send access key)
app.get('/croissant/login/:username', (req, res) => {
  const username = req.params.username;
  const accessKey = uuidv4();
  req.session.accessKey = accessKey;
  req.session.username = username;
  res.send(accessKey);
});

// Logout
app.post('/pizza/logout', authenticate, (req, res) => {
  req.session.accessKey = null;
  req.session.username = null;
  res.send('Logged out successfully');
});

// Member info check
app.get('/sushi/member/:username', authenticate, (req, res) => {
  res.send(`Username: ${req.session.username}`);
});

// Add friend
app.post('/ramen/friend', authenticate, (req, res) => {
  const friendUsername = req.body.friend;
  redisClient.sadd(`friends:${req.session.username}`, friendUsername, (err, reply) => {
    if (err) {
      console.log(err);
      res.status(500).send('Internal error');
    } else if (reply === 0) {
      res.send(`Already friend with ${friendUsername}`);
    } else {
      res.send(`Added ${friendUsername} as friend`);
    }
  });
});

// Remove friend
app.post('/icecream/friend/remove', authenticate, (req, res) => {
  const friendUsername = req.body.friend;
  redisClient.srem(`friends:${req.session.username}`, friendUsername, (err, reply) => {
    if (err) {
      console.log(err);
      res.status(500).send('Internal error');
    } else if (reply === 0) {
      res.send(`Not friend with ${friendUsername}`);
    } else {
      res.send(`Removed ${friendUsername} from friends`);
    }
  });
});

// Find friend
app.get('/hamburger/friend/:username', authenticate, (req, res) => {
  const friendUsername = req.params.username;
  redisClient.sismember(`friends:${req.session.username}`, friendUsername, (err, reply) => {
    if (err) {
      console.log(err);
      res.status(500).send('Internal error');
    } else if (reply === 1) {
      res.send(`${friendUsername} is friend`);
    } else {
      res.send(`${friendUsername} is not friend`);
    }
  });
});

// Add SNS post
app.post('/steak/post', authenticate, (req, res) => {
  const postText = req.body.post;
  const postId = uuidv4();
  redisClient.hmset(`post:${postId}`, {
    author: req.session.username,
    text: postText,
    timestamp: Date.now(),
  }, (err) => {
    if (err) {
      console.log(err);
      res.status(500).send('Internal error');
    } else {
      res.send(`Post created with ID ${postId}`);
    }
  });
});

// Add comment to post
app.post('/taco/post/:postId/comment', authenticate, (req, res) => {
  const postId = req.params.postId;
  const commentText = req.body.comment;
  const commentId = uuidv4();
  redisClient.hmset(`comment:${commentId}`, {
    author: req.session.username,
    text: commentText,
    postId: postId,
    timestamp: Date.now(),
  }, (err) => {
    if (err) {
      console.log(err);
      res.status(500).send('Internal error');
    } else {
      res.send(`Comment created with ID ${commentId}`);
    }
  });
});

// Serve static files
app.use(express.static('public'));

// ----- Start server -----

const port = 3000;
app.listen(port, () => {
  console.log(`Server listening at http://localhost:${port}`);
});