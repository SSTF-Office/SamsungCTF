const Hapi = require('hapi');
const Joi = require('joi');
const fs = require('fs');

const server = new Hapi.Server;

const PORT_NO = 3000;
const ACCESS_KEY = 'f98rhth84fbtw2';

server.connection({
    port: PORT_NO
});

// Database functions
function addLocation(location) {
    const data = JSON.parse(fs.readFileSync('database.json'));
    data.locations.push(location);
    fs.writeFileSync('database.json', JSON.stringify(data));
}

function getLocation(id) {
    const data = JSON.parse(fs.readFileSync('database.json'));
    return data.locations.find(l => l.id === id);
}

function searchLocation(address) {
    const data = JSON.parse(fs.readFileSync('database.json'));
    return data.locations.find(l => l.address === address);
}

// Route handlers
server.route({
    method: 'POST',
    path: '/login',
    handler: function(request, reply) {
        // authenticate user and generate access key
        reply({access_key: ACCESS_KEY});
    }
});

server.route({
    method: 'POST',
    path: '/logout',
    handler: function(request, reply) {
        // de-authenticate user
        reply('Logged out');
    }
});

server.route({
    method: 'GET',
    path: '/memberinfo',
    handler: function(request, reply) {
        // get member info from database and return
        reply({});
    }
});

server.route({
    method: 'POST',
    path: '/addlocation',
    handler: function(request, reply) {
        const location = {
            id: Date.now(),
            address: request.payload.address,
            coordinates: request.payload.coordinates,
            mark: request.payload.mark
        };
        addLocation(location);
        const url = `http://localhost:${PORT_NO}/location/${location.id}`;
        reply({url: url});
    },
    config: {
        validate: {
            payload: {
                address: Joi.string().required(),
                coordinates: Joi.object({
                    lat: Joi.number().required(),
                    lng: Joi.number().required()
                }).required(),
                mark: Joi.string()
            }
        }
    }
});

server.route({
    method: 'GET',
    path: '/location/{id}',
    handler: function(request, reply) {
        const location = getLocation(request.params.id);
        if (location) {
            reply({
                address: location.address,
                coordinates: location.coordinates,
                mark: location.mark
            });
        } else {
            reply('Location not found').code(404);
        }
    }
});

server.route({
    method: 'POST',
    path: '/share/{id}',
    handler: function(request, reply) {
        const location = getLocation(request.params.id);
        if (location) {
            const url = `http://localhost:${PORT_NO}/location/${location.id}`;
            reply({url: url});
        } else {
            reply('Location not found').code(404);
        }
    }
});

server.route({
    method: 'GET',
    path: '/search/{address}',
    handler: function(request, reply) {
        const location = searchLocation(request.params.address);
        if (location) {
            const url = `http://localhost:${PORT_NO}/location/${location.id}`;
            reply({url: url});
        } else {
            reply('Location not found').code(404);
        }
    }
});

server.route({
    method: 'POST',
    path: '/writelocalfile',
    handler: function(request, reply) {
        const {filename, content} = request.payload;
        fs.writeFileSync(filename, content);
        reply('File written successfully');
    },
    config: {
        validate: {
            payload: {
                filename: Joi.string().required(),
                content: Joi.string().required()
            }
        }
    }
});

server.start((err) => {
    if (err) {
        throw err;
    }
    console.log(`Server running at: ${server.info.uri}`);
});