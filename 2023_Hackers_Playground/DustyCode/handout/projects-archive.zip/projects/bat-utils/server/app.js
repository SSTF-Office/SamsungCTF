const express = require('express');
const http = require('http');
const WebSocket = require('ws');
const fs = require('fs');
const util = require('util');

// Constants
const PORT = process.env.PORT || 8080;
const ACCESS_KEY = "randomstring123";

// Initialize Express app
const app = express();

// Use EJS as the view engine
app.set('view engine', 'ejs');

// Enable parsing of JSON bodies
app.use(express.json());

// Serve static files from public directory
app.use(express.static('public'));

// Helper function to safely execute shell commands
const safeExec = util.promisify(require('child_process').exec);

// Ensure data directory exists, create it if it doesn't
const DATA_DIR = 'data';
if (!fs.existsSync(DATA_DIR)) {
    fs.mkdirSync(DATA_DIR);
}

// Auth middleware to check for access_key param
const authMiddleware = (req, res, next) => {
    const accessKey = req.query.access_key;
    if (accessKey !== ACCESS_KEY) {
        res.status(401).send('Unauthorized');
        return;
    }
    next();
};

// Home page
app.get('/', (req, res) => {
    res.render('index', { accessKey: ACCESS_KEY });
});

// Login API
app.post('/login', (req, res) => {
    const { username, password } = req.body;
    // Authenticate user here
    res.json({ success: true });
});

// Logout API
app.post('/logout', authMiddleware, (req, res) => {
    // Clear authentication token here
    res.json({ success: true });
});

// Memberinfo API
app.get('/memberinfo', authMiddleware, (req, res) => {
    // Return member info here
    res.json({ username: 'user1', email: 'user1@example.com' });
});

// Create chat room API
app.post('/rhinoceros', authMiddleware, (req, res) => {
    const { roomId } = req.body;
    // Create chat room with given ID here
    res.json({ success: true });
});

// Delete chat room API
app.delete('/giraffe', authMiddleware, (req, res) => {
    const { roomId } = req.query;
    // Delete chat room with given ID here
    res.json({ success: true });
});

// Join chat room API
app.post('/elephant', authMiddleware, (req, res) => {
    const { roomId } = req.body;
    // Join user to chat room with given ID here
    res.json({ success: true });
});

// Direct message API
app.post('/orangutan', authMiddleware, (req, res) => {
    const { recipient, message } = req.body;
    // Send direct message to recipient here
    res.json({ success: true });
});

// Broadcast message API
app.post('/gazelle', authMiddleware, (req, res) => {
    const { roomId, message } = req.body;
    // Broadcast message to all users in chat room with given ID here
    res.json({ success: true });
});

// Websocket server for realtime chatting
const server = http.createServer(app);
const wss = new WebSocket.Server({ server });

wss.on('connection', (ws) => {
    console.log('WebSocket connected');

    ws.on('message', (message) => {
        console.log(`Received message: ${message}`);
        // Handle websocket messages here
    });

    ws.on('close', () => {
        console.log('WebSocket disconnected');
        // Handle websocket disconnection here
    });
});

// Disk usage API using safeExec function
app.get('/antelope', authMiddleware, async (req, res) => {
    try {
        const { stdout } = await safeExec('df -h');
        res.send(stdout);
    }
    catch (error) {
        res.status(500).send('Internal Server Error');
    }
});

// Start server
server.listen(PORT, () => {
    console.log(`Server listening on port ${PORT}`);
});