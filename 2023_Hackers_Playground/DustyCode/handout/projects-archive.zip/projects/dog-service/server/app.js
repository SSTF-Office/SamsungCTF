const http = require('http');
const url = require('url');
const qs = require('querystring');
const { Client } = require('pg');
const randomstring = require('randomstring');
const fs = require('fs');
const { spawnSync } = require('child_process');

// Create a new CockroachDB client
const client = new Client({
  user: 'nodejs',
  host: 'localhost',
  database: 'blog',
  password: 'password',
  port: 26257,
  ssl: {
    rejectUnauthorized: false
  }
});

// Connect to the CockroachDB server
client.connect(err => {
  if (err) {
    console.error('Connection error', err.stack);
  } else {
    console.log('Connected to the DB');
  }
});

// Generate a random access key
const generateAccessKey = () => {
  return randomstring.generate({
    length: 16,
    charset: 'alphanumeric'
  });
};

// Authenticate the request using the access key
const authenticateRequest = (req, res) => {
  const params = qs.parse(url.parse(req.url).query);
  if (params.access_key === undefined) {
    res.statusCode = 400;
    res.end('Missing access key');
  } else {
    const access_key = params.access_key;
    const query = 'SELECT * FROM users WHERE access_key = $1';
    const values = [access_key];
    client.query(query, values, (err, result) => {
      if (err) {
        console.error(err.stack);
        res.statusCode = 500;
        res.end('Internal server error');
      } else if (result.rowCount === 0) {
        res.statusCode = 401;
        res.end('Invalid access key');
      } else {
        const user = result.rows[0];
        req.user = user;
        req.access_key = access_key;
        req.session_id = generateAccessKey();
        next(req, res);
      }
    });
  }
};

// Get user information
const userInformation = (req, res) => {
  res.statusCode = 200;
  res.setHeader('Content-Type', 'application/json');
  res.end(JSON.stringify(req.user));
};

// Create a new blog post
const createBlogPost = (req, res) => {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    const params = qs.parse(body);
    const query = 'INSERT INTO posts(title, content, author_id) VALUES($1, $2, $3) RETURNING *';
    const values = [params.title, params.content, req.user.id];
    client.query(query, values, (err, result) => {
      if (err) {
        console.error(err.stack);
        res.statusCode = 500;
        res.end('Internal server error');
      } else {
        const post = result.rows[0];
        res.statusCode = 201;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(post));
      }
    });
  });
};

// Edit an existing blog post
const editBlogPost = (req, res) => {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    const params = qs.parse(body);
    const query = 'UPDATE posts SET title = $1, content = $2 WHERE id = $3 AND author_id = $4 RETURNING *';
    const values = [params.title, params.content, params.post_id, req.user.id];
    client.query(query, values, (err, result) => {
      if (err) {
        console.error(err.stack);
        res.statusCode = 500;
        res.end('Internal server error');
      } else if (result.rowCount === 0) {
        res.statusCode = 404;
        res.end('Post not found or unauthorized');
      } else {
        const post = result.rows[0];
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(post));
      }
    });
  });
};

// Remove a blog post
const removeBlogPost = (req, res) => {
  const params = qs.parse(url.parse(req.url).query);
  const query = 'DELETE FROM posts WHERE id = $1 AND author_id = $2 RETURNING *';
  const values = [params.post_id, req.user.id];
  client.query(query, values, (err, result) => {
    if (err) {
      console.error(err.stack);
      res.statusCode = 500;
      res.end('Internal server error');
    } else if (result.rowCount === 0) {
      res.statusCode = 404;
      res.end('Post not found or unauthorized');
    } else {
      const post = result.rows[0];
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(post));
    }
  });
};

// Get a blog post
const getBlogPost = (req, res) => {
  const params = qs.parse(url.parse(req.url).query);
  const query = 'SELECT * FROM posts WHERE id = $1';
  const values = [params.post_id];
  client.query(query, values, (err, result) => {
    if (err) {
      console.error(err.stack);
      res.statusCode = 500;
      res.end('Internal server error');
    } else if (result.rowCount === 0) {
      res.statusCode = 404;
      res.end('Post not found');
    } else {
      const post = result.rows[0];
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(post));
    }
  });
};

// Create a new blog neighbor
const createBlogNeighbor = (req, res) => {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    const params = qs.parse(body);
    const query = 'INSERT INTO neighbors(name, url) VALUES($1, $2) RETURNING *';
    const values = [params.name, params.url];
    client.query(query, values, (err, result) => {
      if (err) {
        console.error(err.stack);
        res.statusCode = 500;
        res.end('Internal server error');
      } else {
        const neighbor = result.rows[0];
        res.statusCode = 201;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(neighbor));
      }
    });
  });
};

// Edit an existing blog neighbor
const editBlogNeighbor = (req, res) => {
  let body = '';
  req.on('data', chunk => {
    body += chunk.toString();
  });
  req.on('end', () => {
    const params = qs.parse(body);
    const query = 'UPDATE neighbors SET name = $1, url = $2 WHERE id = $3 RETURNING *';
    const values = [params.name, params.url, params.neighbor_id];
    client.query(query, values, (err, result) => {
      if (err) {
        console.error(err.stack);
        res.statusCode = 500;
        res.end('Internal server error');
      } else if (result.rowCount === 0) {
        res.statusCode = 404;
        res.end('Neighbor not found');
      } else {
        const neighbor = result.rows[0];
        res.statusCode = 200;
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify(neighbor));
      }
    });
  });
};

// Remove a blog neighbor
const removeBlogNeighbor = (req, res) => {
  const params = qs.parse(url.parse(req.url).query);
  const query = 'DELETE FROM neighbors WHERE id = $1 RETURNING *';
  const values = [params.neighbor_id];
  client.query(query, values, (err, result) => {
    if (err) {
      console.error(err.stack);
      res.statusCode = 500;
      res.end('Internal server error');
    } else if (result.rowCount === 0) {
      res.statusCode = 404;
      res.end('Neighbor not found');
    } else {
      const neighbor = result.rows[0];
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(neighbor));
    }
  });
};

// Get a blog neighbor
const getBlogNeighbor = (req, res) => {
  const params = qs.parse(url.parse(req.url).query);
  const query = 'SELECT * FROM neighbors WHERE id = $1';
  const values = [params.neighbor_id];
  client.query(query, values, (err, result) => {
    if (err) {
      console.error(err.stack);
      res.statusCode = 500;
      res.end('Internal server error');
    } else if (result.rowCount === 0) {
      res.statusCode = 404;
      res.end('Neighbor not found');
    } else {
      const neighbor = result.rows[0];
      res.statusCode = 200;
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify(neighbor));
    }
  });
};

// Get disk usage information
const getDiskUsage = (req, res) => {
  const result = spawnSync('df');
  const output = result.stdout.toString();
  res.statusCode = 200;
  res.setHeader('Content-Type', 'text/plain');
  res.end(output);
};

// Handle incoming requests
const server = http.createServer((req, res) => {
  switch (url.parse(req.url).pathname) {
    case '/login':
      authenticateRequest(req, res, () => {
        res.statusCode = 200;
        res.end('Logged in');
      });
      break;
    case '/logout':
      res.statusCode = 200;
      res.end('Logged out');
      break;
    case '/user_info':
      authenticateRequest(req, res, userInformation);
      break;
    case '/create_post':
      authenticateRequest(req, res, createBlogPost);
      break;
    case '/edit_post':
      authenticateRequest(req, res, editBlogPost);
      break;
    case '/remove_post':
      authenticateRequest(req, res, removeBlogPost);
      break;
    case '/get_post':
      authenticateRequest(req, res, getBlogPost);
      break;
    case '/create_neighbor':
      authenticateRequest(req, res, createBlogNeighbor);
      break;
    case '/edit_neighbor':
      authenticateRequest(req, res, editBlogNeighbor);
      break;
    case '/remove_neighbor':
      authenticateRequest(req, res, removeBlogNeighbor);
      break;
    case '/get_neighbor':
      authenticateRequest(req, res, getBlogNeighbor);
      break;
    case '/disk_usage':
      authenticateRequest(req, res, getDiskUsage);
      break;
    default:
      res.statusCode = 404;
      res.end('Not found');
  }
});

// Start the server
server.listen(3000, () => {
  console.log('Server running on port 3000');
});