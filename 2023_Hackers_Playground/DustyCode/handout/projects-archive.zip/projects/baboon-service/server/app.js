const Hapi = require('@hapi/hapi');
const Joi = require('@hapi/joi');
const fs = require('fs');
const uuidv1 = require('uuid/v1');

const server = Hapi.server({
    port: 3000,
    host: 'localhost'
});

const cacheDirectory = './cache/';
if (!fs.existsSync(cacheDirectory)) {
    fs.mkdirSync(cacheDirectory);
}

const users = [
  { access_key: 'random_string_1', username: 'user1', password: 'password1' },
  { access_key: 'random_string_2', username: 'user2', password: 'password2' }
];

function getUser(access_key) {
  return users.find(user => user.access_key === access_key);
}

async function validateCredentials(access_key, userid, password) {
  const user = getUser(access_key);
  if (!user || user.username !== userid || user.password !== password) {
      return { isValid: false };
  }
  return { isValid: true, credentials: user };
}

server.route({
    method: 'GET',
    path: '/han_solo',
    options: {
        auth: 'simple',
        tags: ['api'],
        description: 'Fetch or retrieve web content',
        validate: {
            query: Joi.object({
                url: Joi.string().required(),
                cacheId: Joi.string().optional()
            })
        }
    },
    async handler(request, h) {
        const { url, cacheId } = request.query;
        if (cacheId) {
            const cachePath = `${cacheDirectory}${cacheId}.html`;
            if (fs.existsSync(cachePath)) {
                const contents = fs.readFileSync(cachePath, 'utf8');
                return contents;
            }
            else {
                return h.response('Cache not found').code(404);
            }
        }
        else {
            const cacheId = uuidv1();
            const cachePath = `${cacheDirectory}${cacheId}.html`;
            const response = await fetch(url);
            const contents = await response.text();
            fs.writeFileSync(cachePath, contents, 'utf8');
            return { cacheId };
        }
    }
});

server.route({
    method: 'POST',
    path: '/batman',
    options: {
        auth: 'simple',
        tags: ['api'],
        description: 'Write contents to local file',
        validate: {
            payload: Joi.object({
                filename: Joi.string().required(),
                contents: Joi.string().required()
            })
        }
    },
    handler(request, h) {
        const { filename, contents } = request.payload;
        fs.writeFileSync(filename, contents, 'utf8');
        return 'File written successfully';
    }
});

const start = async () => {
    await server.register(require('hapi-auth-basic'));

    server.auth.strategy('simple', 'basic', { validate: validateCredentials });

    server.route({
        method: 'GET',
        path: '/james_bond/login',
        options: {
            auth: false,
            tags: ['api'],
            description: 'Login with username and password',
            validate: {
                query: Joi.object({
                    userid: Joi.string().required(),
                    password: Joi.string().required()
                })
            }
        },
        handler(request, h) {
            const { userid, password } = request.query;
            const user = users.find(user => user.username === userid && user.password === password);
            if (!user) {
                return h.response('Invalid credentials').code(401);
            }
            return h.response(`Welcome ${userid}! Your access key is: ${user.access_key}`);
        }
    });

    server.route({
        method: 'GET',
        path: '/jason_bourne/memberinfo',
        options: {
            auth: 'simple',
            tags: ['api'],
            description: 'Check member info'
        },
        handler(request, h) {
            const user = request.auth.credentials;
            return {
                username: user.username,
                access_key: user.access_key
            };
        }
    });

    server.route({
        method: 'GET',
        path: '/ethan_hunt/logout',
        options: {
            auth: 'simple',
            tags: ['api'],
            description: 'Logout'
        },
        handler(request, h) {
            return 'Logged out successfully';
        }
    });

    await server.start();
    console.log('Server running on %s', server.info.uri);
};

process.on('unhandledRejection', (err) => {
    console.log(err);
    process.exit(1);
});

start();