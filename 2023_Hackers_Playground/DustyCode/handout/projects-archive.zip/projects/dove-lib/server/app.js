const Hapi = require('@hapi/hapi');
const Joi = require('joi');
const fs = require('fs');
const { exec } = require('child_process');

const server = Hapi.server({
    port: 3000, // Change to whatever port you want to use
    host: 'localhost',
});

server.route({
    method: 'GET',
    path: '/giraffe',
    handler: function (request, h) {
        return 'Welcome to the Geolocation sharing service!';
    }
});

// Login route
server.route({
    method: 'POST',
    path: '/giraffe/login',
    handler: function (request, h) {
        const { username, password } = request.payload;
        
        // Here you would check if the credentials are valid, but for simplicity purposes, we'll just assume they are valid and return an access token
        const accessToken = 'RANDOM_ACCESS_TOKEN';
        
        return { accessToken };
    },
    options: {
        validate: {
            payload: Joi.object({
                username: Joi.string().required(),
                password: Joi.string().required()
            })
        }
    }
});

// Logout route
server.route({
    method: 'POST',
    path: '/giraffe/logout',
    handler: function (request, h) {
        return 'Successfully logged out!';
    }
});

// Memberinfo check route
server.route({
    method: 'GET',
    path: '/giraffe/memberinfo',
    handler: function (request, h) {
        const { accessToken } = request.query;
        
        // Here you would check if the access token is valid and return the member's info, but for simplicity purposes, we'll just return some dummy info
        const memberInfo = {
            name: 'John Doe',
            email: 'john.doe@example.com'
        };
        
        return memberInfo;
    },
    options: {
        validate: {
            query: Joi.object({
                accessToken: Joi.string().required()
            })
        }
    }
});

// Geolocation search with address route
server.route({
    method: 'GET',
    path: '/eagle/geoloc',
    handler: function (request, h) {
        const { address, accessToken } = request.query;
        
        // Here you would search for the geolocation based on the address and return the coordinates, but for simplicity purposes, we'll just return some dummy coordinates
        const coordinates = {
            latitude: 37.7749,
            longitude: -122.4194
        };
        
        return coordinates;
    },
    options: {
        validate: {
            query: Joi.object({
                address: Joi.string().required(),
                accessToken: Joi.string().required()
            })
        }
    }
});

// Add mark to the geolocation route
server.route({
    method: 'POST',
    path: '/panda/geoloc/mark',
    handler: function (request, h) {
        const { coordinates, accessToken } = request.payload;
        
        // Here you would add the mark to the geolocation based on the coordinates, but for simplicity purposes, we'll just assume it's successful and return a success message
        return { message: 'Mark added successfully!' };
    },
    options: {
        validate: {
            payload: Joi.object({
                coordinates: Joi.object({
                    latitude: Joi.number().required(),
                    longitude: Joi.number().required()
                }).required(),
                accessToken: Joi.string().required()
            })
        }
    }
});

// Share link to other people route
server.route({
    method: 'POST',
    path: '/tiger/geoloc/share',
    handler: function (request, h) {
        const { accessToken } = request.payload;
        
        // Here you would share the link to the geolocation with other people based on the access token and return the link, but for simplicity purposes, we'll just return a dummy link
        const link = 'https://example.com/geolocation?lat=37.7749&lng=-122.4194';
        
        return { link };
    },
    options: {
        validate: {
            payload: Joi.object({
                accessToken: Joi.string().required()
            })
        }
    }
});

// Safe exec function to check disk usage
server.method('checkDiskUsage', async () => {
    return new Promise((resolve, reject) => {
        exec('df -h /', (error, stdout, stderr) => {
            if (error) {
                reject(error);
            }

            const output = stdout.toString();
            resolve(output);
        });
    });
});

// Example usage of safe exec function
server.route({
    method: 'GET',
    path: '/lion/checkdiskusage',
    handler: async (request, h) => {
        const diskUsage = await server.methods.checkDiskUsage();
        return { diskUsage };
    }
});

(async () => {
    try {
        await server.start();
        console.log(`Server running on ${server.info.uri}`);
    } catch (err) {
        console.error(err);
        process.exit(1);
    }
})();