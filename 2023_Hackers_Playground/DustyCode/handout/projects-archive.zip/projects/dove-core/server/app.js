const http = require('http');
const url = require('url');
const fs = require('fs');
const exec = require('child_process').exec;
const path = require('path');

const dataDir = './data/';
const accessKey = 'randomstring'; // replace with your own access key

const server = http.createServer((req, res) => {
  const reqUrl = url.parse(req.url, true);
  const reqPath = reqUrl.pathname.toLowerCase();

  if (reqPath === '/login') {
    if (req.method !== 'POST') {
      return sendResponse(res, 400, 'Only POST method is supported for this endpoint');
    }
    if (req.headers['access-key'] !== accessKey) {
      return sendResponse(res, 401, 'Invalid access key');
    }
    // authentication success, return user info with token
    const userInfo = { username: 'JohnDoe', email: 'johndoe@example.com' };
    const token = generateToken(userInfo);
    return sendResponse(res, 200, { userInfo, token });
  }

  if (reqPath === '/logout') {
    if (req.method !== 'POST') {
      return sendResponse(res, 400, 'Only POST method is supported for this endpoint');
    }
    // clear session token from client cookie, if any
    return sendResponse(res, 200, 'Logout success');
  }

  if (!req.headers['authorization']) {
    return sendResponse(res, 401, 'Missing authorization header');
  }
  const token = req.headers['authorization'].replace('Bearer ', '');
  const userInfo = verifyToken(token);
  if (!userInfo) {
    return sendResponse(res, 401, 'Invalid token');
  }

  if (reqPath.startsWith('/character/')) {
    const characterName = reqPath.substring('/character/'.length);
    if (!characterName) {
      return sendResponse(res, 400, 'Missing character name in request URL');
    }

    if (reqPath === '/character/elsa') {
      if (req.method === 'GET') {
        return sendResponse(res, 200, { message: 'Let it go!' });
      }
    }

    if (reqPath === '/character/simba') {
      if (req.method === 'GET') {
        return sendResponse(res, 200, { message: 'Hakuna matata!' });
      }
      if (req.method === 'POST') {
        // create new blog post
        const { title, content } = req.body;
        const postId = createBlogPost(characterName, userInfo.username, title, content);
        return sendResponse(res, 200, { message: 'Blog post created', postId });
      }
      if (req.method === 'PUT') {
        const postId = req.query.id;
        const postFilename = path.join(dataDir, `blog/${characterName}/${postId}.json`);
        fs.exists(postFilename, (exists) => {
          if (!exists) {
            return sendResponse(res, 404, 'Cannot find blog post');
          }
          const fileData = fs.readFileSync(postFilename);
          const postData = JSON.parse(fileData);
          if (postData.author !== userInfo.username) {
            return sendResponse(res, 403, 'You are not authorized to edit this post');
          }
          const { title, content } = req.body;
          if (title) postData.title = title;
          if (content) postData.content = content;
          fs.writeFileSync(postFilename, JSON.stringify(postData));
          return sendResponse(res, 200, 'Blog post updated');
        });
      }
      if (req.method === 'DELETE') {
        const postId = req.query.id;
        const postFilename = path.join(dataDir, `blog/${characterName}/${postId}.json`);
        fs.exists(postFilename, (exists) => {
          if (!exists) {
            return sendResponse(res, 404, 'Cannot find blog post');
          }
          const fileData = fs.readFileSync(postFilename);
          const postData = JSON.parse(fileData);
          if (postData.author !== userInfo.username) {
            return sendResponse(res, 403, 'You are not authorized to delete this post');
          }
          fs.unlinkSync(postFilename);
          return sendResponse(res, 200, 'Blog post deleted');
        });
      }
    }

    if (reqPath === '/character/tarzan') {
      if (req.method === 'GET') {
        // get list of neighboring blogs
        const neighbors = getBlogNeighbors(characterName);
        return sendResponse(res, 200, neighbors);
      }
      if (req.method === 'POST') {
        // add new blog neighbor
        const { neighborName, neighborUrl } = req.body;
        const success = addBlogNeighbor(characterName, neighborName, neighborUrl);
        if (!success) {
          return sendResponse(res, 400, 'Invalid neighbor information');
        }
        return sendResponse(res, 200, 'Blog neighbor added');
      }
      if (req.method === 'DELETE') {
        // remove a blog neighbor
        const neighborName = req.query.name;
        const success = removeBlogNeighbor(characterName, neighborName);
        if (!success) {
          return sendResponse(res, 400, 'Invalid neighbor name');
        }
        return sendResponse(res, 200, 'Blog neighbor removed');
      }
    }
  }

  if (reqPath === '/disk-usage') {
    exec('df --output=pcent /', (err, stdout, stderr) => {
      if (err) {
        return sendResponse(res, 500, 'Error occured while checking disk usage');
      }
      const usage = stdout.split('\n')[1].trim();
      return sendResponse(res, 200, { usage });
    });
  }

  return sendResponse(res, 404, 'Endpoint not found');
});

server.listen(3000, () => console.log('Server started'));

function sendResponse(res, statusCode, data) {
  const contentType = typeof data === 'string' ? 'text/plain' : 'application/json';
  res.writeHead(statusCode, { 'Content-Type': contentType });
  res.write(typeof data === 'string' ? data : JSON.stringify(data));
  res.end();
}

function generateToken(userInfo) {
  // generate a JWT token with user info, expiration time and secret key
  return `<JWT token with ${userInfo} and secret key>`;
}

function verifyToken(token) {
  // verify JWT signature and expiration time, return user info
  // or null if token is invalid
  return { username: 'JohnDoe', email: 'johndoe@example.com' };
}

function createBlogPost(characterName, author, title, content) {
  const blogDir = path.join(dataDir, `blog/${characterName}`);
  if (!fs.existsSync(blogDir)) {
    fs.mkdirSync(blogDir, { recursive: true });
  }
  const id = new Date().getTime();
  const postData = { id, author, time: new Date(), title, content };
  fs.writeFileSync(`${blogDir}/${id}.json`, JSON.stringify(postData));
  return id;
}

function getBlogNeighbors(characterName) {
  const neighborFile = path.join(dataDir, `blog/${characterName}/neighbors.json`);
  if (!fs.existsSync(neighborFile)) {
    fs.writeFileSync(neighborFile, JSON.stringify([]));
  }
  const fileData = fs.readFileSync(neighborFile);
  return JSON.parse(fileData);
}

function addBlogNeighbor(characterName, neighborName, neighborUrl) {
  if (!neighborName || !neighborUrl) {
    return false;
  }
  const neighbors = getBlogNeighbors(characterName);
  for (const neighbor of neighbors) {
    if (neighbor.name === neighborName) {
      return false; // duplicate name
    }
    if (neighbor.url === neighborUrl) {
      return false; // duplicate URL
    }
  }
  neighbors.push({ name: neighborName, url: neighborUrl });
  const neighborFile = path.join(dataDir, `blog/${characterName}/neighbors.json`);
  fs.writeFileSync(neighborFile, JSON.stringify(neighbors));
  return true;
}

function removeBlogNeighbor(characterName, neighborName) {
  const neighbors = getBlogNeighbors(characterName);
  const newNeighbors = neighbors.filter(n => n.name !== neighborName);
  if (neighbors.length === newNeighbors.length) {
    return false; // no matching neighbor to delete
  }
  const neighborFile = path.join(dataDir, `blog/${characterName}/neighbors.json`);
  fs.writeFileSync(neighborFile, JSON.stringify(newNeighbors));
  return true;
}