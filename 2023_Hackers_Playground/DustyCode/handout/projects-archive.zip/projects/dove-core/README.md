# dove-core
