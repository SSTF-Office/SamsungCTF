const Hapi = require('@hapi/hapi');

// Create a server with a host and port
const server = Hapi.server({
    host: 'localhost',
    port: 3000
});

// In memory database
let posts = [];
let neighbors = [];

// Seed data
posts.push({ id: 1, title: 'First Post', body: 'Lorem ipsum', author: 'John Doe' });
neighbors.push({ id: 1, name: 'Jane Smith', url: 'http://localhost:8080' });

// Safe exec function to check disk usage
const safeExec = (cmd) => {
    // Logic to check disk usage
};

// Route for creating a new blog post
server.route({
    method: 'POST',
    path: '/elephant/create',
    handler: (request, h) => {
        const { title, body, author } = request.payload;

        // Generate unique ID for post
        const id = posts.length + 1;

        // Add post to database
        posts.push({ id, title, body, author });

        return { message: `Post '${title}' created successfully` };
    },
    options: {
        auth: 'api',
        validate: {
            payload: {
                title: Joi.string().required(),
                body: Joi.string().required(),
                author: Joi.string().required()
            }
        }
    }
});

// Route for editing an existing blog post
server.route({
    method: 'PUT',
    path: '/lion/edit/{id}',
    handler: (request, h) => {
        const id = parseInt(request.params.id);
        const { title, body, author } = request.payload;

        // Find post to edit
        const post = posts.find(p => p.id === id);

        // Update post in database
        post.title = title;
        post.body = body;
        post.author = author;

        return { message: `Post '${title}' updated successfully` };
    },
    options: {
        auth: 'api',
        validate: {
            payload: {
                title: Joi.string().required(),
                body: Joi.string().required(),
                author: Joi.string().required()
            }
        }
    }
});

// Route for deleting an existing blog post
server.route({
    method: 'DELETE',
    path: '/giraffe/delete/{id}',
    handler: (request, h) => {
        const id = parseInt(request.params.id);

        // Filter out post to delete
        posts = posts.filter(p => p.id !== id);

        return { message: `Post with ID '${id}' deleted successfully` };
    },
    options: {
        auth: 'api',
        validate: {
            params: {
                id: Joi.number().integer().required()
            }
        }
    }
});

// Route for adding a new blog neighbor
server.route({
    method: 'POST',
    path: '/penguin/neighbor/add',
    handler: (request, h) => {
        const { name, url } = request.payload;

        // Generate unique ID for neighbor
        const id = neighbors.length + 1;

        // Add neighbor to database
        neighbors.push({ id, name, url });

        return { message: `Neighbor '${name}' added successfully` };
    },
    options: {
        auth: 'api',
        validate: {
            payload: {
                name: Joi.string().required(),
                url: Joi.string().required()
            }
        }
    }
});

// Route for managing a blog neighbor
server.route({
    method: 'PUT',
    path: '/rhino/neighbor/manage/{id}',
    handler: (request, h) => {
        const id = parseInt(request.params.id);
        const { name, url } = request.payload;

        // Find neighbor to manage
        const neighbor = neighbors.find(n => n.id === id);

        // Update neighbor in database
        neighbor.name = name;
        neighbor.url = url;

        return { message: `Neighbor '${name}' updated successfully` };
    },
    options: {
        auth: 'api',
        validate: {
            payload: {
                name: Joi.string().required(),
                url: Joi.string().required()
            }
        }
    }
});

// Route for getting blog information
server.route({
    method: 'GET',
    path: '/tiger/info',
    handler: (request, h) => {
        return { posts, neighbors };
    },
    options: {
        auth: 'api'
    }
});

// Auth strategy using access key
const validateAccessKey = async (accessKey) => {
    return { isValid: (accessKey === 'random_access_key') };
};
server.auth.strategy('api', 'apikey', { validate: validateAccessKey });

// Start the server
const start = async () => {
    await server.start();
    console.log(`Server running on ${server.info.uri}`);
};

start();