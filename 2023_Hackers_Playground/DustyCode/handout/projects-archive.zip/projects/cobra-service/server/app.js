const express = require('express');
const bodyParser = require('body-parser');
const crypto = require('crypto');
const fs = require('fs');
const https = require('https');
const AWS = require('aws-sdk');
const { JSDOM } = require('jsdom');
const { promisify } = require('util');

const app = express();
const port = 3000;

// Initialize AWS SDK
AWS.config.update({ region: 'us-east-1' });
const s3 = new AWS.S3();

// Initialize filesystem directory for writing data to local file
const dataDirectory = './data';
if (!fs.existsSync(dataDirectory)) {
    fs.mkdirSync(dataDirectory);
}

// Set up body-parser middleware for handling POST requests
app.use(bodyParser.urlencoded({ extended: true }));
app.use(bodyParser.json());

// Endpoint for registering a new user
app.post('/register', (req, res) => {
    // Generate random access key for user
    const accessKey = crypto.randomBytes(16).toString('hex');
    // Save access key to database (in this case, just a local variable)
    const user = { username: req.body.username, accessKey: accessKey };
    console.log(`User ${user.username} registered with access key: ${accessKey}`);
    // Return access key to user
    res.json({ accessKey: accessKey });
});

// Middleware function to check for valid access key
function authenticate(req, res, next) {
    // In this example, access keys are stored in memory as an array of objects
    const users = [
        { username: 'Alice', accessKey: 'abc123' },
        { username: 'Bob', accessKey: 'xyz789' },
    ];
    const accessKey = req.query.accessKey || req.body.accessKey;
    const user = users.find((u) => u.accessKey === accessKey);
    if (user) {
        // Add user object to request object for later use
        req.user = user;
        next();
    } else {
        res.status(401).json({ error: 'Invalid access key' });
    }
}

// Endpoint for logging in
app.post('/login', authenticate, (req, res) => {
    console.log(`User ${req.user.username} logged in with access key: ${req.user.accessKey}`);
    res.json({ message: 'Login successful' });
});

// Endpoint for logging out
app.post('/logout', authenticate, (req, res) => {
    console.log(`User ${req.user.username} logged out`);
    res.json({ message: 'Logout successful' });
});

// Endpoint for retrieving user info
app.get('/memberinfo', authenticate, (req, res) => {
    console.log(`User ${req.user.username} requested member info`);
    res.json({ username: req.user.username });
});

// Endpoint for crawling a web page and storing the response to persistent storage
app.post('/giraffe', authenticate, async (req, res) => {
    try {
        const url = req.body.url;
        const response = await promisify(https.get)(url);
        const html = await promisify(response.pipe.bind(response, new (require('stream').Writable)({
            write(chunk, encoding, callback) {
                this.data += chunk;
                callback();
            }
        })))();
        const dom = new JSDOM(html);
        // Save data to persistent storage (AWS S3 in this example)
        const s3params = {
            Bucket: 'my-bucket',
            Key: 'giraffe.html',
            Body: html,
            ContentType: 'text/html',
        };
        await s3.putObject(s3params).promise();
        console.log(`User ${req.user.username} crawled ${url} and stored to AWS S3`);
        res.json({ message: 'Crawling success' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Internal server error' });
    }
});

// Endpoint for writing data to a local file
app.post('/rhinoceros', authenticate, (req, res) => {
    const filename = `${dataDirectory}/${req.body.filename}`;
    const data = req.body.data;
    fs.writeFile(filename, data, (err) => {
        if (err) {
            console.error(err);
            res.status(500).json({ error: 'Internal server error' });
        } else {
            console.log(`User ${req.user.username} wrote data to ${filename}`);
            res.json({ message: 'Write success' });
        }
    });
});

// Start the server
app.listen(port, () => {
    console.log(`Server listening at http://localhost:${port}`);
});