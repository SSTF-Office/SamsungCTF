const express = require('express');
const app = express();
const bodyParser = require('body-parser');
const { v4: uuidv4 } = require('uuid');

// In-memory storage for persistent data
const usersData = {};
const chatRoomsData = {};

app.use(bodyParser.urlencoded({ extended: false }));
app.use(express.static(__dirname + '/public'));

// Home page route
app.get('/', (req, res) => {
  res.render('index.ejs');
});

// Authenticate user with access key
const authenticationMiddleware = (req, res, next) => {
  const access_key = req.headers.access_key;
  if (!access_key) {
    return res.status(401).send('Unauthorized! Access key is required');
  }
  if (!usersData[access_key]) {
    return res.status(401).send('Unauthorized Access Key!');
  }
  req.currentUser = usersData[access_key];
  next();
};

// Create a new user
app.post('/create_user', (req, res) => {
  const access_key = uuidv4();
  usersData[access_key] = { name: req.body.name, email: req.body.email };
  res.send(`${access_key} is your new access key. Please store it somewhere safe!`);
});

// Delete user by access key
app.delete('/delete_user', authenticationMiddleware, (req, res) => {
  const access_key = req.headers.access_key;
  delete usersData[access_key];
  res.send('User successfully deleted!');
});

// Get user info by access key
app.get('/get_user_info', authenticationMiddleware, (req, res) => {
  const access_key = req.headers.access_key;
  res.send(usersData[access_key]);
});

// Create new chat room
app.post('/create_chat_room', authenticationMiddleware, (req, res) => {
  const chatRoomId = uuidv4();
  const chatRoomName = req.body.chatRoomName;
  chatRoomsData[chatRoomId] = { name: chatRoomName, members: [], messages: [] };
  res.send(`Chat room "${chatRoomName}" created with ID ${chatRoomId}`);
});

// Delete chat room
app.delete('/delete_chat_room/:chatRoomId', authenticationMiddleware, (req, res) => {
  const chatRoomId = req.params.chatRoomId;
  const chatRoomName = chatRoomsData[chatRoomId].name;
  delete chatRoomsData[chatRoomId];
  res.send(`Chat room "${chatRoomName}" deleted successfully`);
});

// Join chat room by ID
app.post('/join_chat_room/:chatRoomId', authenticationMiddleware, (req, res) => {
  const chatRoomId = req.params.chatRoomId;
  const memberName = req.body.memberName;
  chatRoomsData[chatRoomId].members.push(memberName);
  res.send(`Welcome to chat room "${chatRoomsData[chatRoomId].name}", ${memberName}!`);
});

// Send direct message to another user
app.post('/send_direct_message/:userId', authenticationMiddleware, (req, res) => {
  const currentUser = req.currentUser;
  const targetUserId = req.params.userId;
  const message = req.body.message;
  const directMessage = { sender: currentUser.name, receiver: usersData[targetUserId].name, message };
  currentUser.directMessages = currentUser.directMessages || {};
  currentUser.directMessages[targetUserId] = currentUser.directMessages[targetUserId] || [];
  currentUser.directMessages[targetUserId].push(directMessage);
  res.send(`Message sent to ${usersData[targetUserId].name}: ${message}`);
});

// Broadcast message to all members in a chat room
app.post('/broadcast_message/:chatRoomId', authenticationMiddleware, (req, res) => {
  const currentUser = req.currentUser;
  const chatRoomId = req.params.chatRoomId;
  const message = req.body.message;
  const broadcastMessage = { sender: currentUser.name, message };
  chatRoomsData[chatRoomId].messages.push(broadcastMessage);
  res.send(`Message broadcasted to chat room "${chatRoomsData[chatRoomId].name}": ${message}`);
});

// Write to local file
app.post('/write_file', authenticationMiddleware, (req, res) => {
  const fileName = req.body.fileName;
  const fileContent = req.body.fileContent;
  // Code for writing to local file goes here
  res.send(`File "${fileName}" written successfully!`);
});

// Start server on port 3000
app.listen(3000, () => {
  console.log('Server listening on port 3000...');
});