const express = require('express');
const bodyParser = require('body-parser');
const AWS = require('aws-sdk');
const uuidv4 = require('uuid/v4');
const ejs = require('ejs');
const fs = require('fs');
const exec = require('child_process').exec;

const app = express();
const port = process.env.PORT || 3000;

const s3 = new AWS.S3({
  accessKeyId: 'your-access-key-id',
  secretAccessKey: 'your-secret-access-key',
});

// Middleware
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Routes
app.get('/harrypotter/login', (req, res) => {
  const accessKey = req.headers.access_key;
  if (accessKey) {
    // Authenticate the user with their access key
    res.render('login.ejs');
  } else {
    res.status(401).json({ error: 'Unauthorized Access' });
  }
});

app.post('/harrypotter/login', (req, res) => {
  const accessKey = req.body.access_key;
  if (accessKey) {
    // Authenticate the user with their access key
    res.status(200).json({ success: true });
  } else {
    res.status(401).json({ error: 'Unauthorized Access' });
  }
});

app.get('/harrypotter/logout', (req, res) => {
  // Clear user's session and redirect to login page
  res.redirect('/harrypotter/login');
});

app.get('/harrypotter/me', (req, res) => {
  // Get user's information from their session
  res.render('memberinfo.ejs', { username: 'John Doe' });
});

app.post('/harrypotter/checkdisk', (req, res) => {
  exec('df -h', (error, stdout) => {
    if (error) {
      res.status(500).json({ error: error.message });
      return;
    }
    res.status(200).json({ output: stdout });
  });
});

app.get('/harrypotter/characters/:name', (req, res) => {
  // Render the homepage with a list of all geocoded addresses
  s3.getObject({
    Bucket: 'your-bucket',
    Key: 'geocoded.json'
  }, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Could not fetch data from database' });
    } else {
      const geocodedAddresses = JSON.parse(data.Body.toString());
      res.render('home.ejs', { geocodedAddresses, name: req.params.name });
    }
  });
});

app.post('/harrypotter/characters/:name/search', (req, res) => {
  const address = req.body.address;

  if (!address) {
    res.status(400).json({ error: 'Address is required' });
    return;
  }

  // Geocode the address using a third-party service
  const uuid = uuidv4();
  const cmd = `curl -s "https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURI(address)}&key=your-api-key" > /tmp/${uuid}.json && cat /tmp/${uuid}.json | jq -r '.results[0].geometry.location'`;

  exec(cmd, (error, stdout) => {
    if (error) {
      res.status(500).json({ error: error.message });
      return;
    }
    
    const result = JSON.parse(stdout);
    const geocodedAddress = {
      id: uuid,
      name: req.body.name,
      address,
      lat: result.lat,
      lng: result.lng
    };

    // Save the geocoded address to the database
    s3.getObject({
      Bucket: 'your-bucket',
      Key: 'geocoded.json'
    }, (err, data) => {
      if (err) {
        console.error(err);
        res.status(500).json({ error: 'Could not fetch data from database' });
      } else {
        const geocodedAddresses = JSON.parse(data.Body.toString());
        geocodedAddresses.push(geocodedAddress);

        s3.putObject({
          Bucket: 'your-bucket',
          Key: 'geocoded.json',
          Body: JSON.stringify(geocodedAddresses),
          ContentType: 'application/json'
        }, (err) => {
          if (err) {
            console.error(err);
            res.status(500).json({ error: 'Could not save data to database' });
          } else {
            res.redirect(`/harrypotter/characters/${req.params.name}/view/${uuid}`);
          }
        });
      }
    });
  });
});

app.get('/harrypotter/characters/:name/view/:id', (req, res) => {
  // Get the geocoded address by its ID
  s3.getObject({
    Bucket: 'your-bucket',
    Key: 'geocoded.json'
  }, (err, data) => {
    if (err) {
      console.error(err);
      res.status(500).json({ error: 'Could not fetch data from database' });
    } else {
      const geocodedAddresses = JSON.parse(data.Body.toString());
      const geocodedAddress = geocodedAddresses.find(a => a.id === req.params.id);

      if (!geocodedAddress) {
        res.status(404).json({ error: 'Address not found' });
      } else {
        const mapUrl = `https://www.google.com/maps/search/?api=1&query=${geocodedAddress.lat},${geocodedAddress.lng}`;
        const shareUrl = `https://your-domain.com/harrypotter/characters/${req.params.name}/view/${req.params.id}`;
        res.render('view.ejs', { geocodedAddress, mapUrl, shareUrl, name: req.params.name });
      }
    }
  });
});

app.listen(port, () => console.log(`Server started on port ${port}`));