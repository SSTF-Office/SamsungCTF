const Hapi = require('hapi');
const Boom = require('boom');
const Joi = require('joi');
const crypto = require('crypto');
const WebSocket = require('ws');
const { Pool } = require('pg');
const cluster = require('cluster');
const numCPUs = require('os').cpus().length;
const { evaluate } = require('mathjs');

const pool = new Pool({
  user: 'cockroach',
  host: 'cockroachdb',
  database: 'chat_db',
  port: 26257,
  ssl: {
    ca: './certs/ca.crt',
    key: './certs/client.root.key',
    cert: './certs/client.root.crt',
  }
});

if (cluster.isMaster) {
  for (let i = 0; i < numCPUs; i++) {
    cluster.fork();
  }
} else {
  const wss = new WebSocket.Server({ port: 8000 });

  const server = Hapi.Server({
    host: 'localhost',
    port: 3000
  });

  server.route({
    method: 'POST',
    path: '/login',
    handler: async (request, h) => {
      const { username, password } = request.payload;

      try {
        const result = await pool.query(`SELECT * FROM users WHERE username = '${username}'`);
        const user = result.rows[0];

        if (user && user.password === password) {
          const access_key = crypto.randomBytes(16).toString('hex');
          await pool.query(`UPDATE users SET access_key = '${access_key}' WHERE id = '${user.id}'`);
          return { access_key };
        } else {
          throw Boom.unauthorized('Invalid username or password');
        }
      } catch (error) {
        console.error(error);
        throw Boom.internal('Internal Server Error');
      }
    },
    options: {
      validate: {
        payload: Joi.object({
          username: Joi.string().alphanum().min(3).max(30).required(),
          password: Joi.string().min(6).max(30).required()
        }).options({ stripUnknown: true })
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/logout',
    handler: async (request, h) => {
      const access_key = request.headers.authorization;
      await pool.query(`UPDATE users SET access_key = NULL WHERE access_key = '${access_key}'`);
      return { message: 'Logout successful' };
    },
    options: {
      auth: {
        strategy: 'access_key'
      }
    }
  });

  const validateAccessKey = async (access_key, h) => {
    try {
      const result = await pool.query(`SELECT * FROM users WHERE access_key = '${access_key}'`);
      const user = result.rows[0];

      if (user) {
        return { isValid: true, credentials: user }
      } else {
        throw Boom.unauthorized('Invalid access key');
      }
    } catch (error) {
      console.error(error);
      throw Boom.internal('Internal Server Error');
    }
  };

  server.auth.scheme('access_key', () => ({
    authenticate: async (request, h) => {
      const access_key = request.headers.authorization;

      if (!access_key) {
        throw Boom.unauthorized('Missing access key');
      }

      return validateAccessKey(access_key, h);
    }
  }));

  server.auth.strategy('access_key', 'access_key');

  server.route({
    method: 'GET',
    path: '/memberinfo',
    handler: async (request, h) => {
      const { username, access_key } = request.auth.credentials;
      return { username };
    },
    options: {
      auth: {
        strategy: 'access_key'
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/create_chatroom',
    handler: async (request, h) => {
      const { chatroom_name } = request.payload;

      try {
        const result = await pool.query(`INSERT INTO chatrooms (name) VALUES ('${chatroom_name}') RETURNING *`);
        return { chatroom: result.rows[0] };
      } catch (error) {
        console.error(error);
        throw Boom.internal('Internal Server Error');
      }
    },
    options: {
      auth: {
        strategy: 'access_key'
      },
      validate: {
        payload: Joi.object({
          chatroom_name: Joi.string().min(3).max(30).required()
        })
      }
    }
  });

  server.route({
    method: 'DELETE',
    path: '/delete_chatroom/{id}',
    handler: async (request, h) => {
      const { id } = request.params;

      try {
        await pool.query(`DELETE FROM chatrooms WHERE id = ${id}`);
        return { message: 'Chatroom deleted' };
      } catch (error) {
        console.error(error);
        throw Boom.internal('Internal Server Error');
      }
    },
    options: {
      auth: {
        strategy: 'access_key'
      }
    }
  });

  server.route({
    method: 'POST',
    path: '/join_chatroom/{id}',
    handler: async (request, h) => {
      const { id } = request.params;
      const { access_key } = request.auth.credentials;

      try {
        await pool.query(`INSERT INTO members (chatroom_id, user_id) SELECT '${id}', id FROM users WHERE access_key = '${access_key}'`);
        return { message: 'Joined chatroom' };
      } catch (error) {
        console.error(error);
        throw Boom.internal('Internal Server Error');
      }
    },
    options: {
      auth: {
        strategy: 'access_key'
      }
    }
  });

  server.route({
    method: 'GET',
    path: '/arithmetic',
    handler: (request, h) => {
      const { expression } = request.query;
      const answer = evaluate(expression);
      return { answer };
    }
  });

  wss.on('connection', (ws) => {
    ws.on('message', async (message) => {
      const { chatroom_id, content } = JSON.parse(message);
      const { access_key } = ws;

      try {
        const result = await pool.query(`SELECT * FROM users WHERE access_key = '${access_key}'`);
        const user_id = result.rows[0].id;
        await pool.query(`INSERT INTO messages (chatroom_id, user_id, content) VALUES ('${chatroom_id}', '${user_id}', '${content}')`);
      } catch (error) {
        console.error(error);
      }

      wss.clients.forEach((client) => {
        if (client.readyState === WebSocket.OPEN && client.access_key === access_key) {
          client.send(message);
        }
      });
    });

    ws.on('close', async () => {
      const { access_key } = ws;

      try {
        await pool.query(`UPDATE users SET access_key = NULL WHERE access_key = '${access_key}'`);
      } catch (error) {
        console.error(error);
      }
    });

    ws.on('error', (error) => {
      console.error(error);
    });

    ws.on('headers', (headers) => {
      const access_key = headers['sec-websocket-protocol'];

      if (access_key) {
        ws.access_key = access_key;
      } else {
        ws.close();
      }
    });
  });

  server.start();
}