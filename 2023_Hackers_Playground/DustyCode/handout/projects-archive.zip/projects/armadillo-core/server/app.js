const http = require('http');
const fs = require('fs');
const { v4: uuidv4 } = require('uuid');

const server = http.createServer((req, res) => {
  // Parse the request URL and method
  const url = new URL(req.url, `http://${req.headers.host}`);
  const method = req.method;

  // Route the request to the appropriate handler
  if (url.pathname === '/login') {
    handleLogin(req, res);
  } else if (url.pathname === '/logout') {
    handleLogout(req, res);
  } else if (url.pathname === '/memberinfo') {
    handleMemberInfo(req, res);
  } else if (url.pathname === '/addfriend') {
    handleAddFriend(req, res);
  } else if (url.pathname === '/removefriend') {
    handleRemoveFriend(req, res);
  } else if (url.pathname === '/findfriend') {
    handleFindFriend(req, res);
  } else if (url.pathname === '/addpost') {
    handleAddPost(req, res);
  } else if (url.pathname === '/addcomment') {
    handleAddComment(req, res);
  } else if (url.pathname === '/writefile') {
    handleWriteFile(req, res);
  } else {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('404 Not Found');
  }
});

// Define the access key for authentication
const accessKey = 'abcdefghijklmnopqrstuvwxyz';

// Define the data storage object
const storage = {
  users: {},
  posts: {},
};

// Define the login handler
function handleLogin(req, res) {
  // Check the access key
  const accessKeyHeader = req.headers['x-access-key'];
  if (accessKeyHeader !== accessKey) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Check if the user exists and create if not
    const username = bodyParams.username;
    if (!storage.users[username]) {
      storage.users[username] = {
        password: bodyParams.password,
        friends: {},
        posts: [],
      };
    }

    // Create a session ID and send it as a cookie
    const sessionId = uuidv4();
    res.setHeader('Set-Cookie', `session_id=${sessionId}; Path=/`);
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end(`Logged in as ${username}`);
  });
}

// Define the logout handler
function handleLogout(req, res) {
  // Clear the user's session ID cookie
  res.setHeader('Set-Cookie', 'session_id=; Path=/');

  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end('Logged out');
}

// Define the member info handler
function handleMemberInfo(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  res.writeHead(200, { 'Content-Type': 'text/plain' });
  res.end(`Hello ${username}`);
}

// Define the add friend handler
function handleAddFriend(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Check if the friend exists and add if so
    const friendUsername = bodyParams.username;
    if (storage.users[friendUsername]) {
      storage.users[username].friends[friendUsername] = true;
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(`Added ${friendUsername} as a friend`);
    } else {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end(`User ${friendUsername} does not exist`);
    }
  });
}

// Define the remove friend handler
function handleRemoveFriend(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Check if the friend exists and remove if so
    const friendUsername = bodyParams.username;
    if (storage.users[username].friends[friendUsername]) {
      delete storage.users[username].friends[friendUsername];
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end(`Removed ${friendUsername} as a friend`);
    } else {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end(`User ${friendUsername} is not a friend`);
    }
  });
}

// Define the find friend handler
function handleFindFriend(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Find usernames matching search query
    const searchQuery = bodyParams.query.toLowerCase();
    const matchingUsernames = Object.keys(storage.users)
      .filter(user => user.toLowerCase().includes(searchQuery))
      .filter(user => !(user in storage.users[username].friends))
      .filter(user => user !== username);

    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ usernames: matchingUsernames }));
  });
}

// Define the add post handler
function handleAddPost(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Create a new post
    const post = {
      id: uuidv4(),
      author: username,
      text: bodyParams.text,
      comments: [],
    };
    storage.posts[post.id] = post;
    storage.users[username].posts.push(post.id);

    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('Post added');
  });
}

// Define the add comment handler
function handleAddComment(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Check if the post exists and add the comment if so
    const postId = bodyParams.postId;
    const text = bodyParams.text;
    if (storage.posts[postId]) {
      const comment = {
        id: uuidv4(),
        author: username,
        text: text,
      };
      storage.posts[postId].comments.push(comment);
      res.writeHead(200, { 'Content-Type': 'text/plain' });
      res.end('Comment added');
    } else {
      res.writeHead(400, { 'Content-Type': 'text/plain' });
      res.end(`Post with ID ${postId} does not exist`);
    }
  });
}

// Define the write file handler
function handleWriteFile(req, res) {
  // Check the session ID cookie
  const sessionId = req.headers.cookie?.split('=')[1];
  const username = getUsernameFromSessionId(sessionId);
  if (!username) {
    res.writeHead(401, { 'Content-Type': 'text/plain' });
    res.end('401 Unauthorized');
    return;
  }

  // Parse the request body
  let requestBody = '';
  req.on('data', chunk => {
    requestBody += chunk.toString();
  });
  req.on('end', () => {
    const bodyParams = parseQueryParams(requestBody);

    // Write the file to disk
    const filename = bodyParams.filename;
    const data = bodyParams.data;
    fs.writeFile(filename, data, err => {
      if (err) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
      } else {
        res.writeHead(200, { 'Content-Type': 'text/plain' });
        res.end('File written');
      }
    });
  });
}

// Helper function to parse URL query parameters
function parseQueryParams(queryString) {
  const queryParams = {};
  const queryPairs = queryString.split('&');
  for (const queryPair of queryPairs) {
    const [key, value] = queryPair.split('=');
    queryParams[decodeURIComponent(key)] = decodeURIComponent(value);
  }
  return queryParams;
}

// Helper function to get the username from a session ID
function getUsernameFromSessionId(sessionId) {
  for (const [username, userDetails] of Object.entries(storage.users)) {
    if (sessionId in userDetails) {
      return username;
    }
  }
  return null;
}

// Start the server
const port = process.env.PORT || 3000;
server.listen(port, () => {
  console.log(`Server running on port ${port}`);
});