const express = require('express');
const app = express();

// Set the port number to use (can also be set via environment variable)
const port = process.env.PORT || 3000;

// Define the API secret key (change this to something secure for your own use)
const apiSecret = 'MySecureAPISecret';

// Set up middleware to handle JSON data in requests
app.use(express.json());

// Define a simple endpoint to test the server is working
app.get('/', (req, res) => {
  res.send('API server is running');
});

// Define an endpoint that requires a valid API secret key
app.post('/api/data', (req, res) => {
  const apiKey = req.headers.authorization;

  // Check that the API key is valid
  if (apiKey === apiSecret) {
    // Reflect the JSON data sent in the request back to the client
    res.json(req.body);
  } else {
    // Return an error if the API key is invalid
    res.status(401).json({ error: 'Unauthorized' });
  }
});

// Start the server
app.listen(port, () => {
  console.log(`API server is listening on port ${port}`);
});