const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const uuidv4 = require('uuid/v4');

const app = express();
const port = 3000;

const users = {}; // in-memory user data store
const posts = {}; // in-memory post data store

// Middleware to parse JSON request bodies
app.use(bodyParser.json());

// Middleware to parse URL-encoded request bodies
app.use(bodyParser.urlencoded({ extended: true }));

// Middleware to serve static files from the "public" directory
app.use(express.static('public'));

// Middleware to authenticate API requests with access key
function authenticate(req, res, next) {
  const accessKey = req.query.access_key;
  if (!accessKey || !users[accessKey]) {
    return res.status(401).send('Unauthorized');
  }
  req.user = users[accessKey];
  next();
}

// API endpoint to register a new user
app.post('/register', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  if (!username || !password) {
    return res.status(400).send('Bad Request');
  }
  const accessKey = uuidv4();
  users[accessKey] = { username, password };
  const data = { accessKey };
  res.render('register.ejs', data);
});

// API endpoint to log in an existing user
app.post('/login', (req, res) => {
  const username = req.body.username;
  const password = req.body.password;
  if (!username || !password) {
    return res.status(400).send('Bad Request');
  }
  const accessKey = Object.keys(users).find(
    key => users[key].username === username && users[key].password === password
  );
  if (!accessKey) {
    return res.status(401).send('Unauthorized');
  }
  const data = { accessKey };
  res.render('login.ejs', data);
});

// API endpoint to log out a user
app.post('/logout', authenticate, (req, res) => {
  const accessKey = req.query.access_key;
  delete users[accessKey];
  res.status(204).send();
});

// API endpoint to retrieve the profile information of a user
app.get('/profile', authenticate, (req, res) => {
  const data = { username: req.user.username };
  res.render('profile.ejs', data);
});

// API endpoint to add a friend for a user
app.post('/addfriend', authenticate, (req, res) => {
  const friendName = req.body.friendname;
  if (!friendName) {
    return res.status(400).send('Bad Request');
  }
  req.user.friends = req.user.friends || [];
  req.user.friends.push(friendName);
  res.status(204).send();
});

// API endpoint to remove a friend for a user
app.post('/removefriend', authenticate, (req, res) => {
  const friendName = req.body.friendname;
  if (!friendName) {
    return res.status(400).send('Bad Request');
  }
  req.user.friends = req.user.friends || [];
  req.user.friends = req.user.friends.filter(name => name !== friendName);
  res.status(204).send();
});

// API endpoint to find a friend for a user
app.get('/findfriend', authenticate, (req, res) => {
  const friendName = req.query.friendname;
  if (!friendName) {
    return res.status(400).send('Bad Request');
  }
  const matchingUsers = Object.values(users).filter(user =>
    user.username !== req.user.username && user.friends && user.friends.includes(friendName)
  );
  const data = { matchingUsers };
  res.render('findfriend.ejs', data);
});

// API endpoint to add a post for a user
app.post('/addpost', authenticate, (req, res) => {
  const postText = req.body.posttext;
  if (!postText) {
    return res.status(400).send('Bad Request');
  }
  const postId = uuidv4();
  posts[postId] = {
    userid: req.user.username,
    text: postText,
    comments: []
  };
  res.status(204).send();
});

// API endpoint to add a comment to a post for a user
app.post('/addcomment', authenticate, (req, res) => {
  const postId = req.body.postid;
  const commentText = req.body.commenttext;
  if (!postId || !commentText) {
    return res.status(400).send('Bad Request');
  }
  const post = posts[postId];
  if (!post) {
    return res.status(404).send('Not Found');
  }
  post.comments.push({
    userid: req.user.username,
    text: commentText
  });
  res.status(204).send();
});

// Start the server
app.listen(port, () => {
  console.log(`Server running at http://localhost:${port}`);
});