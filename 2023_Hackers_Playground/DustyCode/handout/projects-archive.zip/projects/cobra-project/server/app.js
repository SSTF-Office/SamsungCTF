const http = require('http');
const url = require('url');
const crypto = require('crypto');

//Persistent data storage
let cache = {}; //In-memory cache storage

//Authentication function using access key
const authenticate = (req) => {
  const access_key = req.headers['access-key'];
  if (access_key === undefined || access_key === '') {
    return false;
  }
  //Any non-empty access key is considered valid
  return true;
};

//Web cache API endpoint (/dog)
const dogCache = (req, res) => {
  if (req.method === 'POST' && authenticate(req)) {
    //Get the URL from the request body
    let requestBody = '';
    req.on('data', chunk => {
      requestBody += chunk.toString();
    });
    req.on('end', () => {
      const { url: cacheUrl } = JSON.parse(requestBody);
      //Check if a cache already exists for the given URL
      const cacheDocId = Object.keys(cache).find(key => {
        const { url, contents } = cache[key];
        return url === cacheUrl;
      });
      if (cacheDocId !== undefined) {
        //Cache already exists
        res.writeHeader(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ cache_id: cacheDocId }));
      } else {
        //New cache
        http.get(cacheUrl, (response) => {
          let responseBody = '';
          response.on('data', chunk => {
            responseBody += chunk.toString();
          });
          response.on('end', async () => {
            //Store cache in memory and return cache id
            const cacheId = crypto.randomBytes(8).toString('hex');
            cache[cacheId] = { url: cacheUrl, contents: responseBody };
            res.writeHeader(200, { 'Content-Type': 'application/json' });
            res.end(JSON.stringify({ cache_id: cacheId }));
          });
        });
      }
    });
  } else if (req.method === 'GET' && authenticate(req)) {
    //Get cache contents using cache id
    const queryObject = url.parse(req.url, true).query;
    const cacheId = queryObject.id;
    if (cacheId === undefined || cacheId === '') {
      //Invalid cache id parameter
      res.writeHeader(400, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Invalid cache id parameter' }));
    } else if (cache[cacheId] === undefined) {
      //Cache id not found
      res.writeHeader(404, { 'Content-Type': 'application/json' });
      res.end(JSON.stringify({ error: 'Cache not found' }));
    } else {
      //Cache found, return contents
      const cacheContents = cache[cacheId].contents;
      res.writeHeader(200, { 'Content-Type': 'text/html' });
      res.end(cacheContents);
    }
  } else {
    //Invalid request
    res.writeHeader(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Authentication failed' }));
  }
};

//Safe exec API endpoint (/cat)
const catSafeExec = (req, res) => {
  if (req.method === 'POST' && authenticate(req)) {
    //Get the command from the request body
    let requestBody = '';
    req.on('data', chunk => {
      requestBody += chunk.toString();
    });
    req.on('end', () => {
      const command = JSON.parse(requestBody).command;
      //Execute the command safely
      const { exec } = require('child_process');
      exec(command, { timeout: 5000 }, (error, stdout, stderr) => {
        if (error) {
          res.writeHeader(500, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ error: error.message }));
        } else if (stderr) {
          res.writeHeader(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ output: stderr }));
        } else {
          res.writeHeader(200, { 'Content-Type': 'application/json' });
          res.end(JSON.stringify({ output: stdout }));
        }
      });
    });
  } else {
    //Invalid request
    res.writeHeader(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Authentication failed' }));
  }
};

//Login API endpoint (/koala)
const koalaLogin = (req, res) => {
  if (req.method === 'POST') {
    //Authenticate user credentials
    let requestBody = '';
    req.on('data', chunk => {
      requestBody += chunk.toString();
    });
    req.on('end', () => {
      const { username, password } = JSON.parse(requestBody);
      if (username === 'admin' && password === 'password') {
        //Valid credentials, return access key
        const accessKey = crypto.randomBytes(16).toString('hex');
        res.writeHeader(200, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ access_key: accessKey }));
      } else {
        //Invalid credentials
        res.writeHeader(401, { 'Content-Type': 'application/json' });
        res.end(JSON.stringify({ error: 'Invalid credentials' }));
      }
    });
  } else {
    //Invalid request
    res.writeHeader(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Authentication failed' }));
  }
};

//Logout API endpoint (/lion)
const lionLogout = (req, res) => {
  if (req.method === 'POST' && authenticate(req)) {
    //Invalidate access key
    res.writeHeader(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ message: 'Logout successful' }));
  } else {
    //Invalid request
    res.writeHeader(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Authentication failed' }));
  }
};

//Memberinfo API endpoint (/turtle)
const turtleMemberInfo = (req, res) => {
  if (req.method === 'GET' && authenticate(req)) {
    //Return member information
    res.writeHeader(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ name: 'John Doe', age: 30, email: 'johndoe@example.com' }));
  } else {
    //Invalid request
    res.writeHeader(401, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({ error: 'Authentication failed' }));
  }
};

//Start server on port 3000
http.createServer((req, res) => {
  const { pathname } = url.parse(req.url);
  switch (pathname) {
    case '/dog':
      dogCache(req, res);
      break;
    case '/cat':
      catSafeExec(req, res);
      break;
    case '/koala':
      koalaLogin(req, res);
      break;
    case '/lion':
      lionLogout(req, res);
      break;
    case '/turtle':
      turtleMemberInfo(req, res);
      break;
    default:
      //Invalid endpoint
      res.writeHeader(404, { 'Content-Type': 'text/plain' });
      res.end('Endpoint not found');
  }
}).listen(3000);

//Safe disk usage checker
const checkDiskUsage = () => {
  const { exec } = require('child_process');
  exec('df -h', { timeout: 5000 }, (error, stdout, stderr) => {
    if (error) {
      console.error(`exec error: ${error}`);
      return;
    }
    console.log(`stdout: ${stdout}`);
    console.error(`stderr: ${stderr}`);
  });
};