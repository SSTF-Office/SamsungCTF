const http = require('http');
const url = require('url');
const fs = require('fs');
const {
  Client
} = require('pg');
const crypto = require('crypto');

const client = new Client({
  database: 'webcache',
  user: 'webcacheuser',
  password: 'password',
  port: 26257,
  host: 'localhost'
});

client.connect()
  .then(() => console.log('Connected to CockroachDB'))
  .catch(error => console.error('Error connecting to CockroachDB', error));

let cache = {};

const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url, true);
  const path = parsedUrl.pathname;

  switch (path) {
    case '/login':
      login(req, res);
      break;
    case '/logout':
      logout(req, res);
      break;
    case '/memberinfo':
      memberInfo(req, res);
      break;
    case '/food':
      handleFoodRequest(req, res, parsedUrl);
      break;
    case '/file':
      handleFileRequest(req, res, parsedUrl);
      break;
    default:
      res.statusCode = 404;
      res.end('Not found');
      break;
  }
});

function login(req, res) {
  const accessKey = req.headers.access_key;
  const userId = getUserId(accessKey);

  if (!userId) {
    res.statusCode = 401;
    res.end('Invalid Access Key');
  } else {
    res.setHeader('Set-Cookie', `access_key=${accessKey}`);
    res.end('Login Success');
  }
}

function logout(req, res) {
  res.setHeader('Set-Cookie', `access_key=; expires=${new Date(0).toUTCString()}`);
  res.end('Logout Success');
}

function memberInfo(req, res) {
  const accessKey = req.headers.access_key;
  const userId = getUserId(accessKey);

  if (!userId) {
    res.statusCode = 401;
    res.end('Invalid Access Key');
  } else {
    const memberInfo = {
      name: 'John Doe',
      email: 'john.doe@example.com',
      phone: '555-555-5555'
    };
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify(memberInfo));
  }
}

async function handleFoodRequest(req, res, parsedUrl) {
  if (req.method !== 'GET') {
    res.statusCode = 405;
    res.end('Method not allowed');
  } else if (!req.headers.access_key) {
    res.statusCode = 401;
    res.end('Access key required');
  } else {
    const accessKey = req.headers.access_key;
    const userId = getUserId(accessKey);

    if (!userId) {
      res.statusCode = 401;
      res.end('Invalid Access Key');
      return;
    }

    const foodUrl = parsedUrl.query.url;

    if (!foodUrl) {
      res.statusCode = 400;
      res.end('URL parameter missing');
      return;
    }

    const cachedResponseId = getCachedResponseId(foodUrl);

    if (cachedResponseId) {
      const cachedResponse = getCachedResponse(cachedResponseId);
      if (cachedResponse) {
        res.statusCode = 200;
        res.setHeader('Content-Type', cachedResponse.contentType);
        res.end(cachedResponse.data);
        return;
      }
    }

    const options = {
      host: foodUrl,
      port: 80,
      path: '/',
      method: 'GET'
    };

    const httpReq = http.request(options, (httpRes) => {
      httpRes.setEncoding('utf8');

      let body = '';

      httpRes.on('data', (chunk) => {
        body += chunk;
      });

      httpRes.on('end', async () => {
        const cacheId = await cacheResponse(foodUrl, body, httpRes.headers['content-type']);
        res.statusCode = 200;
        res.setHeader('Content-Type', httpRes.headers['content-type']);
        res.end(body);
      });
    });

    httpReq.on('error', (error) => {
      console.error('Error fetching web page:', error);
      res.statusCode = 500;
      res.end(error.toString());
    });

    httpReq.end();
  }
}

const CACHE_DIR = './cache';

function handleFileRequest(req, res, parsedUrl) {
  if (req.method !== 'GET') {
    res.statusCode = 405;
    res.end('Method not allowed');
  } else if (!req.headers.access_key) {
    res.statusCode = 401;
    res.end('Access key required');
  } else {
    const accessKey = req.headers.access_key;
    const userId = getUserId(accessKey);

    if (!userId) {
      res.statusCode = 401;
      res.end('Invalid Access Key');
      return;
    }

    const fileId = parsedUrl.query.id;

    if (!fileId) {
      res.statusCode = 400;
      res.end('File ID parameter missing');
      return;
    }

    const filePath = `${CACHE_DIR}/${fileId}`;

    if (!fs.existsSync(filePath)) {
      res.statusCode = 404;
      res.end('File not found');
      return;
    }

    const fileStream = fs.createReadStream(filePath);

    fileStream.on('error', (error) => {
      console.error('Error reading file', error);
      res.statusCode = 500;
      res.end(error.toString());
    });

    fileStream.pipe(res);
  }
}

async function cacheResponse(url, data, contentType) {
  const cacheId = crypto.randomBytes(16).toString('hex');
  cache[cacheId] = {
    data: data,
    contentType: contentType
  };

  try {
    const query = `INSERT INTO cache VALUES ($1, $2, $3) RETURNING id`;
    const values = [cacheId, url, contentType];
    const result = await client.query(query, values);
    console.log('Cached response:', cacheId, url, contentType);
    return cacheId;
  } catch (error) {
    console.error('Error caching response:', error);
  }
}

function getCachedResponseId(url) {
  for (const cacheId in cache) {
    const cachedUrl = cache[cacheId].url;
    if (cachedUrl === url) {
      return cacheId;
    }
  }
  return null;
}

function getCachedResponse(cacheId) {
  return cache[cacheId] || null;
}

function getUserId(accessKey) {
  // Just a mock implementation
  return 123;
}

server.listen(8080, () => {
  console.log('Server running on port 8080');
});