const Hapi = require('@hapi/hapi');
const Joi = require('joi');
const fs = require('fs');

const API_KEY = 'your_random_api_key';
const PORT = 3000;
let geoLocations = [];

const server = Hapi.server({
  port: PORT,
  host: 'localhost'
});

server.route({
  method: 'POST',
  path: '/login',
  handler: (request, h) => {
    return 'Success';
  },
  options: {
    auth: false
  }
});

server.route({
  method: 'POST',
  path: '/logout',
  handler: (request, h) => {
    return 'Success';
  }
});

server.route({
  method: 'GET',
  path: '/memberinfo',
  handler: (request, h) => {
    return 'Member Info';
  }
});

server.route({
  method: 'POST',
  path: '/search-address',
  handler: (request, h) => {
    const { address } = request.payload;

    // Perform search with address

    const geolocation = {
      lat: 37.7749,
      lon: -122.4194
    };

    return geolocation;
  },
  options: {
    validate: {
      payload: Joi.object({
        address: Joi.string().required()
      })
    }
  }
});

server.route({
  method: 'POST',
  path: '/add-location',
  handler: (request, h) => {
    const { lat, lon } = request.payload;

    // Add mark to the geolocation

    const id = geoLocations.length + 1;
    geoLocations.push({
      id,
      lat,
      lon
    });

    return { id };
  },
  options: {
    validate: {
      payload: Joi.object({
        lat: Joi.number().required(),
        lon: Joi.number().required()
      })
    }
  }
});

server.route({
  method: 'GET',
  path: '/share-location/{id}',
  handler: (request, h) => {
    const { id } = request.params;

    const url = `http://localhost:${PORT}/location/${id}`;
    const filePath = `location_${id}.txt`;

    // Write local file
    fs.writeFile(filePath, url, (err) => {
      if (err) throw err;

      console.log(`Location URL saved to ${filePath}`);
    });

    return { url };
  }
});

server.route({
  method: 'GET',
  path: '/location/{id}',
  handler: (request, h) => {
    const { id } = request.params;

    const geolocation = geoLocations.find((location) => location.id === parseInt(id));

    if (!geolocation) {
      return h.response('Location not found').code(404);
    }

    return geolocation;
  },
  options: {
    validate: {
      params: Joi.object({
        id: Joi.number().required()
      })
    }
  }
});

const init = async () => {
  await server.start();
  console.log(`Server running on port ${PORT}`);
};

process.on('unhandledRejection', (err) => {
  console.log(err);
  process.exit(1);
});

init();