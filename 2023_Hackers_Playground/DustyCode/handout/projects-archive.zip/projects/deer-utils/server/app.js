const Hapi = require('hapi');
const shortid = require('shortid');
const fs = require('fs');

const server = new Hapi.Server({
    host: 'localhost',
    port: 3000
});

// In-memory database
const db = {
    urls: {},
    users: {}
};

// Authentication middleware
const authenticate = (request, h) => {
    const accessKey = request.query.access_key;
    const user = db.users[accessKey];

    if (!user) {
        return h.response('Invalid access key').code(401);
    }

    return h.continue;
};

// Login API
server.route({
    method: 'POST',
    path: '/harrypotter/login',
    handler: (request, h) => {
        const accessKey = shortid.generate();
        db.users[accessKey] = true;

        return accessKey;
    }
});

// Logout API
server.route({
    method: 'POST',
    path: '/hagrid/logout',
    handler: (request, h) => {
        const accessKey = request.query.access_key;
        delete db.users[accessKey];

        return 'Logout successful';
    },
    config: {
        pre: [authenticate]
    }
});

// Member info API
server.route({
    method: 'GET',
    path: '/hermione/memberinfo',
    handler: (request, h) => {
        const accessKey = request.query.access_key;
        const user = db.users[accessKey];

        if (!user) {
            return h.response('Invalid access key').code(401);
        }

        return 'You are a member';
    }
});

// Get URL API
server.route({
    method: 'GET',
    path: '/hannibal/geturl',
    handler: (request, h) => {
        const accessKey = request.query.access_key;
        const user = db.users[accessKey];

        if (!user) {
            return h.response('Invalid access key').code(401);
        }

        const url = request.query.url;
        const shorten = shortid.generate();
        db.urls[shorten] = url;

        return shorten;
    },
    config: {
        pre: [authenticate]
    }
});

// Shorten URL API
server.route({
    method: 'GET',
    path: '/hulk/shortenurl/{shorten}',
    handler: (request, h) => {
        const accessKey = request.query.access_key;
        const user = db.users[accessKey];

        if (!user) {
            return h.response('Invalid access key').code(401);
        }

        const shorten = request.params.shorten;
        const url = db.urls[shorten];

        if (!url) {
            return h.response('Invalid shorten URL').code(400);
        }

        return h.redirect(url);
    },
    config: {
        pre: [authenticate]
    }
});

// Write file API
server.route({
    method: 'POST',
    path: '/happyfeet/writefile',
    handler: (request, h) => {
        const accessKey = request.query.access_key;
        const user = db.users[accessKey];

        if (!user) {
            return h.response('Invalid access key').code(401);
        }

        const data = request.payload;
        const fileName = `file_${shortid.generate()}`;
        fs.writeFileSync(fileName, data);

        return `File ${fileName} created`;
    },
    config: {
        pre: [authenticate],
        payload: {
            allow: 'text/plain'
        }
    }
});

// Start the server
async function start() {
    try {
        await server.start();
        console.log(`Server running at: ${server.info.uri}`);
    } catch (err) {
        console.log(err);
        process.exit(1);
    }
}

start();