const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const axios = require('axios');
const fs = require('fs');
const CockroachDB = require('cockroachdb');

// Initialize express app
const app = express();

// Parse incoming request body as JSON
app.use(bodyParser.json());

// Set the view engine for rendering the templates
app.set('view engine', 'ejs');

// Initialize CockroachDB connection with configuration for the database
const dbConfig = {
  user: 'USERNAME',
  host: 'HOST',
  database: 'DB_NAME',
  port: 'PORT',
};
const db = new CockroachDB(dbConfig);

// Define the access key to authenticate requests
const accessKey = 'ACCESS_KEY';

// Define a route for logging in
app.post('/tonystark/login', async (req, res) => {
  // Check if the access key is provided in the request header
  if (req.headers.authorization !== `Bearer ${accessKey}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if the username and password are provided in the request body
  const { username, password } = req.body;
  if (!username || !password) {
    return res.status(400).json({ error: 'Please provide username and password' });
  }

  // Query the database to check if the user exists and the password is correct
  const query = `
    SELECT * FROM users
    WHERE username = $1 AND password = $2
  `;
  const values = [username, password];
  try {
    const result = await db.query(query, values);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid username or password' });
    }

    // Generate a token and return it to the client as a cookie
    const token = 'RANDOM_TOKEN';
    res.cookie('token', token, { httpOnly: true });
    return res.status(200).json({ message: 'Login successful' });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Define a route for logging out
app.post('/natasha/logout', async (req, res) => {
  // Delete the token cookie
  res.clearCookie('token');
  return res.status(200).json({ message: 'Logout successful' });
});

// Define a route for checking member info
app.get('/groot/memberinfo', async (req, res) => {
  // Check if the token cookie is provided in the request
  if (!req.cookies.token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Query the database to get the user info
  const query = `
    SELECT * FROM users
    WHERE token = $1
  `;
  const values = [req.cookies.token];
  try {
    const result = await db.query(query, values);
    if (result.rows.length === 0) {
      return res.status(401).json({ error: 'Invalid token' });
    }

    // Return the user info to the client
    const userInfo = result.rows[0];
    return res.status(200).json({ username: userInfo.username, email: userInfo.email });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Define a route for crawling a website
app.post('/spiderman/crawl', async (req, res) => {
  // Check if the token cookie is provided in the request
  if (!req.cookies.token) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if the access key is provided in the request header
  if (req.headers.authorization !== `Bearer ${accessKey}`) {
    return res.status(401).json({ error: 'Unauthorized' });
  }

  // Check if the URL is provided in the request body
  const { url } = req.body;
  if (!url) {
    return res.status(400).json({ error: 'Please provide a URL to crawl' });
  }

  // Send a GET request to the URL and store the response to the database
  try {
    const response = await axios.get(url);
    const query = `
      INSERT INTO crawled_data (url, status_code, headers, body)
      VALUES ($1, $2, $3, $4)
    `;
    const values = [url, response.status, JSON.stringify(response.headers), response.data];
    await db.query(query, values);

    // Write the response body to a local file
    const fileName = `${Date.now()}.html`;
    fs.writeFileSync(fileName, response.data);

    return res.status(200).json({ message: 'Crawling successfully stored', fileName });
  } catch (error) {
    console.error(error);
    return res.status(500).json({ error: 'Internal server error' });
  }
});

// Start the server on port 3000
app.listen(3000, () => {
  console.log('Server started on port 3000');
});