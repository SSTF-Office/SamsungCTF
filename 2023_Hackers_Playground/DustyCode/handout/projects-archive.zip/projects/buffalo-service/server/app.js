const Hapi = require('hapi');
const Joi = require('joi');
const uuidv4 = require('uuid/v4');
const fs = require('fs');

const server = Hapi.server({
    port: 3000,
    host: 'localhost'
});

// In-memory database
const posts = [];
const comments = [];

// Helper functions
function findPostById(id) {
    return posts.find(post => post.id === id);
}

function findCommentById(id) {
    return comments.find(comment => comment.id === id);
}

function saveData() {
    const data = {
        posts,
        comments
    };
    fs.writeFile('data.json', JSON.stringify(data), err => {
        if (err) throw err;
        console.log('Data saved to file');
    });
}

function loadData() {
    try {
        const data = fs.readFileSync('data.json');
        const parsedData = JSON.parse(data);
        posts.push(...parsedData.posts);
        comments.push(...parsedData.comments);
        console.log('Data loaded from file');
    } catch (err) {
        console.log('No data file found');
    }
}

// Load data from file on server start
loadData();

// Routes
server.route({
    method: 'POST',
    path: '/padthai/writepost',
    options: {
        validate: {
            payload: Joi.object({
                access_key: Joi.string().required(),
                title: Joi.string().required(),
                body: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key, title, body } = request.payload;
        const newPost = {
            id: uuidv4(),
            access_key,
            title,
            body,
            comments: []
        };
        posts.push(newPost);
        saveData();
        return h.response(newPost);
    }
});

server.route({
    method: 'PATCH',
    path: '/sushi/editpost',
    options: {
        validate: {
            payload: Joi.object({
                access_key: Joi.string().required(),
                postId: Joi.string().required(),
                title: Joi.string().required(),
                body: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key, postId, title, body } = request.payload;
        const post = findPostById(postId);
        if (!post) {
            return h.response('Post not found').code(404);
        }
        if (post.access_key !== access_key) {
            return h.response('Unauthorized').code(401);
        }
        post.title = title;
        post.body = body;
        saveData();
        return h.response(post);
    }
});

server.route({
    method: 'DELETE',
    path: '/ramen/removepost/{postId}',
    options: {
        validate: {
            params: Joi.object({
                postId: Joi.string().required()
            }),
            payload: Joi.object({
                access_key: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key } = request.payload;
        const { postId } = request.params;
        const postIndex = posts.findIndex(post => post.id === postId);
        if (postIndex === -1) {
            return h.response('Post not found').code(404);
        }
        const post = posts[postIndex];
        if (post.access_key !== access_key) {
            return h.response('Unauthorized').code(401);
        }
        posts.splice(postIndex, 1);
        saveData();
        return h.response('Post deleted');
    }
});

server.route({
    method: 'POST',
    path: '/poke/addcomment',
    options: {
        validate: {
            payload: Joi.object({
                access_key: Joi.string().required(),
                postId: Joi.string().required(),
                body: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key, postId, body } = request.payload;
        const post = findPostById(postId);
        if (!post) {
            return h.response('Post not found').code(404);
        }
        const newComment = {
            id: uuidv4(),
            postId,
            access_key,
            body,
            replies: []
        };
        post.comments.push(newComment);
        comments.push(newComment);
        saveData();
        return h.response(newComment);
    }
});

server.route({
    method: 'PATCH',
    path: '/spaghetti/editcomment',
    options: {
        validate: {
            payload: Joi.object({
                access_key: Joi.string().required(),
                commentId: Joi.string().required(),
                body: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key, commentId, body } = request.payload;
        const comment = findCommentById(commentId);
        if (!comment) {
            return h.response('Comment not found').code(404);
        }
        if (comment.access_key !== access_key) {
            return h.response('Unauthorized').code(401);
        }
        comment.body = body;
        saveData();
        return h.response(comment);
    }
});

server.route({
    method: 'DELETE',
    path: '/pizza/removecomment/{commentId}',
    options: {
        validate: {
            params: Joi.object({
                commentId: Joi.string().required()
            }),
            payload: Joi.object({
                access_key: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key } = request.payload;
        const { commentId } = request.params;
        const commentIndex = comments.findIndex(comment => comment.id === commentId);
        if (commentIndex === -1) {
            return h.response('Comment not found').code(404);
        }
        const comment = comments[commentIndex];
        if (comment.access_key !== access_key) {
            return h.response('Unauthorized').code(401);
        }
        const post = findPostById(comment.postId);
        post.comments = post.comments.filter(c => c.id !== commentId);
        comments.splice(commentIndex, 1);
        saveData();
        return h.response('Comment deleted');
    }
});

server.route({
    method: 'POST',
    path: '/biscuit/replycomment',
    options: {
        validate: {
            payload: Joi.object({
                access_key: Joi.string().required(),
                commentId: Joi.string().required(),
                body: Joi.string().required()
            })
        }
    },
    handler: function (request, h) {
        const { access_key, commentId, body } = request.payload;
        const comment = findCommentById(commentId);
        if (!comment) {
            return h.response('Comment not found').code(404);
        }
        const newReply = {
            id: uuidv4(),
            commentId,
            access_key,
            body
        };
        comment.replies.push(newReply);
        saveData();
        return h.response(newReply);
    }
});

// Start the server
async function startServer() {
    try {
        await server.start();
        console.log('Server running at:', server.info.uri);
    } catch (err) {
        console.log(err);
        process.exit(1);
    }
}

startServer();