// import required modules
const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const AWS = require('aws-sdk');
const fs = require('fs');

// configure AWS SDK
AWS.config.update({
  accessKeyId: '<YOUR_ACCESS_KEY_ID>',
  secretAccessKey: '<YOUR_SECRET_ACCESS_KEY>'
});

// create an instance of AWS S3 object storage service
const s3 = new AWS.S3({apiVersion: '2006-03-01'});

// create express app
const app = express();

// set the view engine to ejs
app.set('view engine', 'ejs');

// set the directory for serving static files
app.use(express.static(__dirname + '/public'));

// use body parser middleware
app.use(bodyParser.urlencoded({ extended: true }));

// define endpoints for authentication
app.post('/login', (req, res) => {
  const access_key = req.body.access_key;
  // perform authentication logic and set session variables
  res.json({ success: true, message: 'Login successful.' });
});

app.post('/logout', (req, res) => {
  // perform logout logic and destroy session variables
  res.json({ success: true, message: 'Logout successful.' });
});

app.get('/memberinfo', (req, res) => {
  // retrieve session variables to fetch member information
  res.json({ success: true, message: 'Member information retrieved.' });
});

// endpoints for blog feature
app.get('/lion', (req, res) => {
  // retrieve all blog posts for lion category
  res.render('lion', { posts: [{title: 'Sample Lion Post 1', body: 'This is a sample blog post for lion category.'}, {title: 'Sample Lion Post 2', body: 'This is another sample blog post for lion category.'}] });
});

app.get('/tiger', (req, res) => {
  // retrieve all blog posts for tiger category
  res.render('tiger', { posts: [{title: 'Sample Tiger Post 1', body: 'This is a sample blog post for tiger category.'}, {title: 'Sample Tiger Post 2', body: 'This is another sample blog post for tiger category.'}] });
});

app.post('/lion', (req, res) => {
  // create new blog post in lion category
  const title = req.body.title;
  const body = req.body.body;
  // save post data in AWS S3 object storage
  const key = `lion/${title}_${Date.now()}.txt`;
  const params = {
    Bucket: '<YOUR_BUCKET_NAME>',
    Key: key,
    Body: body
  };
  s3.upload(params, (err, data) => {
    if (err) {
      console.error(err);
      res.json({ success: false, message: 'Failed to create blog post.' });
    } else {
      res.json({ success: true, message: 'Blog post created successfully.' });
    }
  });
});

app.put('/lion/:id', (req, res) => {
  // update existing blog post in lion category
  const id = req.params.id;
  const title = req.body.title;
  const body = req.body.body;
  // fetch existing post data from AWS S3 object storage
  const key = `lion/${id}.txt`;
  const params = {
    Bucket: '<YOUR_BUCKET_NAME>',
    Key: key
  };
  s3.getObject(params, (err, data) => {
    if (err) {
      console.error(err);
      res.json({ success: false, message: 'Failed to update blog post.' });
    } else {
      // update post data and save in AWS S3 object storage
      let post = data.Body.toString();
      post = post.replace(/Title:.*?(\r?\n)/, `Title: ${title}$1`);
      post = post.replace(/Body:.*?(\r?\n)/, `Body: ${body}$1`);
      const updatedParams = {
        Bucket: '<YOUR_BUCKET_NAME>',
        Key: key,
        Body: post
      };
      s3.upload(updatedParams, (err, data) => {
        if (err) {
          console.error(err);
          res.json({ success: false, message: 'Failed to update blog post.' });
        } else {
          res.json({ success: true, message: 'Blog post updated successfully.' });
        }
      });
    }
  });
});

app.delete('/lion/:id', (req, res) => {
  // delete existing blog post in lion category
  const id = req.params.id;
  // remove post data from AWS S3 object storage
  const key = `lion/${id}.txt`;
  const params = {
    Bucket: '<YOUR_BUCKET_NAME>',
    Key: key
  };
  s3.deleteObject(params, (err, data) => {
    if (err) {
      console.error(err);
      res.json({ success: false, message: 'Failed to delete blog post.' });
    } else {
      res.json({ success: true, message: 'Blog post deleted successfully.' });
    }
  });
});

app.post('/lion/neighbor', (req, res) => {
  // add new neighbor to lion blog category
  const neighbor = req.body.neighbor;
  // save neighbor data in local file system
  const path = `${__dirname}/public/neighbors/lion.txt`;
  fs.appendFileSync(path, `${neighbor}\n`);
  res.json({ success: true, message: 'Neighbor added successfully.' });
});

app.get('/lion/neighbor', (req, res) => {
  // retrieve all neighbors for lion blog category
  const path = `${__dirname}/public/neighbors/lion.txt`;
  const data = fs.readFileSync(path, 'utf8');
  const neighbors = data.split('\n').filter(Boolean);
  res.json({ success: true, neighbors: neighbors });
});

// start the server
app.listen(3000, () => {
  console.log('Server started on port 3000.');
});