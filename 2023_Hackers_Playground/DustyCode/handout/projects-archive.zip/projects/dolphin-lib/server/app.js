const Hapi = require('@hapi/hapi');
const AWS = require('aws-sdk');
const fs = require('fs');

// Create a new S3 object and specify its endpoint and region
const s3 = new AWS.S3({
  endpoint: 'https://s3.amazonaws.com',
  region: 'us-west-2',
});

// Define access key for authentication
const accessKey = "randomstring123";

// Create a server with a host and port
const server = Hapi.server({
  host: 'localhost',
  port: 3000
});

// Create a handler function for adding a new friend
const addFriendHandler = async (request, h) => {
  const { friendName, access_key } = request.payload;
  if (access_key !== accessKey) {
    return { message: "Invalid access key" };
  }
  // Add friend to database
  return { message: `${friendName} has been added as your friend.` };
};

// Create a handler function for removing a friend
const removeFriendHandler = async (request, h) => {
  const { friendName, access_key } = request.payload;
  if (access_key !== accessKey) {
    return { message: "Invalid access key" };
  }
  // Remove friend from database
  return { message: `${friendName} has been removed from your friends list.` };
};

// Create a handler function for finding a friend
const findFriendHandler = async (request, h) => {
  const { friendName, access_key } = request.query;
  if (access_key !== accessKey) {
    return { message: "Invalid access key" };
  }
  // Find friend in database
  return { message: `${friendName} is your friend.` };
};

// Create a handler function for posting to SNS
const postHandler = async (request, h) => {
  const { post, access_key } = request.payload;
  if (access_key !== accessKey) {
    return { message: "Invalid access key" };
  }
  // Save post to AWS object storage
  const params = {
    Bucket: 'mybucket',
    Key: 'posts.txt',
    Body: post
  };
  await s3.putObject(params).promise();
  return { message: "Post saved successfully." };
};

// Create a handler function for commenting on a post
const commentHandler = async (request, h) => {
  const { postId, comment, access_key } = request.payload;
  if (access_key !== accessKey) {
    return { message: "Invalid access key" };
  }
  // Retrieve post from AWS object storage
  const params = {
    Bucket: 'mybucket',
    Key: 'posts.txt'
  };
  const data = await s3.getObject(params).promise();
  const posts = data.Body.toString();
  // Append comment to post
  const updatedPosts = posts.replace(postId, `${postId}\n${comment}`);
  // Save updated post to AWS object storage
  const updatedParams = {
    Bucket: 'mybucket',
    Key: 'posts.txt',
    Body: updatedPosts
  };
  await s3.putObject(updatedParams).promise();
  return { message: "Comment added successfully." };
};

// Create a handler function for writing to a local file
const fileHandler = async (request, h) => {
  const { fileName, fileContent, access_key } = request.payload;
  if (access_key !== accessKey) {
    return { message: "Invalid access key" };
  }
  // Write file to local storage
  fs.writeFileSync(fileName, fileContent);
  return { message: "File saved successfully." };
};

// Create a route for adding a friend
server.route({
  method: 'POST',
  path: '/addfriend',
  handler: addFriendHandler
});

// Create a route for removing a friend
server.route({
  method: 'POST',
  path: '/removefriend',
  handler: removeFriendHandler
});

// Create a route for finding a friend
server.route({
  method: 'GET',
  path: '/findfriend',
  handler: findFriendHandler
});

// Create a route for posting to SNS
server.route({
  method: 'POST',
  path: '/post',
  handler: postHandler
});

// Create a route for commenting on a post
server.route({
  method: 'POST',
  path: '/comment',
  handler: commentHandler
});

// Create a route for writing to a local file
server.route({
  method: 'POST',
  path: '/writefile',
  handler: fileHandler
});

// Start the server
async function start() {
  try {
    await server.start();
    console.log(`Server running on ${server.info.uri}`);
  } catch (err) {
    console.log(err);
    process.exit(1);
  }
};

// Start the server
start();