const Hapi = require('@hapi/hapi');
const { Client } = require('pg');

// Create a new Hapi server instance
const server = Hapi.server({
  port: 3000,
  host: 'localhost'
});

// Define a PostgreSQL client to connect to the database
const client = new Client({
  connectionString: 'postgres://username:password@localhost:5432/mydatabase'
});

async function start() {
  try {
    // Connect to the PostgreSQL database
    await client.connect();

    // Register a new API endpoint to query the list of users
    server.route({
      method: 'GET',
      path: '/users',
      handler: async (request, h) => {
        const { access_key } = request.query;

        // Check the access_key parameter
        if (access_key !== 'myrandomaccesskey') {
          return h.response({ message: 'Invalid access key' }).code(401);
        }

        try {
          // Query the database to get the list of users
          const result = await client.query('SELECT * FROM users');

          // Return the list of users as the API response
          return result.rows;
        } catch (err) {
          return h.response({ message: 'Error querying the database' }).code(500);
        }
      }
    });

    // Start the Hapi server
    await server.start();

    console.log('Server running on %s', server.info.uri);
  } catch (err) {
    console.error(err);
    process.exit(1);
  }
}

start();