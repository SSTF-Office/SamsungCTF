const Hapi = require('hapi');
const Redis = require('redis');
const DiskUsage = require('diskusage');

const server = new Hapi.Server();

const PORT = 3000;

const REDIS_HOST = 'localhost';
const REDIS_PORT = 6379;

const ACCESS_KEY = 'random_access_key';

const redisClient = Redis.createClient({
  host: REDIS_HOST,
  port: REDIS_PORT
});

server.connection({ port: PORT });

server.route({
  method: 'POST',
  path: '/cat',
  config: {
    auth: {
      strategy: 'access_key'
    },
    handler: function(request, reply) {
      redisClient.hmset(`blog:${request.payload.id}`, request.payload, function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply(result);
      });
    }
  }
});

server.route({
  method: 'PUT',
  path: '/dog/{id}',
  config: {
    auth: {
      strategy: 'access_key'
    },
    handler: function(request, reply) {
      redisClient.hmset(`blog:${request.params.id}`, request.payload, function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply(result);
      });
    }
  }
});

server.route({
  method: 'DELETE',
  path: '/zebra/{id}',
  config: {
    auth: {
      strategy: 'access_key'
    },
    handler: function(request, reply) {
      redisClient.del(`blog:${request.params.id}`, function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply(result);
      });
    }
  }
});

server.route({
  method: 'POST',
  path: '/lion',
  config: {
    auth: {
      strategy: 'access_key'
    },
    handler: function(request, reply) {
      redisClient.sadd('blog_neighbors', request.payload.id, function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply(result);
      });
    }
  }
});

server.route({
  method: 'DELETE',
  path: '/giraffe',
  config: {
    auth: {
      strategy: 'access_key'
    },
    handler: function(request, reply) {
      redisClient.srem('blog_neighbors', request.payload.id, function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply(result);
      });
    }
  }
});

server.route({
  method: 'GET',
  path: '/meerkat',
  config: {
    auth: {
      strategy: 'access_key'
    },
    handler: function(request, reply) {
      redisClient.hgetall(`blog:${request.query.id}`, function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply(result);
      });
    }
  }
});

server.register(require('hapi-auth-basic'), function(err) {
  if(err) {
    console.log(err);
  }

  server.auth.strategy('access_key', 'basic', {
    validateFunc: function(request, username, password, cb) {
      if (password === ACCESS_KEY) {
        return cb(null, true);
      }
      return cb(null, false);
    }
  });
});

server.route({
  method: 'GET',
  path: '/disk-usage',
  config: {
    auth: false,
    handler: function(request, reply) {
      DiskUsage.check('/', function(err, result) {
        if (err) {
          return reply({
            error: err
          });
        }
        return reply({
          free: result.free,
          total: result.total,
          used: result.total - result.free
        });
      });
    }
  }
});

server.start(function(err) {
  if (err) {
    console.log(err);
  }
  console.log('Server running at:', server.info.uri);
});