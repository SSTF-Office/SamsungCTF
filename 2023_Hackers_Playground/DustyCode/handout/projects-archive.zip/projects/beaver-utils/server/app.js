const http = require('http');
const url = require('url');
const querystring = require('querystring');

// in-memory cache object
const cache = {};

// generate random access key
function generateAccessKey() {
  const chars = 'abcdefghijklmnopqrstuvwxyz0123456789';
  let key = '';
  for (let i = 0; i < 20; i++) {
    key += chars[Math.floor(Math.random() * chars.length)];
  }
  return key;
}

// authenticate user with access_key
function authenticate(req) {
  const parsedUrl = url.parse(req.url);
  const query = querystring.parse(parsedUrl.query);
  if (!query.access_key) {
    return false;
  }
  // check access key in cache
  const accessKey = query.access_key;
  if (cache[accessKey]) {
    return true;
  }
  return false;
}

// arithmetic calculation function using eval
function calculate(expr) {
  try {
    return eval(expr);
  } catch (e) {
    return null;
  }
}

// create http server
const server = http.createServer((req, res) => {
  const parsedUrl = url.parse(req.url);
  const path = parsedUrl.pathname;
  const method = req.method.toUpperCase();

  if (path === '/login' && method === 'POST') {
    // generate random access key and store in cache
    const accessKey = generateAccessKey();
    cache[accessKey] = {loggedIn: true};
    res.setHeader('Content-Type', 'application/json');
    res.end(JSON.stringify({access_key: accessKey}));
  } else if (path === '/logout' && method === 'POST') {
    // remove access key from cache
    const parsedUrl = url.parse(req.url);
    const query = querystring.parse(parsedUrl.query);
    const accessKey = query.access_key;
    delete cache[accessKey];
    res.statusCode = 204;
    res.end();
  } else if (path === '/memberinfo' && method === 'GET') {
    // check if user is logged in with access key
    if (authenticate(req)) {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({memberInfo: 'some info'}));
    } else {
      res.statusCode = 401;
      res.end();
    }
  } else if (path === '/cache' && method === 'GET') {
    // get web response and store to cache
    const parsedUrl = url.parse(req.url);
    const query = querystring.parse(parsedUrl.query);
    const urlToCache = query.url;
    const webReq = http.get(urlToCache, (webRes) => {
      let cacheDoc = '';
      webRes.on('data', (chunk) => {
        cacheDoc += chunk;
      });
      webRes.on('end', () => {
        const cacheId = generateAccessKey();
        cache[cacheId] = {data: cacheDoc};
        res.setHeader('Content-Type', 'application/json');
        res.end(JSON.stringify({cache_id: cacheId}));
      });
    });
    webReq.on('error', (e) => {
      console.error(`Error fetching ${urlToCache}: ${e}`);
      res.statusCode = 500;
      res.end();
    });
  } else if (path.startsWith('/cache/') && method === 'GET') {
    // get cached document with cache id
    const cacheId = path.replace('/cache/', '');
    if (cache[cacheId]) {
      res.setHeader('Content-Type', 'text/html');
      res.end(cache[cacheId].data);
    } else {
      res.statusCode = 404;
      res.end();
    }
  } else if (path === '/calculate' && method === 'GET') {
    // perform arithmetic calculation
    const parsedUrl = url.parse(req.url);
    const query = querystring.parse(parsedUrl.query);
    const expr = decodeURIComponent(query.expr);
    const result = calculate(expr);
    if (result !== null) {
      res.setHeader('Content-Type', 'application/json');
      res.end(JSON.stringify({result}));
    } else {
      res.statusCode = 400;
      res.end();
    }
  } else {
    res.statusCode = 404;
    res.end();
  }
});

// start listening to port 3000
server.listen(3000, () => {
  console.log('Server started on port 3000');
});