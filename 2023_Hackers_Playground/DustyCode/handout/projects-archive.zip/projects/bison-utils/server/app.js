const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const AWS = require('aws-sdk');
const { v4: uuidv4 } = require('uuid');
const WebSocket = require('ws');

const app = express();
app.set('view engine', 'ejs');
app.use(bodyParser.urlencoded({ extended: true }));

const s3 = new AWS.S3({ region: 'REGION', accessKeyId: 'ACCESS_KEY_ID', secretAccessKey: 'SECRET_ACCESS_KEY' });
const BUCKET_NAME = 'BUCKET_NAME';

let activeChatRooms = {};

// Authentication middleware
const authenticate = (req, res, next) => {
  const access_key = req.body.access_key || req.query.access_key;
  if (!access_key) return res.status(403).send({ message: 'Access key is required!' });
  next();
};

// API endpoints for authentication
app.post('/login', (req, res) => {
  const access_key = uuidv4();
  res.send({ access_key });
});

app.get('/logout', authenticate, (req, res) => {
  res.status(200).send({ message: 'Logged out successfully!' });
});

app.get('/memberinfo', authenticate, (req, res) => {
  res.send({ info: 'Some member info' });
});

// API endpoint for chat room creation
app.post('/lemur/create-chat-room', authenticate, (req, res) => {
  const { name, description } = req.body;
  const id = uuidv4();
  activeChatRooms[id] = { name, description, participants: [] };
  res.send({ message: 'Chat room created successfully!', id });
});

// API endpoint for chat room deletion
app.delete('/parrot/delete-chat-room/:chatroomId', authenticate, (req, res) => {
  const { chatroomId } = req.params;
  if (!(chatroomId in activeChatRooms)) return res.status(404).send();
  delete activeChatRooms[chatroomId];
  res.status(204).send();
});

// API endpoint for joining a chat room
app.post('/puma/join-chat-room/:chatroomId', authenticate, (req, res) => {
  const { chatroomId } = req.params;
  if (!(chatroomId in activeChatRooms)) return res.status(404).send({ message: 'Chat room does not exist!' });
  activeChatRooms[chatroomId].participants.push(req.body.username);
  res.send({ message: 'Joined chat room successfully!', chatRoom: activeChatRooms[chatroomId] });
});

// Websocket chat server
const wss = new WebSocket.Server({ port: 8080 });

wss.on('connection', ws => {
  ws.on('message', message => {
    const data = JSON.parse(message);
    const { chatroomId, type, message: chatMessage, username } = data;
    const chatRoom = activeChatRooms[chatroomId];
    if (!chatRoom) return;
    
    if (type === 'direct') {
      const userSocket = wss.clients.find(client => client.username === username);
      if (userSocket) userSocket.send(JSON.stringify({ type: 'direct', message: chatMessage }));
    } else {
      chatRoom.participants.forEach(participant => {
        const userSocket = wss.clients.find(client => client.username === participant);
        if (participant !== username && userSocket) {
          userSocket.send(JSON.stringify({ type: 'broadcast', chatRoom, message: chatMessage }));
        }
      });
    }
  });
  
  ws.on('close', () => {
    const userChatrooms = Object.values(activeChatRooms).filter(chatRoom => chatRoom.participants.includes(ws.username));
    userChatrooms.forEach(chatRoom => {
      chatRoom.participants = chatRoom.participants.filter(participant => participant !== ws.username);
    });
  });
});

// Calculate API
app.get('/dolphin/calculate', authenticate, (req, res) => {
  const { calculation } = req.query;
  const result = eval(calculation);
  res.send({ result });
});

app.listen(3000, () => console.log('Server started on port 3000'));