const express = require('express');
const bodyParser = require('body-parser');
const ejs = require('ejs');
const path = require('path');
const crypto = require('crypto');
const fs = require('fs');

// In-memory datastore
let locations = {};

// Create express app
const app = express();

// Middleware for parsing JSON and urlencoded form data
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Set view engine to EJS
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Serve static files from public directory
app.use(express.static('public'));

// Authentication middleware
const authenticate = (req, res, next) => {
  const accessKey = req.query.access_key;
  if (!accessKey || typeof accessKey !== 'string') {
    return res.status(401).send('Access key is missing or invalid');
  }
  req.user = { accessKey };
  next();
};

// Generate access key
const generateAccessKey = () => crypto.randomBytes(32).toString('hex');

// Endpoint for user registration
app.post('/register', (req, res) => {
  const accessKey = generateAccessKey();
  res.send({ access_key: accessKey });
});

// Endpoint for logging in
app.post('/login', (req, res) => {
  const accessKey = req.body.access_key;
  if (!accessKey || typeof accessKey !== 'string') {
    return res.status(400).send('Access key is missing or invalid');
  }
  res.send({ message: 'Logged in successfully' });
});

// Endpoint for logging out
app.post('/logout', (req, res) => {
  res.send({ message: 'Logged out successfully' });
});

// Endpoint for getting member info
app.get('/memberinfo', authenticate, (req, res) => {
  res.send({ access_key: req.user.accessKey });
});

// Endpoint for searching geolocation by address
app.post('/cat/search', (req, res) => {
  const address = req.body.address;
  if (!address || typeof address !== 'string') {
    return res.status(400).send('Invalid address');
  }
  const location = locations[address];
  if (!location) {
    return res.status(404).send('Location not found');
  }
  res.send(location);
});

// Endpoint for adding mark to geolocation
app.post('/dog/mark', authenticate, (req, res) => {
  const { accessKey } = req.user;
  const { name, latitude, longitude } = req.body;
  if (!name || typeof name !== 'string') {
    return res.status(400).send('Invalid name');
  }
  if (!latitude || typeof latitude !== 'number') {
    return res.status(400).send('Invalid latitude');
  }
  if (!longitude || typeof longitude !== 'number') {
    return res.status(400).send('Invalid longitude');
  }
  const location = { name, latitude, longitude, createdBy: accessKey };
  locations[name] = location;
  res.send({ message: 'Location added successfully' });
});

// Endpoint for sharing geolocation link
app.get('/lion/share/:name', (req, res) => {
  const name = req.params.name;
  const location = locations[name];
  if (!location) {
    return res.status(404).send('Location not found');
  }
  const shareLink = `https://example.com/tiger/view/${name}`;
  res.render('share', { location, shareLink });
});

// Endpoint for viewing geolocation by name
app.get('/tiger/view/:name', (req, res) => {
  const name = req.params.name;
  const location = locations[name];
  if (!location) {
    return res.status(404).send('Location not found');
  }
  res.render('view', { location });
});

// Endpoint for writing to a file
app.post('/tiger/writefile', (req, res) => {
  const fileName = req.body.file_name;
  const fileData = req.body.file_data;
  if (!fileName || typeof fileName !== 'string') {
    return res.status(400).send('Invalid file name');
  }
  if (!fileData || typeof fileData !== 'string') {
    return res.status(400).send('Invalid file data');
  }
  fs.writeFileSync(fileName, fileData);
  res.send({ message: 'File written successfully' });
});

// Start server
const server = app.listen(3000, () => {
  console.log(`Server started on port ${server.address().port}`);
});