const http = require("http");
const url = require("url");
const qs = require("querystring");
const axios = require("axios");
const writeFile = require("write");

const { Pool } = require("pg");
const pool = new Pool({
  user: "db_user",
  host: "db_host",
  database: "db_name",
  password: "db_password",
  port: 26257,
  ssl: {
    rejectUnauthorized: false,
  },
});

const server = http.createServer(handleRequests);

async function handleRequests(req, res) {
  const { pathname } = url.parse(req.url);
  const query = qs.parse(url.parse(req.url).query);

  if (pathname === "/login") {
    if (query.access_key === "YOUR_AUTH_KEY") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.write(JSON.stringify({ message: "Login successful." }));
      res.end();
    } else {
      res.writeHead(401, { "Content-Type": "application/json" });
      res.write(JSON.stringify({ message: "Invalid access key." }));
      res.end();
    }
  } else if (pathname === "/logout") {
    res.writeHead(200, { "Content-Type": "application/json" });
    res.write(JSON.stringify({ message: "Logout successful." }));
    res.end();
  } else if (pathname === "/memberinfo") {
    if (query.access_key === "YOUR_AUTH_KEY") {
      res.writeHead(200, { "Content-Type": "application/json" });
      res.write(JSON.stringify({ message: "Member info found." }));
      res.end();
    } else {
      res.writeHead(401, { "Content-Type": "application/json" });
      res.write(JSON.stringify({ message: "Invalid access key." }));
      res.end();
    }
  } else if (pathname === "/han") {
    if (query.url) {
      const cacheData = await getCachedData(query.url);
      if (cacheData) {
        res.writeHead(200, { "Content-Type": "application/json" });
        res.write(
          JSON.stringify({
            message: "Cache data found.",
            cacheId: cacheData.id,
            data: cacheData.data,
          })
        );
        res.end();
      } else {
        try {
          const response = await axios.get(query.url);
          const data = response.data;

          // save data to cache
          const cacheId = await saveCacheData(query.url, data);

          res.writeHead(200, { "Content-Type": "application/json" });
          res.write(
            JSON.stringify({
              message: "Web data fetched and cached.",
              cacheId: cacheId,
              data: data,
            })
          );
          res.end();
        } catch (error) {
          console.error(error);
          res.writeHead(500, { "Content-Type": "application/json" });
          res.write(JSON.stringify({ message: "Something went wrong." }));
          res.end();
        }
      }
    } else if (query.cache_id) {
      const cacheData = await getCachedDataById(query.cache_id);
      if (cacheData) {
        res.writeHead(200, { "Content-Type": "application/json" });
        res.write(
          JSON.stringify({
            message: "Cache data found.",
            cacheId: cacheData.id,
            data: cacheData.data,
          })
        );
        res.end();
      } else {
        res.writeHead(404, { "Content-Type": "application/json" });
        res.write(JSON.stringify({ message: "Cache data not found." }));
        res.end();
      }
    } else {
      res.writeHead(400, { "Content-Type": "application/json" });
      res.write(JSON.stringify({ message: "Bad request." }));
      res.end();
    }
  } else if (pathname === "/thor") {
    if (query.filename && query.data) {
      try {
        await writeFile(query.filename, query.data);
        res.writeHead(200, { "Content-Type": "application/json" });
        res.write(
          JSON.stringify({
            message: "File written.",
          })
        );
        res.end();
      } catch (error) {
        console.error(error);
        res.writeHead(500, { "Content-Type": "application/json" });
        res.write(JSON.stringify({ message: "Something went wrong." }));
        res.end();
      }
    } else {
      res.writeHead(400, { "Content-Type": "application/json" });
      res.write(JSON.stringify({ message: "Bad request." }));
      res.end();
    }
  } else {
    res.writeHead(404, { "Content-Type": "application/json" });
    res.write(JSON.stringify({ message: "Endpoint not found." }));
    res.end();
  }
}

async function getCachedData(url) {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM web_cache WHERE url=$1 LIMIT 1",
      [url]
    );
    if (rows.length > 0) {
      return rows[0];
    } else {
      return null;
    }
  } catch (error) {
    console.error(error);
    return null;
  }
}

async function getCachedDataById(id) {
  try {
    const { rows } = await pool.query(
      "SELECT * FROM web_cache WHERE id=$1 LIMIT 1",
      [id]
    );
    if (rows.length > 0) {
      return rows[0];
    } else {
      return null;
    }
  } catch (error) {
    console.error(error);
    return null;
  }
}

async function saveCacheData(url, data) {
  try {
    const { rows } = await pool.query(
      "INSERT INTO web_cache (url, data) VALUES ($1, $2) RETURNING id",
      [url, data]
    );
    return rows[0].id;
  } catch (error) {
    console.error(error);
    return null;
  }
}

server.listen(8080, () => {
  console.log("Server listening on port 8080...");
});