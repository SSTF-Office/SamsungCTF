const Hapi = require('hapi');
const fs = require('fs');
const crypto = require('crypto');

const server = Hapi.server({
    port: 3000,
    host: 'localhost'
});

let cache = {};

const generateRandomString = (length) => {
    return crypto.randomBytes(Math.ceil(length/2)).toString('hex').slice(0,length);
};

server.route({
    method: 'POST',
    path: '/panda/webcache',
    handler: function (request, h) {
        const url = request.payload.url;
        const id = generateRandomString(12);
        const cacheData = {id:id, data:''};

        // check if the cache already exists
        if (cache[url]) {
            cacheData.data = cache[url];
        } else {
            // fetch and store the web response
            // (you can use any library for http requests)
            const responseData = 'sample web response';
            cache[url] = responseData;
            cacheData.data = responseData;
        }

        return cacheData;
    }
});

server.route({
    method: 'GET',
    path: '/penguin/webcache/{id}',
    handler: function (request, h) {
        const id = request.params.id;
        const cachedData = cache[id];

        if (cachedData) {
            return cachedData;
        } else {
            return h.response('Cache not found!').code(404);
        }
    }
});

server.route({
    method: 'POST',
    path: '/monkey/writefile',
    handler: function (request, h) {
        const filename = request.payload.filename;
        const data = request.payload.data;

        fs.writeFileSync(filename, data);

        return 'File written successfully!';
    }
});

server.start();