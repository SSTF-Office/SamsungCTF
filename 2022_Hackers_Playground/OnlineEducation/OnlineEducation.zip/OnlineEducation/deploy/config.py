# should be secret
secret_key = "" # REDACTED
admin_hash = "" # REDACTED

# sample data
course_data = {
    'name': 'Sample Education',
    'author': 'SSTF',
    'vids': [
        # REDACTED
    ],
}



