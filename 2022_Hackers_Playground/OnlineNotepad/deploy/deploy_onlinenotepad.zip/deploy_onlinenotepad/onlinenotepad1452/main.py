import os
import jinja2
import uvicorn
import hashlib
from pydantic import BaseModel, Field, validator
from fastapi import FastAPI, Request
from fastapi.staticfiles import StaticFiles
from fastapi.templating import Jinja2Templates


app = FastAPI()

userinfo_path = "userinfo"
memo_path = "memo"

app.mount("/static", StaticFiles(directory="static"), name="static")
templates = Jinja2Templates(directory=["templates", userinfo_path, memo_path])


userinfo_raw = """{%% set userid = "%s" %%}
{%% set password = "%s" %%}"""

memofile_raw = """<html>
<head>
    <title>Online Notepad</title>
    <link href="{{ url_for('static', path='/styles.css') }}" rel="stylesheet">
</head>
<body>
<div>
    {%% import userid+".j2" as user %%}

    {%% if userid == user.userid %%}
        {%% if password == user.password %%}
            <h1>Hello {{ userid }}</h1>
            <h1><pre>{%% raw %%}%s{%% endraw %%}</pre></h1>
        {%% else %%}
            <h1>Login Fail</h1>
        {%% endif %%}
    {%% else %%}
        <h1>Login Fail</h1>
    {%% endif %%}
</div>
</body>
</html>
"""

class Memo(BaseModel):
    userid: str = Field(min_length=5, max_length=20)
    password: str = Field(min_length=5, max_length=20)
    memo: str = Field(min_length=1, max_length=64)

    @validator("userid")
    def val_userid(cls, v):
        if v == "admin":
            raise ValueError("access denied")
        if v.isalnum() != True:
            raise ValueError("userid cannot contain a special character")
        return v

    @validator("password")
    def val_password(cls, v):
        if ("\"" in v) or ("/" in v):
            raise ValueError("password cannot contain a special character")
        return v

    @validator("memo")
    def val_memo(cls, v):
        if ("{{" in v) or ("}}" in v):
            raise ValueError("memo cannot contain a special character")
        return v


@app.post("/memo/")
async def write_memo(request:Request, memo:Memo):
    global userinfo_path, memo_path
    global userinfo_raw, memofile_raw

    userinfo = userinfo_raw % (memo.userid, memo.password)
    open(os.path.join(userinfo_path, memo.userid+".j2"), "w").write(userinfo)

    memofile = memofile_raw % memo.memo
    open(os.path.join(memo_path, memo.userid+".html"), "w").write(memofile)

    return memo

@app.get("/memo/{userid}/{password}")
async def read_memo(request:Request, userid:str, password:str):
    global userinfo_path, memo_path
    global userinfo_raw, memofile_raw

    try:
        if (os.path.exists(os.path.join(userinfo_path, "admin.j2")) == False) or (hashlib.md5(open(os.path.join(userinfo_path, "admin.j2"), "rb").read()).hexdigest() != "7cfdf7eb50aa96059952e96a9db72088"):
            userinfo = userinfo_raw % ("admin", "!@#$qwer1234!@#$")
            open(os.path.join(userinfo_path, "admin.j2"), "w").write(userinfo)
        if (os.path.exists(os.path.join(memo_path, "admin.html")) == False) or (hashlib.md5(open(os.path.join(memo_path, "admin.html"), "rb").read()).hexdigest() != "268e671c900bcf05246823cd0ed420dd"):
            memofile = memofile_raw % "Hacked by Super Hacker!"
            open(os.path.join(memo_path, "admin.html"), "w").write(memofile)

        if (
            (userid.isalnum() == True) and 
            os.path.exists( os.path.join(userinfo_path, userid+".j2") ) and 
            os.path.exists( os.path.join(memo_path, userid+".html") )
        ):
            return templates.TemplateResponse(userid+".html", {"request": request, "userid":userid, "password":password})
        else:
            return templates.TemplateResponse("readfail.html", {"request": request})
    except Exception as e:
        print(e)
        return("Exception")

@app.get('/')
async def index(request:Request):
    context = {"request":request}
    return templates.TemplateResponse('index.html', context)


if __name__ == '__main__':
    uvicorn.run(app, host="0.0.0.0", port=35547, headers=[("Server", "FastAPI")], log_level="info")