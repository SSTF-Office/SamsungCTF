#!/usr/bin/env bash

/etc/init.d/xinetd restart
sleep infinity
